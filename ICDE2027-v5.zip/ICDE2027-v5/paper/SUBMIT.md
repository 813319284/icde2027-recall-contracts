# 投稿清单（PI 专用 · ICDE 2027 Round 2）

> 格式按 IEEE 官方会议模板 062824 生成：模板自带 `IEEEtran.cls` V1.8b 随源码放在 `paper/IEEEtran.cls`，
> preamble、`algorithmic` 算法环境、多作者作者块、`IEEEtran.bst` 均与模板对齐。
> 一处已知偏离：模板建议摘要不用数学符号，本文保留了唯一的 `Pr[r(q)<τ] ≤ φ`（本文定义的对象）。

> 机械项全部由脚本核验，当前 **38/38 通过**（作者块已按官方模板填入：杨晨、陈纯毅（通讯作者），长春理工大学）。
> 38 项含：Letter 尺寸 / 页数 / 字体嵌入 / 文本层 / 编译错误 / 未解析引用 / 文献条数 / 无 appendix /
> 无 TODO / 摘要 ≤300 词 / 无 overfull / 浮动体全被引用 / 文献无孤儿 / PDF 无主机名与路径泄漏 /
> PDF 与当前源码同源（源码哈希）/ claim 审计 / PDF 声明的审计格数与实际一致 /
> PDF 声明的运行次数与产物一致 / 30 条头条主张与产物一致且出现在 PDF 中（`relay/claims.json`）/
> 正文页数 ≤12（按参考文献起始页判定，现 ≈11.9）/ PDF 字节里无本地路径、主机名、内网地址 /
> 无嵌入附件 / 无近空页 / qpdf 结构检查通过 / 无批注 / 元数据不含主机名或路径 /
> CMT 摘要与 PDF 摘要逐一对齐 / 作者块。
> **截止：2026-11-11 17:00 PT = 北京时间 11-12 09:00。投稿走 Microsoft CMT。**

## 零、最省事的完整闭环

改任何东西之后都必须重走一遍，缺一步都不算完成：

```bash
bash scripts/build_paper.sh           # 断言 latex_errors=0 / bibitems=23 / unresolved=0
python3 scripts/preflight.py          # 应为 38/38
bash scripts/verify_all.sh            # 末行 ALL LAYERS OK (submit-ready: 38/38)
pdfinfo paper/build/main.pdf | grep Pages
```

**实测预期**：正文 ≈11.9 页，参考文献自第 12 页起，总 13 页（ICDE 页数上限不含参考文献）。
若出现红项（例如正文涨过 12 页），先修再传。1/2/3/4/6 作者与长名的页数矩阵见
`relay/AUTHOR_BLOCK_MATRIX.md`（六种都不超正文 12 页）。改作者：编辑 `relay/authors.txt` 后
`python3 scripts/set_authors.py --run`。

## 零·五、上传前最后一步

**确认"你上传的文件"就是"通过 38/38 检查的那个文件"**：

```bash
bash scripts/submit_manifest.sh > relay/SUBMISSION_RECEIPT.txt
cat relay/SUBMISSION_RECEIPT.txt
```

回执打印 PDF 的 sha256 / 字节数 / 页数 / 源码哈希，并核对 `source hash == current source`。
上传前用回执里的 `pdf sha256` 与要传的文件比对，不一致就是传错了文件。

## 一、只需 PI 做的 5 件事

1. **CMT 里逐个作者填 ORCID**（官方硬要求；未填无法提交）。
2. **确认没有重复投稿**（本文不得同时在别处审稿；被拒后一年内不能再投 ICDE）。
3. **上传 PDF**：`paper/build/main.pdf`（正文 ≈11.9 页 ≤ 12 页上限）。
4. **补充材料**给一个公开、稳定、不暴露审稿人身份的 URL（Zenodo 或 GitHub Release）。
5. **选 track**：Research Track（regular paper）；标题原样：
   *Recall Contracts: Anytime-Valid Auditing of Vector Search, and the Price of Compliance*

## 二、CMT 表单可复制内容

**Title**
```
Recall Contracts: Anytime-Valid Auditing of Vector Search, and the Price of Compliance
```

**Abstract**（与 PDF 逐字一致；`python3 scripts/sync_submit_abstract.py` 会从 PDF 重灌这一块，preflight 逐字比对）
```
Vector search is an operator inside database systems, but its quality is still governed by an offline average. We show the average is the wrong object: on SIFT-1M an index with mean recall@10 of 0.987 returns under 10 true neighbors for 10.0% of queries; on GloVe-1.18M a mean of 0.875 hides 42.0%; on NYTimes-256 an index exactly at the 0.95 target serves 23.9% of queries below it. We formulate the promise as a recall contract on the tail: at every decision time, the fraction of arrivals whose recall falls below the target must stay below a violation budget. We then study how a service can know, on a bounded audit budget, whether it violates it and what the cheapest way back is. Our certificate is valid uniformly over time: over 1000 twelveepoch runs at the boundary, a fixed-sample 95% interval re-used at every decision false-certifies 7.6% of runs and a bootstrap 12.3%, both above the promised 5%, while α-spent bounds falsecertify 0.8% of runs (95% Wilson CI [0.4, 1.6]). We give an auditsizing law converting a margin into a rate, verified over a 20× power range (0.0%→84.2%), and a price list: three rebuilds (89 s) leave every epoch of a churn trajectory in violation, adapting search effort costs 2.5× mean query latency and leaves none, and the compliant intervention differs across index families—effort, redesign or representation. Deployment-time audits sign off on 97% of drift runs, mean-recall monitoring on 86%; the contract does not. The same loop runs in PostgreSQL, where rebuilds buy no tail quality. No distribution-free, mean-only certificate does better: a 0.95 tail at 0.05 needs a mean of at least 0.995, so a mean SLA is insufficient by construction.
```

**Keywords**
```
vector search; approximate query processing; quality contracts; sequential testing; index maintenance; confidence sequences
```

## 三、官方规则核对

| 规则 | 官方要求 | 现状 |
|---|---|---|
| 页数 | 正文 ≤12 页（不含参考文献） | 正文 ≈11.9 页 ✓ |
| 附录 | 不允许 | 无 ✓ |
| 模板 | IEEE conference，Letter | IEEEtran conference，612×792 ✓ |
| 字体 | 全部嵌入 | 42 个，全部嵌入 ✓ |
| 匿名 | 单盲 | 作者可见（已填） ✓ |
| 生成式 AI | 写作过程中使用需在致谢声明 | 已按官方表述声明（仅语言与可读性润色） ✓ |
| 一稿多投 | 禁止 | 请确认 |
| 每轮上限 | 每作者 ≤5 篇 | 请确认 |

## 四、审稿期弹药（不进正文）

- `relay/REVIEWER_RISKS.md`：8 条最可能攻击 + 证据 + 一句话应答。
- `relay/REBUTTAL_DRAFT.md`：回应期可直接改写的 8 段预写回应（每条带数字与章节/图表指针）。
- `relay/THEOREM_CHECK.md`：定理 1 的六个条件 ↔ 实现逐条核对。
- `relay/AUDIT.md`：每个正文数字 → 产物 → 重算命令。
- `scripts/check_numbers.py`：236 个表格数字逐格核对（退出码 0 才放行）。

## 五、如果被拒

R2 被拒后一年内不得再投 ICDE（最早 ICDE 2028 R1）。可转向 SIGMOD/VLDB 下一轮，或 TKDE 期刊版
（补 DKW 型整条 CDF 与更广的系统接入）。
