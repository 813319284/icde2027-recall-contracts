#!/usr/bin/env bash
# Gates for this archive; run from the archive root:  bash repro.sh
set -uo pipefail
cd "$(dirname "$0")"
fail=0
run() {
  printf '%-42s' "$1"; shift
  if "$@" >/tmp/gate.log 2>&1; then
    echo "OK    $(tail -1 /tmp/gate.log | cut -c1-64)"
  else
    echo "FAIL"; tail -6 /tmp/gate.log; fail=1
  fi
}
run "table numbers"  python3 repro/scripts/check_numbers.py
run "prose numbers"                  python3 repro/scripts/check_prose_numbers.py --strict
run "template conformance"           python3 repro/scripts/check_template.py
echo
if [ "$fail" -eq 0 ]; then echo "ALL GATES OK"; else echo "SOME GATES FAILED"; fi
exit "$fail"
