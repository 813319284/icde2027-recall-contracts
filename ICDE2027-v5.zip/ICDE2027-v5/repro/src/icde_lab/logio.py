"""Per-query log: the artefact every later estimator/policy experiment replays."""
from __future__ import annotations

import json
import os
from typing import Iterable


class JsonlWriter:
    def __init__(self, path: str):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.path = path
        self._f = open(path, "w", encoding="utf-8")

    def write(self, rec: dict):
        self._f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    def write_many(self, recs: Iterable[dict]):
        for r in recs:
            self.write(r)

    def close(self):
        self._f.flush()
        self._f.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


def dump_json(path: str, obj):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
