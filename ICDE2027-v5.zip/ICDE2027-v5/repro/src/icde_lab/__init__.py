"""ICDE lab: vector-index recall contracts under drift.

Design rule (feasibility lever): every experiment writes a *per-query log*
(found ids, exact ids, latency, round, query family). All monitoring /
estimation / maintenance-policy experiments are then offline re-simulations
over that log, so we can run thousands of trials cheaply and report real CIs.
"""
__all__ = ["datasets", "indexes", "truth", "drift", "logio"]
