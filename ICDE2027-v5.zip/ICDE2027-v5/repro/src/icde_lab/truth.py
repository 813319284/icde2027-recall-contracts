"""Exact ground truth for arbitrary (drifting) query sets and live vector sets.

Deletes are tombstones in both the ANN index and here, so "recall" is always
recall w.r.t. exact kNN *over the live set* — the only口径 that a contract can
be written against.
"""
from __future__ import annotations

import faiss
import numpy as np


class ExactKNN:
    def __init__(self, dim: int, metric: str = "l2"):
        self.dim, self.metric = dim, metric
        self.index = self._fresh()
        self.dead: np.ndarray = np.empty(0, dtype=np.int64)

    def _fresh(self):
        return faiss.IndexFlatL2(self.dim) if self.metric == "l2" else faiss.IndexFlatIP(self.dim)

    def reset_with(self, x: np.ndarray):
        self.index = self._fresh()
        self.index.add(np.ascontiguousarray(x))
        self.dead = np.empty(0, dtype=np.int64)
        return self

    def add(self, x: np.ndarray):
        self.index.add(np.ascontiguousarray(x))
        return self

    def set_dead(self, dead: np.ndarray):
        self.dead = np.asarray(dead, dtype=np.int64)
        return self

    def knn(self, q: np.ndarray, k: int) -> np.ndarray:
        q = np.ascontiguousarray(q)
        if len(self.dead) == 0:
            _, i = self.index.search(q, k)
            return i
        sp = faiss.SearchParameters()
        sp.sel = faiss.IDSelectorNot(faiss.IDSelectorBatch(self.dead))
        _, i = self.index.search(q, k, params=sp)
        return i

    @property
    def ntotal(self) -> int:
        return int(self.index.ntotal)


def recall_at_k(found: np.ndarray, truth: np.ndarray, k: int) -> np.ndarray:
    """Per-query recall@k (fraction of exact top-k ids retrieved). Vectorised."""
    found = np.asarray(found)[:, :k]
    truth = np.asarray(truth)[:, :k]
    hits = np.zeros(len(found), dtype=np.float64)
    for r in range(len(found)):
        t = truth[r][truth[r] >= 0]
        if len(t) == 0:
            hits[r] = np.nan
            continue
        hits[r] = np.intersect1d(found[r], t).size / float(len(t))
    return hits
