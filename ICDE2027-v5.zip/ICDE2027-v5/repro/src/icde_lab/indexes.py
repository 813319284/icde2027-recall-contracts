"""Index wrappers. One interface, several families (HNSW / IVF-PQ / flat).

Only faiss is used: single dependency, stable wheels, and it covers the index
families an ICDE reviewer expects to see (graph / quantization / exact).
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import faiss
import numpy as np


def _metric(metric: str) -> int:
    return faiss.METRIC_INNER_PRODUCT if metric == "ip" else faiss.METRIC_L2


@dataclass
class BuildStats:
    build_s: float = 0.0
    add_s: float = 0.0
    n_rebuilds: int = 0
    rebuild_s: float = 0.0
    n_inserted: int = 0
    n_deleted: int = 0


class AnnIndex:
    """HNSW index with incremental insert + delete, and full rebuild accounting."""

    def __init__(self, dim: int, metric: str = "l2", family: str = "hnsw",
                 M: int = 32, ef_construction: int = 200, ef_search: int = 64,
                 nlist: int = 1024, nprobe: int = 16, pq_m: int = 16):
        self.dim, self.metric, self.family = dim, metric, family
        self.M, self.ef_construction, self.ef_search = M, ef_construction, ef_search
        self.nlist, self.nprobe, self.pq_m = nlist, nprobe, pq_m
        self.stats = BuildStats()
        self._data: list[np.ndarray] = []   # authoritative store (rebuild needs the vectors)
        self.index = None
        self.dead: np.ndarray = np.empty(0, dtype=np.int64)  # tombstones (production-style soft delete)
        self._live_cache: np.ndarray | None = None

    # ---- construction -------------------------------------------------
    def _fresh(self):
        if self.family == "hnsw":
            idx = faiss.IndexHNSWFlat(self.dim, self.M, _metric(self.metric))
            idx.hnsw.efConstruction = self.ef_construction
            idx.hnsw.efSearch = self.ef_search
            return idx
        if self.family == "ivfpq":
            quant = faiss.IndexFlatL2(self.dim) if self.metric == "l2" else faiss.IndexFlatIP(self.dim)
            idx = faiss.IndexIVFPQ(quant, self.dim, self.nlist, self.pq_m, 8, _metric(self.metric))
            idx.nprobe = self.nprobe
            return idx
        if self.family == "ivfflat":
            quant = faiss.IndexFlatL2(self.dim) if self.metric == "l2" else faiss.IndexFlatIP(self.dim)
            idx = faiss.IndexIVFFlat(quant, self.dim, self.nlist, _metric(self.metric))
            idx.nprobe = self.nprobe
            return idx
        if self.family == "flat":
            return faiss.IndexFlatL2(self.dim) if self.metric == "l2" else faiss.IndexFlatIP(self.dim)
        raise ValueError(self.family)

    def build(self, x: np.ndarray):
        t0 = time.perf_counter()
        self._data = [np.ascontiguousarray(x)]
        self.index = self._fresh()
        if self.family in ("ivfpq", "ivfflat"):
            self.index.train(x)
        self.index.add(x)
        self.stats.build_s += time.perf_counter() - t0
        return self

    def live_matrix(self) -> np.ndarray:
        """Concatenated live vectors, in id order (what a rebuild actually indexes)."""
        x = np.concatenate(self._data, axis=0) if self._data else np.empty((0, self.dim), np.float32)
        if len(self.dead) == 0:
            return np.ascontiguousarray(x)
        mask = np.ones(len(x), dtype=bool)
        mask[self.dead[self.dead < len(x)]] = False
        return np.ascontiguousarray(x[mask])

    def rebuild(self):
        """Full rebuild: the expensive action. Tombstoned vectors are physically dropped,
        which is exactly what makes rebuild a different lever from ef_search."""
        t0 = time.perf_counter()
        x = self.live_matrix()
        if len(x) == 0:
            return self
        self._data = [x]
        self.dead = np.empty(0, dtype=np.int64)
        self._live_cache = None
        self.index = self._fresh()
        if self.family in ("ivfpq", "ivfflat"):
            self.index.train(x)
        self.index.add(x)
        dt = time.perf_counter() - t0
        self.stats.rebuild_s += dt
        self.stats.n_rebuilds += 1
        return self

    # ---- mutation -----------------------------------------------------
    def add(self, x: np.ndarray):
        t0 = time.perf_counter()
        x = np.ascontiguousarray(x)
        self._data.append(x)
        self.index.add(x)
        self.stats.add_s += time.perf_counter() - t0
        self.stats.n_inserted += len(x)
        return self

    def remove(self, frac: float, rng: np.random.Generator):
        """Soft-delete a random fraction of *live* vectors (tombstones, as deployed systems do).

        faiss HNSW has no remove_ids, so tombstones are the faithful mechanism:
        the node stays in the graph and is filtered at query time via IDSelector,
        which is exactly what Milvus / Qdrant / pgvector do.
        """
        live = self.live_ids()
        if len(live) == 0 or frac <= 0:
            return np.empty(0, dtype=np.int64)
        ids = rng.choice(live, size=int(frac * len(live)), replace=False).astype(np.int64)
        self.dead = np.union1d(self.dead, ids)
        self._live_cache = None
        self.stats.n_deleted += len(ids)
        return ids

    def live_ids(self) -> np.ndarray:
        if self._live_cache is None:
            n = self.index.ntotal
            if len(self.dead) == 0:
                self._live_cache = np.arange(n, dtype=np.int64)
            else:
                mask = np.ones(n, dtype=bool)
                mask[self.dead[self.dead < n]] = False
                self._live_cache = np.flatnonzero(mask).astype(np.int64)
        return self._live_cache

    # ---- query --------------------------------------------------------
    def search(self, q: np.ndarray, k: int, ef: int | None = None):
        """Search with tombstones handled the way deployed systems do it: over-fetch + filter.

        faiss' IDSelector path ignores efSearch for HNSW (measured), so the
        latency lever would silently disappear under churn — the one regime where
        the controller matters. Over-fetch keeps the lever honest and matches
        Milvus/Qdrant behaviour (filter-after-search).
        """
        t0 = time.perf_counter()
        q = np.ascontiguousarray(q)
        if ef is not None and self.family == "hnsw":
            self.index.hnsw.efSearch = ef
        if ef is not None and self.family in ("ivfpq", "ivfflat"):
            self.index.nprobe = ef
        dead = self.dead
        if len(dead) == 0:
            d, i = self.index.search(q, k)
        else:
            live = self.live_ids()
            dead_set = dead
            kq = int(min(self.index.ntotal, max(k * 8, k + 64)))
            d, i = self.index.search(q, kq)
            keep = np.isin(i, dead_set, invert=True)
            idx_sorted = np.argsort(np.where(keep, np.arange(kq)[None, :], kq), axis=1)
            i = np.take_along_axis(i, idx_sorted, axis=1)[:, :k]
            d = np.take_along_axis(d, idx_sorted, axis=1)[:, :k]
        return i, d, (time.perf_counter() - t0) / max(len(q), 1)

    def search_ef(self, q: np.ndarray, k: int, ef: int):
        """Search at an explicit ef_search (the latency lever of the controller)."""
        return self.search(q, k, ef=ef)

    @property
    def ntotal(self) -> int:
        return int(self.index.ntotal if self.index is not None else 0)
