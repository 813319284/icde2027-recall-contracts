"""Dataset loading (ann-benchmarks HDF5 format) + deterministic splits."""
from __future__ import annotations

import os
from dataclasses import dataclass

import h5py
import numpy as np

DATA_DIR = os.environ.get("ICDE_DATA", "/opt/volume/IEEE/ICDE/data")


@dataclass
class Dataset:
    name: str
    train: np.ndarray      # (N, d) float32 base vectors
    test: np.ndarray       # (Q, d) float32 official queries
    neighbors: np.ndarray  # (Q, k_gt) official ground truth (may be -1 padded)
    metric: str            # "l2" | "ip"

    @property
    def dim(self) -> int:
        return int(self.train.shape[1])


def load_ann_benchmark(filename: str, name: str | None = None) -> Dataset:
    path = filename if os.path.isabs(filename) else os.path.join(DATA_DIR, filename)
    with h5py.File(path, "r") as f:
        train = np.asarray(f["train"], dtype=np.float32)
        test = np.asarray(f["test"], dtype=np.float32)
        neighbors = np.asarray(f["neighbors"], dtype=np.int64)
        metric = f.attrs.get("distance", "euclidean")
        if isinstance(metric, bytes):
            metric = metric.decode()
    metric = "ip" if str(metric).lower() in ("angular", "ip", "cosine") else "l2"
    if metric == "ip":  # ann-benchmarks stores angular => normalise, use inner product
        train = train / np.maximum(np.linalg.norm(train, axis=1, keepdims=True), 1e-12)
        test = test / np.maximum(np.linalg.norm(test, axis=1, keepdims=True), 1e-12)
    return Dataset(name or os.path.basename(path).split(".")[0], train, test, neighbors, metric)


def initial_split(ds: Dataset, n_base: int, seed: int = 0):
    """Return (base0, incoming) as a fixed permutation split -> incoming order is the arrival order."""
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(ds.train))
    base0 = ds.train[idx[:n_base]]
    incoming = ds.train[idx[n_base:]]
    return np.ascontiguousarray(base0), np.ascontiguousarray(incoming)
