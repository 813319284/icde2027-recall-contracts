"""Drift generators: the workload is not stationary, and that is the point.

Four families, matching how vector stores actually degrade:
  append       content growth (new documents indexed)
  churn        update-heavy (deletes + inserts)
  query_shift  query distribution moves to the new content
  model_shift  embedding model upgraded -> new vectors/queries live in a rotated frame

Every query carries a `cluster` id: queries issued "from" the same source vector
are correlated, which is precisely what makes i.i.d. audit intervals undercover.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def orthogonal(dim: int, rng: np.random.Generator, angle: float = 0.35) -> np.ndarray:
    """Rotation by `angle` towards a random rotation (mild-but-real embedding drift)."""
    a = rng.normal(size=(dim, dim))
    q, _ = np.linalg.qr(a)
    r = (1 - angle) * np.eye(dim, dtype=np.float64) + angle * q
    u, _, vt = np.linalg.svd(r)
    return (u @ vt).astype(np.float32)


@dataclass
class RoundPlan:
    inserts: np.ndarray | None
    delete_frac: float
    q_old: np.ndarray
    q_new: np.ndarray
    cluster_old: np.ndarray
    cluster_new: np.ndarray


def build_plan(
    incoming: np.ndarray,
    test_queries: np.ndarray,
    rounds: int,
    batch: int,
    nq: int,
    family: str = "append",
    seed: int = 0,
    jitter: float = 0.15,
    delete_frac: float = 0.02,
    n_clusters: int = 50,
) -> list[RoundPlan]:
    rng = np.random.default_rng(seed)
    plan: list[RoundPlan] = []
    cursor, ins_offset = 0, 0
    rot = orthogonal(incoming.shape[1], rng) if family == "model_shift" else None
    std = float(incoming.std())
    n_test = len(test_queries)

    for t in range(rounds):
        ins = incoming[cursor:cursor + batch] if cursor < len(incoming) else np.empty((0, incoming.shape[1]), np.float32)
        cursor += batch

        # --- old-distribution queries: held-out official queries, grouped in clusters
        start = (t * nq) % max(n_test - nq, 1)
        q_old = test_queries[start:start + nq].copy()
        c_old = np.arange(nq) % max(nq // 8, 1) + 0  # official queries: near-independent groups

        # --- new-distribution queries: issued from freshly arriving content (clustered!)
        if len(ins) >= 1:
            pick = rng.integers(0, len(ins), size=nq)
            src = ins[pick]
            c_new = ins_offset + pick
        else:
            pick = rng.integers(0, len(incoming), size=nq)
            src = incoming[pick]
            c_new = pick
        q_new = src + rng.normal(scale=jitter * std, size=src.shape).astype(np.float32)
        # quantise clusters: many queries from few source vectors -> strong within-cluster dependence
        c_new = (c_new % n_clusters) + 1000 * (t + 1) % 100000

        if family == "model_shift":
            if len(ins):
                ins = (ins @ rot)
            q_new = (q_new @ rot)
        if family == "query_shift":
            # progressive out-of-distribution drift: the workload walks off the data
            # manifold (new user intents), 0.4 population-sd per epoch
            direction = rng.normal(size=incoming.shape[1]).astype(np.float32)
            direction /= max(np.linalg.norm(direction), 1e-9)
            q_new = q_new + (0.4 * (t + 1)) * std * direction

        df = delete_frac if family == "churn" else 0.0
        plan.append(RoundPlan(ins, df, q_old.astype(np.float32), q_new.astype(np.float32),
                              np.asarray(c_old, dtype=np.int64), np.asarray(c_new, dtype=np.int64)))
        ins_offset += len(ins)
    return plan
