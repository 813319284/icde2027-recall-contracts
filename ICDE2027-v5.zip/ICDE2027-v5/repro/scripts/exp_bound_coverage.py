#!/usr/bin/env python3
"""Validate the certificate's core primitive: does Eq. (3) actually cover?

Everything downstream (Thm. 1, the sizing law, the closed loop) rests on one object: the
exact finite-population upper limit K+(k; n, N, alpha). If its coverage is below 1-alpha,
the paper is wrong regardless of how the experiments look, so we check it directly by
simulation over a grid of population sizes, violation counts, sample sizes and levels.

    python3 scripts/exp_bound_coverage.py

Writes reports/s0/bound_coverage.json and prints the worst observed coverage per alpha.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np
from scipy.stats import hypergeom

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from exp_t1_audit import hypergeom_upper  # noqa: E402

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))


def main():
    rng = np.random.default_rng(20261110)
    trials = 4000
    grid_N = [500, 4000, 20000]
    grid_K = [0.005, 0.02, 0.05, 0.10, 0.30]
    grid_m = [50, 200, 1000]
    grid_alpha = [0.20, 0.10, 0.05, 0.01]
    out = []
    for N in grid_N:
        for frac in grid_K:
            K = int(round(frac * N))
            for m in grid_m:
                if m > N:
                    continue
                # draw the audited violation counts directly from the hypergeometric law
                ks = hypergeom.rvs(N, K, m, size=trials, random_state=rng)
                for alpha in grid_alpha:
                    n_eval = 2000
                    draws = ks[:n_eval]
                    # cache the (expensive) bound per distinct k: at most m+1 of them
                    cache = {int(k): hypergeom_upper(int(k), m, N, alpha)
                             for k in np.unique(draws)}
                    hits = np.array([cache[int(k)] >= K / N for k in draws])
                    cov = float(hits.mean())
                    se = float(np.sqrt(max(cov * (1 - cov), 1e-9) / n_eval))
                    out.append({"N": N, "K_frac": frac, "m": m, "alpha": alpha,
                                "coverage": cov, "se": se})
    os.makedirs(os.path.join(REPO, "reports", "s0"), exist_ok=True)
    with open(os.path.join(REPO, "reports", "s0", "bound_coverage.json"), "w") as f:
        json.dump(out, f, indent=1)

    print(f"{'alpha':>6} {'min cov':>8} {'mean cov':>9} {'cells':>6}")
    worst = {}
    for alpha in grid_alpha:
        covs = [c["coverage"] for c in out if c["alpha"] == alpha]
        worst[alpha] = min(covs)
        print(f"{alpha:6.2f} {min(covs):8.3f} {np.mean(covs):9.3f} {len(covs):6d}")
    # nominal coverage is 1 - alpha; allow 3 Monte-Carlo standard errors of slack
    bad = []
    for c in out:
        nom = 1.0 - c["alpha"]
        if c["coverage"] < nom - 3.0 * c["se"] - 0.005:
            bad.append((c["alpha"], c["N"], c["K_frac"], c["m"], round(c["coverage"], 3),
                        round(nom, 3), round(c["se"], 4)))
    if bad:
        print("\nWARNING: cells below nominal beyond Monte-Carlo error:")
        for b in bad[:6]:
            print("   alpha=%s N=%s K=%s m=%s cov=%.3f nominal=%.3f se=%.4f" % b)
        return 1
    print("\nOK: exact bound covers at or above nominal in every cell (within 3 MC SE).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
