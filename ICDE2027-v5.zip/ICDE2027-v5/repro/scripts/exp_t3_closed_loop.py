#!/usr/bin/env python3
"""T3 closed loop: audit-driven maintenance under a recall contract.

Policies compared on the same drift trajectory:
  never      no action (what happens by default)
  periodic_k full rebuild every k rounds (k picked by an oracle over the grid)
  count_n    rebuild once `n` vectors have been inserted since the last rebuild
  ef_auto    adaptive ef_search only (latency lever, never rebuild)
  ctrl       contract controller: from the audit sample estimate F(tau) at every
             ef, pick the cheapest action whose predicted bound stays <= phi

Key trick that makes the controller honest and cheap: the audit sample already
has *exact* top-k, so recall at any ef is measurable on the same audited queries
for free (no extra ground truth). Only the post-rebuild effect needs a model, and
that model is re-calibrated at every rebuild.

Cost is reported in two physical units (rebuild wall-clock seconds, per-query
latency ms) plus a Pareto sweep over their exchange rate — no invented prices.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from dataclasses import dataclass, field

import faiss
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from icde_lab.datasets import initial_split, load_ann_benchmark   # noqa: E402
from icde_lab.drift import build_plan                             # noqa: E402
from icde_lab.indexes import AnnIndex                             # noqa: E402
from icde_lab.logio import dump_json                              # noqa: E402
from icde_lab.truth import ExactKNN, recall_at_k                  # noqa: E402
from exp_t1_audit import hypergeom_lower, hypergeom_upper                          # noqa: E402

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
EF_GRID = [16, 32, 64, 128, 256]


def eb_upper(k: int, m: int, delta: float) -> float:
    if m == 0:
        return 1.0
    phat = k / m
    lt = np.log(2.0 / delta)
    hw = np.sqrt(2.0 * phat * (1 - phat) * lt / m) + 7.0 * lt / (3.0 * max(m - 1, 1))
    return float(min(1.0, phat + hw))


@dataclass
class Round:
    t: int
    ntotal: int
    n_deleted: int
    audit_m: int = 0
    f_hat: dict = field(default_factory=dict)      # ef -> estimated F
    f_ub: dict = field(default_factory=dict)       # ef -> upper bound
    f_true: float = float("nan")                   # held-out realised F at chosen ef
    action: str = "none"
    verdict: str = "none"
    ef: int = 64            # the effort the NEXT epoch will be served at
    ef_served: int = 64     # the effort this epoch was served at (what the certificate covers)
    ef_next: int = 64
    ef_verified: int = 64   # where the held-out measurement was taken (== ef_served)
    n_arrivals: int = 0     # |epoch| = the hypergeometric population N
    pre_rebuild: bool = False  # this epoch's truth was measured before the rebuild it triggered
    rebuild_s: float = 0.0
    latency_ms: float = float("nan")
    certified: bool = False


def choose_ef_under_contract(f_hat, f_ub, phi, ef_prev, lat):
    """Cheapest ef whose upper bound is <= phi; else the ef with the smallest bound."""
    ok = [ef for ef in sorted(f_ub) if f_ub[ef] <= phi]
    if ok:
        return ok[0], True
    return min(f_ub, key=lambda e: f_ub[e]), False


def run(ds, args, policy: str, tag: str):
    base0, incoming = initial_split(ds, args.n_base, seed=args.seed)
    plan = build_plan(incoming, ds.test, args.rounds, args.batch, args.nq, family=args.drift, seed=args.seed)
    rng = np.random.default_rng(args.seed + 101)
    idx = AnnIndex(ds.dim, ds.metric, args.family, M=args.M, ef_construction=args.ef_construction,
                   ef_search=args.ef0, nlist=args.nlist).build(base0)
    exact = ExactKNN(ds.dim, ds.metric).reset_with(base0)
    ref_F = None            # calibrated post-rebuild F (from the last audit after a rebuild)
    ef_cur = args.ef0
    inserts_since = 0
    last_rebuild = -10**9
    rounds: list[Round] = []
    t_start = time.perf_counter()

    for t, rp in enumerate(plan):
        if rp.inserts is not None and len(rp.inserts):
            idx.add(rp.inserts)
            exact.add(rp.inserts)
            inserts_since += len(rp.inserts)
        if rp.delete_frac > 0:
            idx.remove(rp.delete_frac, rng)
            exact.set_dead(idx.dead)

        # ---- audit: m random arriving queries, exact top-k once, recall at every ef for free
        q_all = np.concatenate([rp.q_old, rp.q_new], axis=0)
        perm = rng.permutation(len(q_all))
        n_aud = min(args.audit_m, len(q_all) // 2)
        a_idx, v_idx = perm[:n_aud], perm[n_aud:]
        if args.audit_frame == "new":
            pool = rp.q_new if len(rp.q_new) else rp.q_old
            sel = rng.choice(len(pool), size=min(args.audit_m, len(pool)), replace=False)
            qa = pool[sel]
        elif args.audit_frame == "old":
            pool = rp.q_old
            sel = rng.choice(len(pool), size=min(args.audit_m, len(pool)), replace=False)
            qa = pool[sel]
        else:
            qa = q_all[a_idx]
        m = len(qa)
        truth = exact.knn(qa, args.k)
        rec_by_ef, lat_by_ef = {}, {}
        for ef in EF_GRID:
            found, _, lat = idx.search_ef(qa, args.k, ef)
            rec_by_ef[ef] = recall_at_k(found, truth, args.k)
            lat_by_ef[ef] = lat * 1e3
        r = Round(t=t, ntotal=idx.ntotal, n_deleted=int(len(idx.dead)), audit_m=m)
        r.f_hat = {ef: float(np.mean(rec_by_ef[ef] < args.tau)) for ef in EF_GRID}
        delta_w = args.delta * 6.0 / (np.pi ** 2 * (t + 1) ** 2)
        r.f_ub = {ef: eb_upper(int(np.sum(rec_by_ef[ef] < args.tau)), m, delta_w) for ef in EF_GRID}
        # ---- three-way verdict at the *served* configuration
        # ef_served is the effort in force while this epoch's arrivals were answered; the
        # action chosen below applies to the NEXT epoch, so the certificate and the held-out
        # measurement both use ef_served and the two describe the same object. The level is
        # alpha_w/2 for the two decisions and /|E| because the controller may pick the point
        # from this same audit (paper, Algorithm 1 and the third scoping remark).
        ef_served = ef_cur
        level = delta_w / 2.0 / len(EF_GRID)
        k_cur = int(np.sum(rec_by_ef[ef_served] < args.tau))
        N_cur = len(q_all)                      # the epoch's arriving population
        u_cur = hypergeom_upper(k_cur, m, N_cur, level)
        l_cur = hypergeom_lower(k_cur, m, N_cur, level)
        if os.environ.get("T3_DEBUG"):
            print("DBG t=%d ef_served=%d k=%d m=%d N=%d level=%.6f U=%.4f L=%.4f" % (
                t, ef_served, k_cur, m, N_cur, level, u_cur, l_cur), flush=True)
        # Compare *counts*, not rates: K^+/N <= phi  <=>  K^+ <= phi*N. Integer comparisons
        # cannot be flipped by floating-point error, so an epoch whose exact limit lands
        # exactly on phi is decided identically every time (the boundary tie the review asked
        # about).
        cap = int(np.floor(args.phi * N_cur + 1e-9))
        K_up, K_lo = int(round(u_cur * N_cur)), int(round(l_cur * N_cur))
        r.verdict = ("pass" if K_up <= cap else
                     ("reject" if K_lo > cap else "undetermined"))
        # NOTE on what is certified: `verdict` is the exact finite-population certificate of
        # the paper's Algorithm 1, taken at the operating point in force for this epoch. When a
        # controller chooses that point from the same audit (ef_auto, ctrl*), the level must be
        # additionally split over the candidate grid; `args.ef0` is used here because the
        # action only takes effect for the *next* epoch, so the certificate reported for the
        # epoch reflects the point actually served. `r.certified` below is the controller's
        # SCREENING decision (empirical Bernstein), not a certificate: the paper states this
        # distinction explicitly and no action inherits the theorem until a later audit passes.

        # ---- policy
        action, rebuild_s = "none", 0.0
        if policy == "never":
            pass
        elif policy.startswith("periodic_"):
            k = int(policy.split("_")[1])
            if (t + 1) % k == 0:
                action = "rebuild"   # applied after the held-out measurement, below
        elif policy.startswith("count_"):
            n = int(policy.split("_")[1])
            if inserts_since >= n:
                action = "rebuild"   # applied after the held-out measurement, below
                inserts_since = 0
        elif policy == "ef_auto":
            ef_cur, _ = choose_ef_under_contract(r.f_hat, r.f_ub, args.phi, ef_cur, lat_by_ef)
            action = "ef"
        elif policy == "ctrl_mean":
            # the ablation that matters: same controller, but it believes a mean SLA
            rec_aud = np.concatenate([rec_by_ef[64]])          # audited recalls at the default ef
            m_aud = len(rec_aud)
            lb_mean = float(rec_aud.mean() - 1.645 * rec_aud.std(ddof=1) / np.sqrt(max(m_aud, 2)))
            r.certified = bool(lb_mean >= args.tau)
            if not r.certified:
                ef_best, ok = choose_ef_under_contract(r.f_hat, r.f_ub, args.phi, ef_cur, lat_by_ef)
                if ok:
                    action, ef_cur = "ef", ef_best
                elif (t - last_rebuild) >= args.cooldown:
                    action = "rebuild"   # applied after the held-out measurement, below
                    ef_cur, inserts_since, last_rebuild = args.ef0, 0, t
        elif policy in ("ctrl", "ctrl_rebuild"):
            ef_best, ok = choose_ef_under_contract(r.f_hat, r.f_ub, args.phi, ef_cur, lat_by_ef)
            r.certified = ok
            if ok:
                if ef_best != ef_cur:
                    action, ef_cur = "ef", ef_best
            elif policy == "ctrl_rebuild":
                # latency lever exhausted: is a rebuild worth it? Only if the projected
                # post-rebuild bound passes AND the cooldown elapsed (no rebuild storms).
                projected = ref_F if ref_F is not None else 0.5 * (1.0 - np.mean(list(r.f_hat.values())))
                proj_ub = eb_upper(int(round(projected * m)), m, delta_w)
                cooldown_ok = (t - last_rebuild) >= args.cooldown
                if proj_ub <= args.phi and cooldown_ok:
                    action = "rebuild"   # applied after the held-out measurement, below
                    ef_cur = args.ef0
                    inserts_since = 0
                    last_rebuild = t
            if ef_best != ef_cur and action == "none":
                action, ef_cur = "ef", ef_best

        # ---- held-out verification, taken BEFORE the policy mutates anything.
        # The certificate above describes the index/effort that served this epoch; measuring
        # here (before ef changes and before a rebuild) keeps the realized rate on the same
        # object. An earlier version measured after the action, which made a rebuild epoch
        # compare a pre-rebuild certificate with a post-rebuild truth.
        qv = q_all[v_idx] if args.audit_frame == "mixed" else q_all
        truth_v = exact.knn(qv, args.k)
        prev_threads = faiss.omp_get_max_threads()
        faiss.omp_set_num_threads(1)
        found_v, _, lat_v = idx.search_ef(qv, args.k, ef_served)
        faiss.omp_set_num_threads(prev_threads)
        rec_v = recall_at_k(found_v, truth_v, args.k)
        r.f_true = float(np.mean(rec_v < args.tau))
        r.latency_ms = lat_v * 1e3
        r.ef_served, r.ef_verified = ef_served, ef_served
        r.n_arrivals = int(N_cur)
        r.pre_rebuild = action == "rebuild"
        rounds.append(r)

        # ---- only now does the policy take effect, for the next epoch
        if action == "rebuild":
            idx.rebuild()
            rebuild_s = idx.stats.rebuild_s
            exact.reset_with(idx.live_matrix())
            ref_F = r.f_true
        r.action, r.ef = action, ef_cur
        r.ef_next = ef_cur
        r.rebuild_s = rebuild_s

    out = {
        "policy": policy, "tag": tag, "dataset": ds.name, "drift": args.drift,
        "tau": args.tau, "phi": args.phi, "delta": args.delta, "audit_m": args.audit_m,
        "wall_s": time.perf_counter() - t_start,
        "rounds": [r.__dict__ for r in rounds],
        "summary": {
            "violation_rounds": int(sum(r.f_true > args.phi for r in rounds)),
            "n_rounds": len(rounds),
            "violation_rate": float(np.mean([r.f_true > args.phi for r in rounds])),
            "n_rebuilds": int(sum(r.action == "rebuild" for r in rounds)),
            "rebuild_s": float(sum(r.rebuild_s for r in rounds)),
            "mean_latency_ms": float(np.nanmean([r.latency_ms for r in rounds])),
            "mean_f_true": float(np.nanmean([r.f_true for r in rounds])),
            # A certification is the exact verdict (Algorithm 1's PASS), not the heuristic
            # screening flag used to choose the action. Keeping them in separate counters is
            # what stops a screening pass from being reported as a statistical certification.
            "false_cert": int(sum(r.verdict == "pass" and r.f_true > args.phi for r in rounds)),
            "cert_rounds": int(sum(r.verdict == "pass" for r in rounds)),
            "screening_passes": int(sum(r.certified for r in rounds)),
            "screening_false_passes": int(sum(r.certified and r.f_true > args.phi for r in rounds)),
            "verdicts": {v: int(sum(r.verdict == v for r in rounds))
                         for v in ("pass", "reject", "undetermined")},
            "verdicts_violating": {v: int(sum(r.verdict == v and r.f_true > args.phi for r in rounds))
                                   for v in ("pass", "reject", "undetermined")},
        },
    }
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="sift-128-euclidean.hdf5")
    ap.add_argument("--tag", default="sift")
    ap.add_argument("--drift", default="churn")
    ap.add_argument("--policies", default="never,periodic_5,count_400000,ef_auto,ctrl")
    ap.add_argument("--n-base", type=int, default=600_000)
    ap.add_argument("--batch", type=int, default=20_000)
    ap.add_argument("--rounds", type=int, default=12)
    ap.add_argument("--nq", type=int, default=400)
    ap.add_argument("--k", type=int, default=10)
    ap.add_argument("--M", type=int, default=32)
    ap.add_argument("--ef-construction", type=int, default=200)
    ap.add_argument("--ef0", type=int, default=64)
    ap.add_argument("--tau", type=float, default=0.95)
    ap.add_argument("--phi", type=float, default=0.05)
    ap.add_argument("--delta", type=float, default=0.05)
    ap.add_argument("--audit-m", type=int, default=200)
    ap.add_argument("--audit-frame", default="mixed", choices=["mixed", "new", "old"])
    ap.add_argument("--family", default="hnsw", choices=["hnsw", "ivfflat", "ivfpq"])
    ap.add_argument("--nlist", type=int, default=512)
    ap.add_argument("--cooldown", type=int, default=3, help="min epochs between rebuilds")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    ds = load_ann_benchmark(a.data)
    outdir = os.path.join(REPO, "reports", "t3")
    os.makedirs(outdir, exist_ok=True)
    results = []
    for pol in a.policies.split(","):
        t0 = time.perf_counter()
        res = run(ds, a, pol, a.tag)
        results.append(res)
        s = res["summary"]
        print(f"[{pol:14s}] {time.perf_counter()-t0:6.1f}s viol={s['violation_rounds']}/{s['n_rounds']} "
              f"rebuilds={s['n_rebuilds']} rebuild_s={s['rebuild_s']:6.1f} "
              f"lat={s['mean_latency_ms']:6.3f}ms false_cert={s['false_cert']} cert={s['cert_rounds']} "
              f"screen={s['screening_passes']}({s['screening_false_passes']} false)", flush=True)
        dump_json(os.path.join(outdir, f"t3_{a.tag}_{a.drift}_{pol}_s{a.seed}.json"), res)
    dump_json(os.path.join(outdir, f"t3_{a.tag}_{a.drift}_all_s{a.seed}.json"), results)
    print("[done]", flush=True)


if __name__ == "__main__":
    main()
