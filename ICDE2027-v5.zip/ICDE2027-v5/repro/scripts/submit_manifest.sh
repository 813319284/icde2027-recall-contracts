#!/usr/bin/env bash
# Submission receipt: prove that the PDF you upload is the PDF that passed the checks.
#
#   bash scripts/submit_manifest.sh          # print the receipt
#   bash scripts/submit_manifest.sh > relay/SUBMISSION_RECEIPT.txt
#
# Run it immediately before uploading to CMT, and keep the output next to the PDF.
set -uo pipefail
HERE=$(cd "$(dirname "$0")/.." && pwd)
# locate the project root: in the working tree it is the parent of scripts/, in a delivered
# archive the scripts sit under repro/ with paper/ at the archive root
ROOT=$HERE
for cand in "$HERE" "$(dirname "$HERE")" "$(dirname "$(dirname "$HERE")")"; do
  if [ -e "$cand/paper/main.tex" ]; then ROOT=$cand; break; fi
done
cd "$ROOT"
PDF=paper/build/main.pdf

if [ ! -f "$PDF" ]; then
  echo "no PDF at $PDF — run bash scripts/build_paper.sh first" >&2
  exit 1
fi

echo "== submission receipt =="
echo "generated      : $(date -Is)"
echo "pdf path       : $PDF"
echo "pdf sha256     : $(sha256sum "$PDF" | cut -d' ' -f1)"
echo "pdf bytes      : $(stat -c%s "$PDF")"
echo "pdf modified   : $(date -Is -r "$PDF")"
echo "pdf pages      : $(pdfinfo "$PDF" | awk '/^Pages:/{print $2}')"
echo "page size      : $(pdfinfo "$PDF" | awk '/Page size:/{print $3" x "$5" points"}')"
if [ -f paper/build/SOURCE_HASH ]; then
  echo "source hash    : $(cat paper/build/SOURCE_HASH)   (hash of main.tex+refs.bib+figures at build time)"
else
  echo "source hash    : MISSING — rebuild with scripts/build_paper.sh"
fi
echo "current source : $(cd paper && { sha256sum main.tex refs.bib; find figures -name '*.pdf' 2>/dev/null | sort | xargs -r sha256sum; } | sha256sum | cut -d' ' -f1)   (same recipe, hashed right now)"
echo
echo "== gate =="
python3 scripts/check_numbers.py | head -1
python3 scripts/check_prose_numbers.py --strict | head -1
python3 scripts/preflight.py | grep -E '^\[(✓|✗)\] (author block|paper states|CMT abstract|body pages)|checks passed' || true
echo
echo "If 'source hash' equals 'current source', the PDF was built from the sources you have now."
echo "Compare 'pdf sha256' with the file you upload; if they differ, you are uploading something else."
