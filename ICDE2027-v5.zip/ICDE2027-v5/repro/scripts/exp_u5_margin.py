#!/usr/bin/env python3
"""U5: is the violating query identifiable *before* the audit?

If tail violations were exchangeable noise, the only lever on an audit budget would be its
size. If they are predictable from the ANN response itself---which the service already has,
for free, before it decides to audit---then the budget can be *allocated* instead of merely
spent, and the contract gets cheaper without weakening the certificate.

The candidate score is the distance margin of the returned list: a query whose 10th
neighbour sits far from its 1st is one where the search had to reach, i.e. one whose recall
is fragile. Everything here is computed from the distances the index returned, so no ground
truth is touched when scoring.

Outputs (reports/u5/):
  margin_<tag>.json   AUC of each score, violation rate by score decile, per-ef numbers
  margin_<tag>.npz    (score, violated, recall, round) for the stratified-certificate study

    python3 scripts/exp_u5_margin.py --tag sift --n-base 200000 --nq 4000
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import faiss
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from icde_lab.datasets import load_ann_benchmark   # noqa: E402
from icde_lab.logio import dump_json               # noqa: E402

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))


def auc(score: np.ndarray, label: np.ndarray) -> float:
    """Rank AUC (Mann-Whitney), no sklearn dependency."""
    pos, neg = score[label], score[~label]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    order = np.argsort(np.concatenate([pos, neg]))
    ranks = np.empty(len(order), dtype=float)
    ranks[order] = np.arange(1, len(order) + 1)
    r_pos = ranks[:len(pos)].sum()
    return float((r_pos - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg)))


def build_and_probe(ds, args, round_id: int, seed: int):
    rng = np.random.default_rng(seed + round_id)
    base_idx = rng.permutation(len(ds.train))[:args.n_base]
    base = np.ascontiguousarray(ds.train[np.sort(base_idx)])
    flat = faiss.IndexFlatL2(ds.dim)
    flat.add(base)
    hnsw = faiss.IndexHNSWFlat(ds.dim, args.m)
    hnsw.hnsw.efConstruction = args.efc
    hnsw.add(base)

    q = ds.test[rng.choice(len(ds.test), size=args.nq, replace=False)]
    _, Iex = flat.search(np.ascontiguousarray(q), args.k)
    rows = []
    for ef in args.efs:
        hnsw.hnsw.efSearch = ef
        D, I = hnsw.search(np.ascontiguousarray(q), args.k)
        rec = np.array([len(set(I[i]) & set(Iex[i])) / args.k for i in range(len(q))])
        d1, dk = D[:, 0], D[:, -1]
        eps = 1e-9
        scores = {
            "spread": (dk - d1) / np.maximum(d1, eps),      # relative spread of the list
            "ratio": dk / np.maximum(d1, eps),              # classic margin ratio
            "abs_dk": dk,                                   # absolute radius
            "gap_tail": (dk - D[:, -2]) / np.maximum(D[:, -2], eps),  # tail gap
        }
        for name, s in scores.items():
            rows.append({"round": round_id, "ef": ef, "score_name": name,
                         "score": s, "recall": rec, "violated": rec < args.tau})
    return rows


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="sift-128-euclidean.hdf5")
    ap.add_argument("--tag", default="sift")
    ap.add_argument("--n-base", type=int, default=200_000)
    ap.add_argument("--nq", type=int, default=4000)
    ap.add_argument("--k", type=int, default=10)
    ap.add_argument("--m", type=int, default=16)
    ap.add_argument("--efc", type=int, default=64)
    ap.add_argument("--efs", type=int, nargs="+", default=[32, 64])
    ap.add_argument("--tau", type=float, default=0.95)
    ap.add_argument("--rounds", type=int, default=3, help="independent base draws (round 0 = fresh)")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    ds = load_ann_benchmark(a.data)
    out = {}
    store = {}
    for r in range(a.rounds):
        for row in build_and_probe(ds, a, r, a.seed):
            key = (r, row["ef"], row["score_name"])
            store[key] = (row["score"], row["violated"], row["recall"])
            if r == 0:
                out.setdefault(f"ef{row['ef']}", {})[row["score_name"]] = {
                    "auc": auc(row["score"], row["violated"]),
                    "violation_rate": float(row["violated"].mean()),
                }
    # deciles of the best score at each ef (round 0)
    deciles = {}
    for ef in a.efs:
        name = max(out[f"ef{ef}"], key=lambda n: out[f"ef{ef}"][n]["auc"])
        s, v, _ = store[(0, ef, name)]
        order = np.argsort(-s)                    # highest score first = most at risk
        buckets = np.array_split(order, 10)
        rates = [float(v[b].mean()) for b in buckets]
        deciles[f"ef{ef}"] = {"score": name, "violation_by_decile_high_to_low": rates,
                              "top_bottom_decile_ratio": float(rates[0] / rates[-1]) if rates[-1] else None,
                              "top_decile_rate": rates[0], "bottom_decile_rate": rates[-1]}
    payload = {"dataset": ds.name, "tag": a.tag, "n_base": a.n_base, "nq": a.nq,
               "tau": a.tau, "per_ef": out, "deciles": deciles,
               "rounds": a.rounds}
    os.makedirs(os.path.join(REPO, "reports", "u5"), exist_ok=True)
    dump_json(os.path.join(REPO, "reports", "u5", f"margin_{a.tag}.json"), payload)
    # arrays for the stratified-certificate study: best score per ef, all rounds
    npz = {}
    for ef in a.efs:
        name = max(out[f"ef{ef}"], key=lambda n: out[f"ef{ef}"][n]["auc"])
        sc = np.concatenate([store[(r, ef, name)][0] for r in range(a.rounds)])
        vi = np.concatenate([store[(r, ef, name)][1] for r in range(a.rounds)])
        rd = np.concatenate([np.full(len(store[(r, ef, name)][0]), r) for r in range(a.rounds)])
        npz[f"score_ef{ef}"] = sc
        npz[f"recall_ef{ef}"] = np.concatenate([store[(r, ef, name)][2] for r in range(a.rounds)])
        npz[f"viol_ef{ef}"] = vi
        npz[f"round_ef{ef}"] = rd
    np.savez_compressed(os.path.join(REPO, "reports", "u5", f"margin_{a.tag}.npz"), **npz)

    print(json.dumps({"per_ef": out, "deciles": deciles}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
