#!/usr/bin/env bash
# Deterministic build of the supplementary document.
#
# Mirrors scripts/build_paper.sh for the same reason it exists: the shared tex.py wrapper
# can report success while reusing a stale PDF (DECISIONS D006). Here we stage the source
# into supp/build/, run pdflatex twice, and assert that the run actually succeeded and that
# the tables it \inputs were generated from current artifacts.
set -euo pipefail
HERE=$(cd "$(dirname "$0")/.." && pwd)
# locate the project root: in the working tree it is the parent of scripts/, in a delivered
# archive the scripts sit under repro/ with paper/ at the archive root
ROOT=$HERE
for cand in "$HERE" "$(dirname "$HERE")" "$(dirname "$(dirname "$HERE")")"; do
  if [ -e "$cand/paper/main.tex" ]; then ROOT=$cand; break; fi
done
SRC="$ROOT/supp"
[ -d "$SRC" ] || SRC="$ROOT/supplementary"      # the archive calls it supplementary/
B="$SRC/build"

python3 "$HERE/scripts/make_supp_tables.py"

rm -rf "$B"; mkdir -p "$B"
cp "$SRC/supplement.tex" "$B"/
cp -r "$SRC/tables" "$B"/

cd "$B"
export SOURCE_DATE_EPOCH=${SOURCE_DATE_EPOCH:-1757484000}
export FORCE_SOURCE_DATE=1
pdflatex -interaction=nonstopmode -halt-on-error supplement.tex >/dev/null
pdflatex -interaction=nonstopmode -halt-on-error supplement.tex >/dev/null

errors=$(grep -c '^!' supplement.log || true)
unresolved=$(grep -c "Reference.*undefined\|Citation.*undefined" supplement.log || true)
pages=$(pdfinfo supplement.pdf | awk '/^Pages:/{print $2}')
echo "supplement pages=$pages  latex_errors=$errors  unresolved=$unresolved"
if [ "$errors" -ne 0 ] || [ "$unresolved" -ne 0 ]; then
  echo "SUPPLEMENT BUILD FAILED" >&2
  grep -m5 '^!' supplement.log >&2 || true
  exit 1
fi
echo "ok: $B/supplement.pdf"
