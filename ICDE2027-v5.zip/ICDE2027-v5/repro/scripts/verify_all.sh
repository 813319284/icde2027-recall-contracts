#!/usr/bin/env bash
# Full verification sweep. Eleven layers, one command, one summary line per layer.
#
#   bash "$SCR"/verify_all.sh
#
# Exit code 0 = every layer green (except the known "author block pending" item,
# which is reported as PENDING rather than FAIL because only the PI can clear it).
set -uo pipefail
HERE=$(cd "$(dirname "$0")/.." && pwd)
# locate the project root: in the working tree it is the parent of scripts/, in a delivered
# archive the scripts sit under repro/ with paper/ at the archive root
ROOT=$HERE
for cand in "$HERE" "$(dirname "$HERE")" "$(dirname "$(dirname "$HERE")")"; do
  if [ -e "$cand/paper/main.tex" ]; then ROOT=$cand; break; fi
done
# the scripts live in $ROOT/scripts in the working tree and in $ROOT/repro/scripts in the
# delivery archive; resolve once so every layer works in both
SCR="$ROOT/scripts"
[ -d "$ROOT/repro/scripts" ] && SCR="$ROOT/repro/scripts"
cd "$ROOT"
fail=0

line() { printf '%-34s %s\n' "$1" "$2"; }

# 1 build
if out=$(bash "$ROOT/repro/scripts/build_paper.sh" 2>&1 || bash "$ROOT/scripts/build_paper.sh" 2>&1); then
  line "1 build" "PASS  $(echo "$out" | grep -o 'bibitems=[0-9]*  unresolved_citations=[0-9]*' | head -1)"
else
  line "1 build" "FAIL"; echo "$out" | tail -3; fail=1
fi

# 2 table cells
if out=$(python3 "$SCR"/check_numbers.py 2>&1); then
  line "2 table cells" "PASS  $(echo "$out" | head -1)"
else
  line "2 table cells" "FAIL"; echo "$out" | tail -3; fail=1
fi

# 3 prose numbers
if out=$(python3 "$SCR"/check_prose_numbers.py --strict 2>&1); then
  line "3 prose numbers" "PASS  $(echo "$out" | head -1)"
else
  line "3 prose numbers" "FAIL"; echo "$out" | tail -3; fail=1
fi

# 4 preflight (extract the one allowed pending item; a crashed checker is a FAIL)
out=$(python3 "$SCR"/preflight.py 2>&1); rc=$?
summary=$(echo "$out" | grep 'checks passed')
if [ -z "$summary" ]; then
  line "4 preflight" "FAIL  checker exited $rc"; echo "$out" | tail -3; fail=1
else
  others=$(echo "$out" | grep '^\[✗\]' | grep -vc 'author block')
  if [ "$others" -eq 0 ] && echo "$out" | grep -q '^\[✗\] author block filled in'; then
    line "4 preflight" "PENDING author block  ($summary)"
  elif [ "$others" -ne 0 ]; then
    line "4 preflight" "FAIL  $summary"; echo "$out" | grep '^\[✗\]'; fail=1
  elif [ "$rc" -ne 0 ]; then
    line "4 preflight" "FAIL  $summary (exit $rc)"; fail=1
  else
    line "4 preflight" "PASS  $summary"
  fi
fi

# 5 core primitive coverage
if out=$(python3 "$SCR"/exp_bound_coverage.py 2>&1); then
  line "5 bound coverage" "PASS  $(echo "$out" | tail -1 | cut -c1-60)"
else
  line "5 bound coverage" "FAIL"; fail=1
fi

# 6 page geometry
pages=$(pdfinfo paper/build/main.pdf | awk '/Pages:/{print $2}')
size=$(pdfinfo paper/build/main.pdf | awk '/Page size:/{print $3" x "$5" pts"}')
line "6 page geometry" "INFO  ${pages} pages, ${size}"

# 7 PDF hygiene
raw_hits=$(strings paper/build/main.pdf | grep -cE "/home/|/opt/volume|sorryios|172\.28\." || true)
attachments=$(pdfdetach -list paper/build/main.pdf 2>/dev/null | head -1)
if [ "$raw_hits" -eq 0 ]; then
  line "7 pdf hygiene" "PASS  no path/host leak, ${attachments}"
else
  line "7 pdf hygiene" "FAIL  ${raw_hits} suspicious strings"; fail=1
fi

# 8 documentation consistency (counts quoted in relay docs vs reality)
cells=$(python3 "$SCR"/check_numbers.py 2>/dev/null | grep -o 'checked [0-9]*' | awk '{print $2}')
stale=$(grep -rl "220 项\|430 个散文\|bibitems=21 " README.md relay/*.md 2>/dev/null | head -3)
if [ -z "$stale" ]; then
  line "8 docs consistent" "PASS  (${cells} cells quoted consistently)"
else
  line "8 docs consistent" "WARN  stale counts in: ${stale}"; fail=1
fi

# 9 artifact provenance
if [ -f paper/build/SOURCE_HASH ]; then
  line "9 provenance" "PASS  source hash $(cut -c1-12 paper/build/SOURCE_HASH)"
else
  line "9 provenance" "FAIL  missing SOURCE_HASH"; fail=1
fi

# 10 template conformance (IEEE conference template 062824)
if out=$(python3 "$SCR"/check_template.py 2>&1); then
  line "10 template" "PASS  $(echo "$out" | tail -1)"
else
  line "10 template" "FAIL  $(echo "$out" | tail -1)"; echo "$out" | grep '^\[✗\]'; fail=1
fi

# 11 disk headroom
avail=$(df -h / | awk 'NR==2{print $4}')
line "11 disk headroom" "INFO  root ${avail} free"

echo
if [ "$fail" -ne 0 ]; then
  echo "SOME LAYERS FAILED — do not submit"
elif echo "$out" | grep -q 'author block'; then
  echo "ALL LAYERS OK (author block still pending on the PI)"
else
  echo "ALL LAYERS OK (submit-ready: ${summary:-11 layers, see layer 4})"
fi
exit "$fail"
