#!/usr/bin/env python3
"""S0: does recall silently decay under content growth + query drift?

Arms (maintenance policies):
  none        append only, never rebuild            (what most deployments do)
  rebuild_all rebuild after every round             (cost upper bound)
  rebuild_h    rebuild at round h/2 and h            (periodic-rebuild strawman)

Outputs
  reports/s0/perquery_<tag>.jsonl   one record per query (replayable)
  reports/s0/summary_<tag>.json     per-round aggregates + cost accounting
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from dataclasses import asdict

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from icde_lab.datasets import initial_split, load_ann_benchmark          # noqa: E402
from icde_lab.drift import build_plan                                    # noqa: E402
from icde_lab.indexes import AnnIndex                                    # noqa: E402
from icde_lab.logio import JsonlWriter, dump_json                        # noqa: E402
from icde_lab.truth import ExactKNN, recall_at_k                         # noqa: E402

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))


def run_arm(arm: str, ds, base0, incoming, plan, args):
    idx = AnnIndex(ds.dim, ds.metric, family=args.family, M=args.M,
                   ef_construction=args.ef_construction, ef_search=args.ef_search,
                   nlist=args.nlist, nprobe=args.nprobe)
    exact = ExactKNN(ds.dim, ds.metric)
    rng = np.random.default_rng(args.seed + 7)
    idx.build(base0)
    exact.reset_with(base0)
    records, rounds = [], []
    t_start = time.perf_counter()

    for t, rp in enumerate(plan):
        if rp.inserts is not None and len(rp.inserts):
            idx.add(rp.inserts)
            exact.add(rp.inserts)
        if rp.delete_frac > 0:
            idx.remove(rp.delete_frac, rng)
            exact.set_dead(idx.dead)
        do_rebuild = (arm == "rebuild_all") or (arm == "rebuild_h" and t + 1 in (len(plan) // 2, len(plan)))
        if do_rebuild:
            idx.rebuild()

        for fam, q, cl in (("old", rp.q_old, rp.cluster_old), ("new", rp.q_new, rp.cluster_new)):
            if q is None or len(q) == 0:
                continue
            truth = exact.knn(q, args.k)
            found, dist, lat = idx.search(q, args.k)
            rec = recall_at_k(found, truth, args.k)
            for i in range(len(q)):
                records.append({
                    "arm": arm, "round": t, "family": fam, "qid": int(i),
                    "cluster": int(cl[i]) if cl is not None else -1,
                    "recall": float(rec[i]), "latency_ms": lat * 1e3,
                    "top1_dist": float(dist[i][0]) if np.isfinite(dist[i][0]) else -1.0,
                })
            rounds.append({
                "round": t, "family": fam, "n": int(len(q)),
                "recall_mean": float(np.nanmean(rec)), "recall_p05": float(np.nanpercentile(rec, 5)),
                "recall_median": float(np.nanmedian(rec)),
                "ntotal": idx.ntotal, "latency_ms": lat * 1e3,
            })
        rounds.append({"round": t, "family": "meta", "ntotal": idx.ntotal,
                       "n_inserted": idx.stats.n_inserted, "n_rebuilds": idx.stats.n_rebuilds,
                       "wall_s": time.perf_counter() - t_start})

    summary = {
        "arm": arm, "dataset": ds.name, "family": args.family, "k": args.k,
        "n_base": int(len(base0)), "batch": args.batch, "rounds": len(plan),
        "M": args.M, "ef_construction": args.ef_construction, "ef_search": args.ef_search,
        "stats": asdict(idx.stats), "drift": args.drift, "per_round": rounds,
    }
    return records, summary


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="sift-128-euclidean.hdf5")
    ap.add_argument("--tag", default="sift")
    ap.add_argument("--family", default="hnsw")
    ap.add_argument("--arms", default="none,rebuild_all,rebuild_h")
    ap.add_argument("--n-base", type=int, default=800_000)
    ap.add_argument("--batch", type=int, default=20_000)
    ap.add_argument("--rounds", type=int, default=10)
    ap.add_argument("--nq", type=int, default=500)
    ap.add_argument("--k", type=int, default=10)
    ap.add_argument("--M", type=int, default=32)
    ap.add_argument("--ef-construction", type=int, default=200)
    ap.add_argument("--ef-search", type=int, default=64)
    ap.add_argument("--nlist", type=int, default=1024)
    ap.add_argument("--nprobe", type=int, default=16)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--tau", type=float, default=0.95)
    ap.add_argument("--ef-sweep", default="0", help="comma list of ef_search values; 0 = default only")
    ap.add_argument("--drift", default="append",
                    choices=["append", "churn", "query_shift", "model_shift"])
    ap.add_argument("--delete-frac", type=float, default=0.02)
    args = ap.parse_args()
    args.ef_sweep = [int(v) for v in str(args.ef_sweep).split(",") if v != ""]

    ds = load_ann_benchmark(args.data)
    print(f"[data] {ds.name} train={ds.train.shape} test={ds.test.shape} metric={ds.metric}", flush=True)
    base0, incoming = initial_split(ds, args.n_base, seed=args.seed)
    plan = build_plan(incoming, ds.test, args.rounds, args.batch, args.nq,
                      family=args.drift, seed=args.seed, delete_frac=args.delete_frac)

    outdir = os.path.join(REPO, "reports", "s0")
    os.makedirs(outdir, exist_ok=True)
    all_sum = []
    for arm in args.arms.split(","):
        t0 = time.perf_counter()
        recs, summ = run_arm(arm, ds, base0, incoming, plan, args)
        tag = f"{args.tag}_{args.family}_{arm}"
        with JsonlWriter(os.path.join(outdir, f"perquery_{tag}.jsonl")) as w:
            w.write_many(recs)
        dump_json(os.path.join(outdir, f"summary_{tag}.json"), summ)
        all_sum.append({"arm": arm, **{k: summ[k] for k in ("dataset", "family", "n_base", "stats")}})
        # console: the headline numbers
        agg = {}
        for r in summ["per_round"]:
            if r["family"] in ("old", "new"):
                agg.setdefault(r["family"], []).append(round(r["recall_mean"], 4))
        print(f"[{arm}] {time.perf_counter()-t0:.1f}s  recall old={agg.get('old')}  new={agg.get('new')}", flush=True)

    dump_json(os.path.join(outdir, f"summary_{args.tag}_all.json"), {"runs": all_sum, "args": vars(args)})
    print("[done]", flush=True)


if __name__ == "__main__":
    main()
