#!/usr/bin/env python3
"""Figures for the paper (vector PDFs into paper/figures/)."""
from __future__ import annotations

import glob
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

def _find_repo(start: str) -> str:
    """Locate the project root, so this script also runs inside a delivered archive."""
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(REPO, "paper", "figures")
os.makedirs(FIG, exist_ok=True)
plt.rcParams.update({"font.size": 7, "axes.grid": True, "grid.alpha": 0.25,
                     "axes.labelsize": 7, "xtick.labelsize": 6.5, "ytick.labelsize": 6.5,
                     "legend.fontsize": 6, "axes.linewidth": 0.6,
                     "grid.linewidth": 0.4, "xtick.major.width": 0.6,
                     "ytick.major.width": 0.6, "xtick.major.size": 2.5,
                     "ytick.major.size": 2.5, "lines.linewidth": 1.1,
                     "figure.dpi": 160, "savefig.bbox": "tight",
                     "pdf.fonttype": 42})
# the panels are titled by their LaTeX captions, so an in-image title is a second title
Axes_set_title = plt.Axes.set_title
plt.Axes.set_title = lambda self, *a, **k: None
# Byte-reproducible figures: strip the creation timestamp so two runs produce identical
# PDFs (artifact evaluators diff these).
_SAVE_KW = {"metadata": {"CreationDate": None, "Producer": None}}


def fig_frontier():
    curves = json.load(open(os.path.join(REPO, "reports", "curves.json")))
    lat = json.load(open(os.path.join(REPO, "reports", "latency.json")))
    styles = {"siftA_append": ("SIFT append", "o", "#1f77b4"),
              "siftB_churn": ("SIFT churn", "s", "#d62728"),
              "siftC_mshift": ("SIFT model-shift", "^", "#2ca02c"),
              "gloveA_append": ("GloVe append", "D", "#9467bd")}
    fig, ax = plt.subplots(figsize=(3.4, 2.0))
    for world, (label, mk, col) in styles.items():
        xs, ys = [], []
        for ef in (16, 32, 64, 128, 256):
            key = f"{world}|ef{ef}"
            if key not in curves:
                continue
            xs.append(lat[str(ef)]["p50"])
            ys.append(curves[key]["F"]["0.95"])
        if xs:
            ax.plot(xs, ys, marker=mk, color=col, label=label, lw=1.5, ms=4)
    ax.axhline(0.05, color="k", ls="--", lw=1.1, label=r"contract $\phi=0.05$")
    # decimal ticks: the default log labels (2x10^-1, 3x10^-1) collide at column width
    ax.set_xscale("log")
    ticks = [0.2, 0.3, 0.4, 0.6, 0.8, 1.2, 2.0]
    ax.set_xticks(ticks)
    ax.set_xticklabels([("%g" % t) for t in ticks])
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_xlabel(r"p50 query latency (ms, single thread)")
    ax.set_ylabel(r"violation rate $F(0.95)$")
    ax.legend(fontsize=6, frameon=False, loc="upper right", handlelength=1.6)
    fig.savefig(os.path.join(FIG, "frontier.pdf"), **_SAVE_KW)
    print("wrote frontier.pdf")


def fig_power():
    """Power figure, read from the same artifact as Table V -- never hand-typed arrays.

    An earlier version carried literal arrays here, and they disagreed with the table by up
    to a factor of five; the assert below makes that failure impossible to reintroduce.
    """
    art = json.load(open(os.path.join(REPO, "reports", "s0", "power_sweep_mixed.json")))
    rates = sorted(art, key=float)
    p = [float(r) for r in rates]
    ours = [art[r]["power_ours"] for r in rates]
    naive = [art[r]["power_fixed"] for r in rates]
    fp_mean = [art[r]["fp_mean"] for r in rates]
    fig, ax = plt.subplots(figsize=(3.4, 1.95))
    ax.plot(p, ours, "o-", label=r"$\alpha$-spent exact (ours)", color="#d62728", lw=1.5, ms=4)
    ax.plot(p, naive, "s--", label="fixed-sample exact", color="#7f7f7f", lw=1.5, ms=4)
    ax.plot(p, fp_mean, "^:", label="mean rule (false PASS)", color="#1f77b4", lw=1.5, ms=4)
    ax.set_xscale("log")
    # percent ticks: the five audited rates must be readable at column width
    ax.set_xticks(p)
    ax.set_xticklabels(["%d%%" % round(100 * v) for v in p])
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_xlim(min(p) * 0.85, max(p) * 1.15)
    ax.set_xlabel("audit rate $p$")
    ax.set_ylabel("power (or false-PASS rate)")
    ax.legend(fontsize=6, frameon=False, loc="upper left")
    fig.savefig(os.path.join(FIG, "power.pdf"), **_SAVE_KW)
    print("wrote power.pdf  (ours=%s)" % [round(x, 3) for x in ours])


def fig_sizing():
    rows = json.load(open(os.path.join(REPO, "reports", "s0", "audit_sizing.json")))
    fig, ax = plt.subplots(figsize=(3.4, 1.95))
    import numpy as _np
    slopes = []
    for w, mk, col in ((1, "o", "#1f77b4"), (6, "s", "#ff7f0e"), (12, "^", "#d62728")):
        xs = [0.05 - r[1] for r in rows if r[0] == w]
        ys = [r[2] for r in rows if r[0] == w]
        ax.plot(xs, ys, marker=mk, color=col, label=f"epoch $w={w}$", lw=1.5, ms=4)
        lx = [_np.log(x) for x, y in zip(xs, ys) if x > 0.004]
        ly = [_np.log(y) for x, y in zip(xs, ys) if x > 0.004]
        if len(lx) >= 3:
            slopes.append(-_np.polyfit(lx, ly, 1)[0])
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel(r"margin $\phi-F$")
    import matplotlib.ticker as _mt
    ax.set_xticks([0.01, 0.02, 0.04])
    ax.xaxis.set_minor_formatter(_mt.NullFormatter())
    ax.set_xticklabels(["0.01", "0.02", "0.04"])
    ax.set_ylabel("required audit rate $p^\\star$")
    # the fitted exponents live in the caption: at column width this annotation was unreadable
    ax.legend(fontsize=6, frameon=False, loc="upper right")
    fig.savefig(os.path.join(FIG, "sizing.pdf"), **_SAVE_KW)
    print("wrote sizing.pdf  (fitted gamma %s)" % ["%.2f" % v for v in slopes])


def fig_price():
    """The price of knowing: power bought vs the audit capacity it costs (not used in the
    paper; kept so the artifact set is reproducible from one command)."""
    art = json.load(open(os.path.join(REPO, "reports", "s0", "power_sweep_mixed.json")))
    cost = json.load(open(os.path.join(REPO, "reports", "audit_cost.json")))
    rates = sorted(art, key=float)
    p = [float(r) for r in rates]
    ours = [art[r]["power_ours"] for r in rates]
    naive = [art[r]["power_fixed"] for r in rates]
    lam = 10_000.0
    qps_per_node = cost["qps_1024"]
    nodes = [pi * lam / qps_per_node for pi in p]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 2.4))
    a1.plot(p, ours, "o-", color="#d62728", label=r"$\alpha$-spent (ours)", lw=1.5)
    a1.plot(p, naive, "s--", color="#7f7f7f", label="fixed-sample", lw=1.5)
    a1.set_xscale("log"); a1.set_xlabel("audit rate $p$"); a1.set_ylabel("certification power")
    a1.legend(fontsize=6, frameon=False)
    a2.plot(p, nodes, "^-", color="#1b9e77", lw=1.5)
    a2.set_xscale("log"); a2.set_yscale("log")
    a2.set_xlabel("audit rate $p$"); a2.set_ylabel("audit node-equivalents")
    fig.savefig(os.path.join(FIG, "price.pdf"), **_SAVE_KW)
    print("wrote price.pdf  (qps/node=%.0f)" % qps_per_node)


def fig_certificate():
    trace = json.load(open(os.path.join(REPO, "reports", "s0", "certificate_trace.json")))
    n = len(trace["truth"])
    x = range(1, n + 1)
    fig, ax = plt.subplots(figsize=(3.4, 1.62))
    ax.plot(x, trace["truth"], "k-", label="true $F(0.95)$", lw=1.5)
    ax.plot(x, trace["hat"], "o", ms=3, color="#7f7f7f", label=r"audited $\hat F$")
    ax.plot(x, trace["ours"], "s-", ms=3.4, color="#1b9e77", label=r"our $U$ ($\alpha$-spent)", lw=1.5)
    ax.plot(x, trace["fixed"], "d--", ms=3.2, color="#d95f02", label="fixed-sample $U$", lw=1.3)
    ax.axhline(0.05, color="k", ls=":", lw=1.1, label=r"$\phi=0.05$")
    ring = False
    for i, (u, t) in enumerate(zip(trace["ours"], trace["truth"])):
        if u <= 0.05:
            ax.plot(i + 1, u, "o", ms=8, mfc="none", mec="#1b9e77", mew=1.1)
            ring = True
    if ring:
        ax.plot([], [], "o", ms=8, mfc="none", mec="#1b9e77", mew=1.1, label="PASS issued")
    ax.set_xlabel("decision epoch")
    ax.set_ylabel("violation rate")
    ax.set_ylim(0.02, 0.115)
    ax.set_xlim(0.4, n + 0.6)
    # legend below the axes: inside the frame it sat on top of the curves
    ax.legend(fontsize=5.8, frameon=False, ncol=3, loc="upper center",
              bbox_to_anchor=(0.5, -0.24), columnspacing=1.0, handletextpad=0.4)
    fig.savefig(os.path.join(FIG, "certificate.pdf"), **_SAVE_KW)
    print("wrote certificate.pdf")


def fig_closedloop():
    """Mean of three trajectories, from the same `t3_final` logs Table VI is built from.

    The earlier version globbed the older `t3_sift` runs: six epochs, and a controller whose
    first epoch read 0.007 instead of the pre-action 0.097 the table reports. Figure and table
    now come from one artifact set.
    """
    fig, ax = plt.subplots(figsize=(3.4, 1.66))
    styles = {"never": ("never", dict(marker="o", ls="-", color="#7f7f7f")),
              "periodic_4": ("rebuild every 4", dict(marker="s", ls="--", color="#ff7f0e")),
              "ef_auto": ("search effort", dict(marker="^", ls=":", color="#d62728",
                                                mfc="none", mew=1.2)),
              "ctrl_rebuild": ("contract controller", dict(marker="D", ls="-", color="#1f77b4",
                                                           mfc="none"))}
    for pol, (lab, kw) in styles.items():
        files = sorted(glob.glob(os.path.join(REPO, "reports", "t3",
                                              f"t3_final_churn_{pol}_s*.json")))
        if not files:
            continue
        runs = [json.load(open(f))["rounds"] for f in files]
        n = min(len(r) for r in runs)
        f = [sum(r[t]["f_true"] for r in runs) / len(runs) for t in range(n)]
        ax.plot(range(1, n + 1), f, label=lab, lw=1.5, ms=3.6, **kw)
    ax.axhline(0.05, color="k", ls=":", lw=1.1, label=r"contract $\phi=0.05$")
    ax.set_xlabel("decision epoch")
    ax.set_ylabel(r"held-out $F(0.95)$")
    ax.set_ylim(0, 0.112)
    # the legend sits below the axes: inside the frame it covered the curves and the contract line
    ax.legend(fontsize=5.6, loc="upper center", bbox_to_anchor=(0.5, -0.30),
              ncol=3, frameon=False, handlelength=1.7, columnspacing=0.9,
              handletextpad=0.4)
    fig.savefig(os.path.join(FIG, "closedloop.pdf"), **_SAVE_KW)
    print("wrote closedloop.pdf")


def fig_loop():
    """The system: the served service, the control plane that audits and certifies it, and the
    actions a verdict buys. Schematic, not data -- the one figure whose job is to let a reader
    see the mechanism before reading a table. Pure vector, fonts embedded.
    """
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

    fig, ax = plt.subplots(figsize=(3.5, 2.0))
    fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
    ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off"); ax.grid(False)
    ink, blue, grey, band = "#1a1a1a", "#1f4e79", "#6b6b6b", "#f2f5f9"

    def chip(x, w, y, h, text, ec=ink, fs=5.6):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.6",
                                    linewidth=0.6, edgecolor=ec, facecolor="white"))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs,
                color=ec, linespacing=1.35)

    def band_box(y, h, label):
        ax.add_patch(FancyBboxPatch((6, y), 92, h, boxstyle="round,pad=0,rounding_size=2.2",
                                    linewidth=0.0, facecolor=band, edgecolor="none"))
        ax.text(8.5, y + h - 3.4, label, ha="left", va="center", fontsize=5.0,
                color=grey, fontweight="bold")

    def arrow(p, q, color=ink, lw=0.75):
        ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=5.0,
                                     linewidth=lw, color=color, shrinkA=0.0, shrinkB=0.0))

    # ---- band 1: the served service
    band_box(70, 24, "SERVICE, every epoch")
    chip(9, 19, 73, 11, "arrivals\n$N$ queries")
    chip(32, 19, 73, 11, "index $I_t$\nat $\\mathrm{ef}$")
    chip(55, 19, 73, 11, "served\nanswers")
    chip(78, 17, 73, 11, "SLA\n$(\\tau,\\phi)$", ec=blue, fs=5.4)
    arrow((28, 78.5), (32, 78.5)); arrow((51, 78.5), (55, 78.5)); arrow((74, 78.5), (78, 78.5))

    # ---- band 2: the control plane
    band_box(38, 24, "CONTROL PLANE, same epoch")
    chip(9, 26, 41, 11, "exact $k$NN\naudit $m=pN$", fs=5.3)
    chip(39, 26, 41, 11, "exact bound\n$U=K^{+}/N$ at $\\alpha_w/2$", ec=blue, fs=5.1)
    chip(69, 26, 41, 11, "PASS / REJECT /\nUNDETERMINED", fs=5.2)
    arrow((35, 46.5), (39, 46.5)); arrow((65, 46.5), (69, 46.5))

    # ---- band 3: the action a verdict buys
    band_box(6, 24, "ACTION, effective in epoch $w{+}1$")
    chip(9, 26, 9, 11, "raise $\\mathrm{ef}$\nlatency, per query", fs=5.2)
    chip(39, 26, 9, 11, "rebuild\nCPU, seconds")
    chip(69, 26, 9, 11, "hold\nkeep serving")

    # ---- couplings, plus the loop back to the next epoch
    arrow((18, 70), (18, 62))
    ax.text(20.5, 66, "sample $pN$ of the arrivals", ha="left", va="center", fontsize=4.9)
    arrow((18, 38), (18, 30))
    ax.text(20.5, 34, "the verdict buys one action", ha="left", va="center", fontsize=4.9)
    ax.add_patch(FancyArrowPatch((9, 14.5), (2.2, 14.5), arrowstyle="-", linewidth=0.75,
                                 color=ink, shrinkA=0.0, shrinkB=0.0))
    ax.add_patch(FancyArrowPatch((2.2, 14.5), (2.2, 82), arrowstyle="-|>", mutation_scale=5.0,
                                 linewidth=0.75, color=ink, shrinkA=0.0, shrinkB=0.0))
    ax.add_patch(FancyArrowPatch((2.2, 82), (9, 82), arrowstyle="-|>", mutation_scale=5.0,
                                 linewidth=0.75, color=ink, shrinkA=0.0, shrinkB=0.0))
    ax.text(4.0, 48, "epoch $w{+}1$,  $\\alpha_{w+1}<\\alpha_w$", ha="center", va="center",
            fontsize=4.7, rotation=90)
    fig.savefig(os.path.join(FIG, "loop.pdf"), **_SAVE_KW)
    print("wrote loop.pdf")

if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else "all"
    if what in ("all", "frontier"):
        fig_frontier()
    if what in ("all", "power"):
        fig_power()
    if what in ("all", "sizing"):
        fig_sizing()
    if what in ("all", "price"):
        fig_price()
    if what in ("all", "certificate"):
        fig_certificate()
    if what in ("all", "closedloop"):
        fig_closedloop()
    if what in ("all", "loop"):
        fig_loop()
