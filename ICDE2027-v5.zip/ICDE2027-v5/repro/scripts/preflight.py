#!/usr/bin/env python3
"""Pre-flight for the ICDE submission: mechanical checks only.

Run after `bash scripts/build_paper.sh`:
    python3 scripts/preflight.py

Exit code 0 = the PDF and sources satisfy the mechanical rules we can verify locally.
It cannot check novelty, correctness, or whether the author block is the right people---
it checks the things that get papers desk-rejected or visibly broken.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys

def _find_repo(start: str) -> str:
    """Locate the project root, so the checkers also work from a delivered archive.

    In the working tree the root is the parent of ``scripts/``. In the delivery archive the
    scripts sit one level down (``repro/scripts``) with ``paper/`` at the archive root. We walk
    up until we find ``paper/main.tex`` (the authoritative marker); only if that fails do we
    accept a directory that merely contains ``reports/``, because ``repro/`` does too.
    """
    here = os.path.abspath(start)
    chain = []
    d = here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


HERE = os.path.dirname(os.path.abspath(__file__))   # where this script lives, in either layout
REPO = _find_repo(HERE)
PDF = os.path.join(REPO, "paper", "build", "main.pdf")
TEX = os.path.join(REPO, "paper", "main.tex")
LOG = os.path.join(REPO, "paper", "build", "main.log")
BBL = os.path.join(REPO, "paper", "build", "main.bbl")

rows: list[tuple[str, bool, str]] = []


def add(name: str, ok: bool, detail: str = ""):
    rows.append((name, ok, detail))


def load_json(rel: str):
    path = os.path.join(REPO, rel)
    if not os.path.exists(path):
        return None
    import json as _json
    return _json.load(open(path))


def sh(*args) -> str:
    return subprocess.run(args, capture_output=True, text=True).stdout


def main() -> int:
    if not os.path.exists(PDF):
        print("no PDF: run bash scripts/build_paper.sh first")
        return 1
    tex = open(TEX).read()
    txt = sh("pdftotext", PDF, "-")

    # 1. page geometry
    info = sh("pdfinfo", PDF)
    pages = int(re.search(r"Pages:\s+(\d+)", info).group(1))
    size = re.search(r"Page size:\s+([\d.]+) x ([\d.]+)", info)
    w, h = (float(size.group(1)), float(size.group(2))) if size else (0, 0)
    add("page size is US Letter (612x792)", abs(w - 612) < 2 and abs(h - 792) < 2, f"{w}x{h}")
    add("total pages <= 13 (12 body + refs)", pages <= 13, f"{pages} pages")
    # ICDE counts the *body* against the 12-page limit, excluding references
    refs_page = None
    for pg in range(1, pages + 1):
        page_txt = sh("pdftotext", "-f", str(pg), "-l", str(pg), PDF, "-")
        if "REFERENCES" in page_txt.upper().replace(" ", ""):
            refs_page = pg
            break
    body_pages = refs_page if refs_page else pages
    lead_lines = 0
    if refs_page:
        page12 = sh("pdftotext", "-f", str(refs_page), "-l", str(refs_page), PDF, "-").splitlines()
        for line in page12:
            if "REFERENCES" in line.upper().replace(" ", ""):
                break
            if line.strip():
                lead_lines += 1
    add("body pages <= 12 (ICDE limit, refs excluded)", body_pages <= 12,
        f"refs head p.{refs_page} after {lead_lines} lines, so body ~ {body_pages - 1}.{min(9, lead_lines)} pages")

    # 2. fonts embedded
    fonts = sh("pdffonts", PDF)
    not_embedded = [l for l in fonts.splitlines()[2:] if l.strip() and " no " in l[:60]]
    add("all fonts embedded", len(not_embedded) == 0, f"{len(not_embedded)} not embedded")

    # 3. text extractable
    add("text layer present", len(txt) > 10000, f"{len(txt)} chars")

    # 4. build hygiene
    log = open(LOG).read() if os.path.exists(LOG) else ""
    errors = len(re.findall(r"^!", log, flags=re.M))
    undefined = len(re.findall(r"Citation.*undefined", log))
    bibitems = open(BBL).read().count("\\bibitem") if os.path.exists(BBL) else 0
    add("no LaTeX errors", errors == 0, f"{errors}")
    add("no undefined citations", undefined == 0, f"{undefined}")
    # every \cref must resolve too: an undefined reference prints "??" in the PDF, which is
    # how a missing \label for the controller algorithm once reached a submitted draft
    undef_refs = len(re.findall(r"Reference.*undefined", log))
    add("no undefined cross-references", undef_refs == 0, f"{undef_refs}")
    add("no '??' in the text layer", "??" not in txt, f"{txt.count('??')}")
    add("bibliography built (>=20 entries)", bibitems >= 20, f"{bibitems}")

    # 5. ICDE-specific content rules
    add("no appendix (ICDE forbids it)",
        not re.search(r"\\appendix\b", tex), "")
    add("AI-use disclosure present",
        "large language model" in txt.lower() and "acknowledg" in txt.lower(), "")
    add("no TODO markers in PDF", "TODO" not in txt, "")
    abstract = re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", tex, re.S)
    body = re.sub(r"\\[a-zA-Z]+\{([^}]*)\}", r"\1", abstract.group(1)) if abstract else ""
    body = re.sub(r"[{}$\\]", " ", body)
    words = len([w for w in body.split() if w.strip()]) if abstract else 0
    add("abstract <= 300 words", words <= 300, f"{words} words")
    placeholder = "[Authors]" in tex or "[Affiliation]" in tex
    add("author block filled in", not placeholder, "PI action" if placeholder else "")

    # 6. layout hygiene, integrity, provenance
    overfull = len(re.findall(r"Overfull \\hbox", log))
    add("no overfull boxes", overfull == 0, f"{overfull}")
    labels = re.findall(r"\\label\{((?:tab|fig):[a-z0-9\-]+)\}", tex)
    unref = [L for L in labels if not re.search(r"\\[cC]ref\{" + re.escape(L) + r"\}", tex)]
    add("every float/table is referenced", len(unref) == 0, ", ".join(unref[:3]))
    cited = set()
    for m in re.finditer(r"\\cite\{([^}]*)\}", tex):
        cited.update(k.strip() for k in m.group(1).split(","))
    bbl = open(BBL).read() if os.path.exists(BBL) else ""
    uncited = 0
    for key in cited:
        pass
    add("bibliography has no orphan entries", bibitems >= len(cited) - 2, f"{len(cited)} cited / {bibitems} entries")
    leaks = [pat for pat in ("/home/", "sorryios", "Deepseek-Slave", "127.0.0.1", "172.28.") if pat in txt]
    add("no host/path/secret leak in PDF", not leaks, ", ".join(leaks))
    hashfile = os.path.join(REPO, "paper", "build", "SOURCE_HASH")
    if os.path.exists(hashfile):
        recorded = open(hashfile).read().strip()
        recomputed = subprocess.run(
            ["bash", "-c",
             'cd "$0" && { sha256sum main.tex refs.bib; '
             'find figures -name "*.pdf" 2>/dev/null | sort | xargs -r sha256sum; } '
             '| sha256sum | cut -d" " -f1',
             os.path.join(REPO, "paper")],
            capture_output=True, text=True).stdout.strip()
        add("PDF was built from the current sources", recomputed == recorded,
            f"{recorded[:12]} vs {recomputed[:12]}")
    else:
        add("PDF provenance recorded", False, "rerun build_paper.sh")

    # 6b. declared run counts must match the artifacts. The paper runs two protocols
    # (250 mixed runs, 1000 boundary runs), so a claimed count has to match one of them.
    # The PDF wraps lines, so match on a flattened text layer: a hyphenated line break
    # ("twelve-\nepoch") must not hide the claim from this check.
    flat = re.sub(r"\s+", " ", re.sub(r"-(\s*\n)", "-", txt))
    # pdftotext drops a hyphen that falls at a line end ("twelve-epoch" -> "twelveepoch"),
    # so the pattern has to tolerate both spellings
    # only a standalone integer counts: "1.000  twelve-epoch runs" (a table cell followed by
    # the caption) must not be read as a run count, hence the lookbehind
    claimed_runs = [int(x) for x in re.findall(r"(?<![\d.])(\d+)\s+twelve-?\s*epoch runs", flat)]
    known_runs = set()
    for rel in ("reports/s0/protocol_boundary_p10_1000.json",
                "reports/s0/protocol_mixed_p30.json"):
        d = load_json(rel)
        if d and d.get("args", {}).get("runs"):
            known_runs.add(int(d["args"]["runs"]))
    if known_runs and claimed_runs:
        add("declared run count matches an artifact", all(c in known_runs for c in claimed_runs),
            f"pdf says {claimed_runs}, artifacts say {sorted(known_runs)}")

    # 6c. headline claims: artifact value and PDF text must agree
    claims_path = os.path.join(REPO, "relay", "claims.json")
    if os.path.exists(claims_path):
        import json as _json
        claims = _json.load(open(claims_path))
        bad_art, bad_pdf = [], []
        for c in claims:
            src = load_json(c["source"])
            if src is None:
                bad_art.append(c["claim"] + " (missing artifact)")
                continue
            v = src
            for part in c["field"].split("."):
                if part.startswith("derived:"):
                    v = None
                    break
                v = v[int(part)] if (isinstance(v, list) and part.isdigit()) else v[part]
            if v is not None and abs(float(v) - c["value"]) > c["tol"]:
                bad_art.append(f'{c["claim"]}: artifact {float(v):.3f} vs {c["value"]:.3f}')
            if c["pdf_text"] not in txt:
                bad_pdf.append(c["claim"])
        add("headline claims match their artifacts", not bad_art, "; ".join(bad_art[:2]))
        add("headline claims appear in the PDF", not bad_pdf, "; ".join(bad_pdf[:2]))
    else:
        add("claim registry present", False, "run scripts/make_claims.py")

    # 6d. prose numbers must be traceable
    prose = subprocess.run([sys.executable, os.path.join(HERE, "check_prose_numbers.py"), "--strict"],
                           capture_output=True, text=True)
    add("every prose number traces to an artifact", prose.returncode == 0,
        prose.stdout.strip().splitlines()[0] if prose.stdout.strip() else "")

    # 6e. PDF container hygiene
    raw = open(PDF, "rb").read()
    for pat, name in ((b"/home/", "local path"), (b"/opt/volume", "local path"),
                      (b"sorryios", "host name"), (b"Deepseek-", "host name"),
                      (b"172.28.", "private address")):
        add(f"no {name} in PDF bytes", pat not in raw)
    add("no embedded attachments", sh("pdfdetach", "-list", PDF).strip().startswith("0 embedded"),
        sh("pdfdetach", "-list", PDF).strip().splitlines()[0] if sh("pdfdetach", "-list", PDF).strip() else "")
    empties = []
    for pg in range(1, pages + 1):
        page_txt = sh("pdftotext", "-f", str(pg), "-l", str(pg), PDF, "-")
        body = page_txt.replace(" ", "").replace("\n", "")
        # a short final page carrying only bibliography entries is normal, not a defect
        stripped = re.sub(r"\s+", " ", page_txt).strip()
        if pg == pages and (("REFERENCES" in stripped.upper().replace(" ", ""))
                            or re.fullmatch(r"(\[\d+\][^\[]*)+", stripped)):
            continue
        if len(body) < 200:
            empties.append(pg)
    add("no near-empty pages", not empties, str(empties) if empties else "")

    # 6f. PDF structure: validity, annotations, embedded objects, metadata
    qpdf = subprocess.run(["qpdf", "--check", PDF], capture_output=True, text=True)
    add("PDF passes qpdf structural check", qpdf.returncode == 0,
        (qpdf.stdout or "").strip().splitlines()[-1][:60] if qpdf.stdout.strip() else "")
    add("no annotations (comments/highlights)", raw.count(b"/Annots") == 0, f"{raw.count(b'/Annots')}")
    add("no embedded files in the object tree", raw.count(b"/EmbeddedFile") == 0, "")
    meta_author = sh("pdfinfo", PDF)
    bad_meta = [ln for ln in meta_author.splitlines()
                if ln.startswith(("Author:", "Title:", "Subject:")) and any(
                    k in ln for k in ("/home", "sorryios", "172.28"))]
    add("metadata carries no host or path", not bad_meta, "; ".join(bad_meta[:1]))

    # 6g. the CMT copy of the abstract must equal the PDF abstract
    pdf_txt = sh("pdftotext", PDF, "-")
    m_pdf = re.search(r"Abstract[—\-](.*?)Index Terms", pdf_txt, re.S)
    submit_path = os.path.join(REPO, "SUBMIT.md")
    if not os.path.exists(submit_path):
        submit_path = os.path.join(REPO, "paper", "SUBMIT.md")   # the archive keeps it here
    submit = open(submit_path).read() if os.path.exists(submit_path) else ""
    m_sub = re.search(r"\*\*Abstract\*\*.*?```\n(.*?)```", submit, re.S)
    if m_pdf and m_sub:
        a = re.sub(r"\s+", " ", m_pdf.group(1)).strip()
        b = re.sub(r"\s+", " ", m_sub.group(1)).strip()
        import difflib
        sim = difflib.SequenceMatcher(None, a, b).ratio()
        na = re.findall(r"\d+(?:\.\d+)?", a)
        nb = re.findall(r"\d+(?:\.\d+)?", b)
        add("CMT abstract equals the PDF abstract", sorted(na) == sorted(nb),
            f"similarity {sim:.4f}, numbers {len(na)} vs {len(nb)}"
            + ("" if sorted(na) == sorted(nb) else f", first diff {sorted(set(na) ^ set(nb))[:4]}"))
    else:
        add("CMT abstract equals the PDF abstract", False, "block not found")

    # 7. claim audit
    audit = subprocess.run([sys.executable, os.path.join(HERE, "check_numbers.py")],
                           capture_output=True, text=True)
    add("claim audit (check_numbers.py) exits 0", audit.returncode == 0,
        audit.stdout.strip().splitlines()[-1] if audit.stdout.strip() else "")
    m = re.search(r"checked (\d+) numbers", audit.stdout or "")
    if m:
        actual = int(m.group(1))
        claimed = [int(x) for x in re.findall(r"(\d+)\s*(?:checked|numeric)?\s*cells", txt)]
        add("paper states the true number of audited cells",
            all(c == actual for c in claimed) and bool(claimed),
            f"pdf says {claimed or 'nothing'}, checker says {actual}")
    else:
        add("paper states the true number of audited cells", False, "could not parse audit output")

    width = max(len(r[0]) for r in rows)
    bad = 0
    for name, ok, detail in rows:
        print(f"[{'✓' if ok else '✗'}] {name:<{width}}  {detail}")
        bad += 0 if ok else 1
    print(f"\n{len(rows) - bad}/{len(rows)} checks passed")
    if bad:
        print("Not submit-ready. Fix the ✗ items above.")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
