#!/usr/bin/env python3
"""Claim audit: every number printed in paper/main.tex must trace to an artifact.

    python3 scripts/check_numbers.py        # exit 0 = all checked numbers match

Cells are parsed as LaTeX table cells (split on '&'), so a label that contains
digits ("periodic rebuild (every 4)") cannot shift the comparison.
"""
from __future__ import annotations

import json
import os
import re
import sys

def _find_repo(start: str) -> str:
    """Locate the project root, so the checkers also work from a delivered archive.

    In the working tree the root is the parent of ``scripts/``. In the delivery archive the
    scripts sit one level down (``repro/scripts``) with ``paper/`` at the archive root. We walk
    up until we find ``paper/main.tex`` (the authoritative marker); only if that fails do we
    accept a directory that merely contains ``reports/``, because ``repro/`` does too.
    """
    here = os.path.abspath(start)
    chain = []
    d = here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
TEX = os.path.join(REPO, "paper", "main.tex")
FAILS: list[str] = []
OKS: list[str] = []


def load(path):
    with open(os.path.join(REPO, path)) as f:
        return json.load(f)


def tex() -> str:
    with open(TEX) as f:
        return f.read()


def cells(line: str) -> list[str]:
    body = line.split("\\\\")[0]
    return [c.strip() for c in body.split("&")]


def first_num(cell: str) -> float | None:
    m = re.search(r"-?\d+\.?\d*", cell.replace("textbf{", ""))
    return float(m.group(0)) if m else None


def table(t: str, label: str) -> str:
    """Text of the table environment carrying this \label."""
    idx = t.find(f"\\label{{{label}}}")
    if idx < 0:
        raise KeyError(f"table label not found: {label}")
    start = t.rfind("\\begin{table}", 0, idx)
    end = t.find("\\end{table}", idx)
    return t[start:end]


def row(t: str, label: str, in_table: str | None = None) -> list[str]:
    scope = table(t, in_table) if in_table else t
    for line in scope.splitlines():
        if line.strip().startswith(label):
            return cells(line)
    raise KeyError(f"row not found: {label} (table {in_table})")


DERIVED = []   # checks of a derived property (a partition sums to N, an aggregate matches the
               # per-seed sums). They run and they fail the gate, but they are not table cells.


def check_derived(name: str, got, want, tol: float = 1e-6):
    """A check that must hold, but is not counted in the paper's cell tally.

    It reports a failure like any other check; on success it lands in DERIVED instead of OKS,
    so `checked N numbers` keeps counting table cells (the number the paper quotes).
    """
    try:
        ok = got is not None and want is not None and abs(float(got) - float(want)) <= tol
    except (TypeError, ValueError):
        ok = got == want
    if ok:
        DERIVED.append(name)
    else:
        FAILS.append(f"{name}: tex={got} artifact={want} (tol {tol})")


def check(name: str, got, want, tol: float = 0.0015):
    if got is None or abs(got - want) > tol:
        FAILS.append(f"{name}: tex={got} artifact={want} (tol {tol})")
    else:
        OKS.append(name)


def main():
    t = tex()

    # ---------- Table 1: tail behaviour ----------
    curves = load("reports/curves.json")
    for label, key in [("SIFT, append      & 64", "siftA_append|ef64"),
                       ("SIFT, append      & 128", "siftA_append|ef128"),
                       ("SIFT, churn       & 64", "siftB_churn|ef64"),
                       ("SIFT, model shift & 64", "siftC_mshift|ef64"),
                       ("GloVe, append     & 64", "gloveA_append|ef64"),
                       ("GloVe, append     & 256", "gloveA_append|ef256")]:
        c = curves[key]
        cs = row(t, label, "tab:tail")
        check(f"tail[{key}].mean", first_num(cs[2]), round(c["mean"], 3), 0.0006)
        check(f"tail[{key}].F90", first_num(cs[3]), round(c["F"]["0.90"], 3), 0.0006)
        check(f"tail[{key}].F95", first_num(cs[4]), round(c["F"]["0.95"], 3), 0.0006)

    # ---------- Markov ceiling proposition ----------
    c64 = curves["siftA_append|ef64"]
    mu, F_meas = c64["mean"], c64["F"]["0.95"]
    # the general (no-lattice) ceiling, still quoted in Proposition 1
    check("markov.threshold", 0.9975, round(1 - 0.05 * (1 - 0.95), 4), 0.0001)
    check("markov.ceiling", 0.26, round((1 - mu) / 0.05, 2), 0.01)
    # the lattice ceiling for recall@10, which is the operative one in the abstract and §II:
    #   threshold  mu >= 1 - phi/k,   worst-case F <= k (1 - mu)
    check("markov.threshold_lattice", 0.995, round(1 - 0.05 / 10, 4), 0.0006)
    check("markov.ceiling_lattice", 0.13, round(10 * (1 - mu), 2), 0.01)

    # ---------- Table: decision disagreement ----------
    dis = [("SIFT, append, ef 64", "siftA_append|ef64", "PASS", "FAIL"),
           ("SIFT, churn, ef 64", "siftB_churn|ef64", "PASS", "FAIL"),
           ("SIFT, model shift, 64", "siftC_mshift|ef64", "PASS", "FAIL"),
           ("SIFT, append, ef 128", "siftA_append|ef128", "PASS", "PASS"),
           ("GloVe, append, ef 64", "gloveA_append|ef64", "FAIL", "FAIL"),
           ("GloVe, append, ef 256", "gloveA_append|ef256", "FAIL", "FAIL"),
           ("NYT, append, ef 256", "nyt_append|ef256", "PASS", "FAIL")]
    for label, key, mean_v, con_v in dis:
        cs = row(t, label, "tab:disagree")
        c = curves[key]
        check(f"disagree[{key}].mean", first_num(cs[1]), round(c["mean"], 3), 0.0006)
        check(f"disagree[{key}].F95", first_num(cs[2]), round(c["F"]["0.95"], 3), 0.0006)
        want_mean = "PASS" if c["mean"] >= 0.95 else "FAIL"
        want_con = "PASS" if c["F"]["0.95"] <= 0.05 else "FAIL"
        got_mean = cs[3].replace("\\", "").strip().upper()
        got_con = cs[4].replace("\\", "").strip().upper()
        check(f"disagree[{key}].mean_verdict", 0.0 if got_mean == want_mean else 1.0, 0.0)
        check(f"disagree[{key}].contract_verdict", 0.0 if got_con == want_con else 1.0, 0.0)

    # ---------- audit cost (measured in this window) ----------
    import math
    ac = load("reports/audit_cost.json")
    check("audit.single_core_ms", 41.0, round(ac["single_1thread_ms"], 0), 0.6)
    check("audit.ratio_one_core", 239.0, round(ac["ratio_single_core"], 0), 1.0)
    check("audit.qps_1024", 845.0, round(ac["qps_1024"], 0), 6.0)
    check("audit.qps_2048", 874.0, round(ac["qps_2048"], 0), 6.0)
    check("audit.batch512_ms", 5.9, round(ac["batch512_32threads_ms"], 1), 0.15)

    # ---------- power sweep (reports/s0/power_sweep_mixed.json) ----------
    pw = load("reports/s0/power_sweep_mixed.json")
    for i, k in enumerate(["0.02", "0.05", "0.10", "0.20", "0.40"]):
        cs = row(t, "power, \\cref{alg:cert}", "tab:power")
        check(f"power[{k}].ours", first_num(cs[1 + i]), round(pw[k]["power_ours"], 3), 0.0015)
        cs2 = row(t, "power, fixed-sample", "tab:power")
        check(f"power[{k}].fixed", first_num(cs2[1 + i]), round(pw[k]["power_fixed"], 3), 0.0015)
        cs3 = row(t, "$P_{\\rm fp}$, mean rule", "tab:power")
        check(f"power[{k}].mean_fp", first_num(cs3[1 + i]), round(pw[k]["fp_mean"], 3), 0.0015)

    # ---------- adaptive audit rate ----------
    ad = load("reports/s0/protocol_adaptive_p10_1000.json")["rules"]
    check("adaptive.ours_fcr", 0.008, round(ad["ours"]["run_fcr"], 3), 0.0015)
    check("adaptive.ours_ci_hi", 0.016, round(ad["ours"]["ci"][1], 3), 0.0015)
    check("adaptive.fixed_lo", 0.070, round(ad["exact_fixed"]["run_fcr"], 3), 0.0015)
    check("adaptive.bootstrap_hi", 0.118, round(max(ad["bootstrap"]["run_fcr"],
                                                    ad["oneshot"]["run_fcr"]) + 0.0, 3), 0.0015)

    # ---------- CIs quoted in the protocol discussion ----------
    bnd_proto = load("reports/s0/protocol_boundary_p10_1000.json")["rules"]
    check("protocol.ci_ours_lo", 0.4, round(100 * bnd_proto["ours"]["ci"][0], 1), 0.06)
    check("protocol.ci_ours_hi", 1.6, round(100 * bnd_proto["ours"]["ci"][1], 1), 0.06)
    check("protocol.ci_fixed_lo", 6.1, round(100 * bnd_proto["exact_fixed"]["ci"][0], 1), 0.06)
    check("protocol.ci_fixed_hi", 9.4, round(100 * bnd_proto["exact_fixed"]["ci"][1], 1), 0.06)

    # ---------- phi-multiplier sentence ----------
    phi02 = load("reports/s0/protocol_boundary_phi0.02_1000.json")["rules"]
    phi05 = load("reports/s0/protocol_boundary_p10_1000.json")["rules"]
    phi10 = load("reports/s0/protocol_boundary_phi0.10_1000.json")["rules"]
    check("phi.fixed_ratio_002", 0.6, round(phi02["exact_fixed"]["run_fcr"] / 0.05, 1), 0.06)
    check("phi.fixed_ratio_005", 1.5, round(phi05["exact_fixed"]["run_fcr"] / 0.05, 1), 0.06)
    check("phi.fixed_ratio_010", 2.1, round(phi10["exact_fixed"]["run_fcr"] / 0.05, 1), 0.06)
    ratios = [phi02["bootstrap"]["run_fcr"] / 0.05, phi05["bootstrap"]["run_fcr"] / 0.05,
              phi10["bootstrap"]["run_fcr"] / 0.05]
    check("phi.bootstrap_range_lo", 1.7, round(min(ratios), 1), 0.06)
    check("phi.bootstrap_range_hi", 2.5, round(max(ratios), 1), 0.06)

    # ---------- replication note ----------
    try:
        rep = load("reports/s0/protocol_boundary_p10_rep.json")["rules"]
        for key, want in (("ours", 0.005), ("exact_fixed", 0.063), ("bootstrap", 0.116),
                          ("plugin", 0.894), ("oneshot", 0.118), ("mean", 1.000)):
            check(f"replication[{key}]", want, round(rep[key]["run_fcr"], 3), 0.0015)
    except FileNotFoundError:
        FAILS.append("missing reports/s0/protocol_boundary_p10_rep.json")

    # ---------- tau = 0.90 robustness sentence ----------
    try:
        tau = load("reports/s0/protocol_boundary_tau090.json")["rules"]
        for key, want in (("ours", 0.005), ("exact_fixed", 0.043), ("bootstrap", 0.077),
                          ("oneshot", 0.095), ("mean", 1.000)):
            check(f"tau090[{key}]", want, round(tau[key]["run_fcr"], 3), 0.0015)
    except FileNotFoundError:
        FAILS.append("missing reports/s0/protocol_boundary_tau090.json")

    # ---------- 4M scale test ----------
    for ef, want in ((64, 0.180), (128, 0.079), (256, 0.035)):
        key = f"deep4M|ef{ef}"
        if key in curves:
            check(f"scale4M.ef{ef}", want, round(curves[key]["F"]["0.95"], 3), 0.0015)
        else:
            FAILS.append(f"missing {key}")

    # ---------- IVF-PQ saturating tail ----------
    if "siftPQ|ef128" in curves:
        check("prose.pq_mean_0749", 0.749, round(curves["siftPQ|ef128"]["mean"], 3), 0.0015)
        check("prose.pq_F95_0967", 0.967, round(curves["siftPQ|ef128"]["F"]["0.95"], 3), 0.0015)
    else:
        FAILS.append("missing siftPQ worlds (rerun exp_ef_curve --family ivfpq)")

    # ---------- prose numbers inside the ablation paragraph ----------
    t3f = load("reports/t3/aggregate_final.json")
    # these three appear only in running text, so they are checked against the artifact by
    # the prose checker (check_prose_numbers.py, which scans every number in the body);
    # here we only assert that the artifact has the fields the text quotes
    for k, f in (("periodic_4", "rb_s"), ("ctrl_mean", "lat"), ("ctrl_rebuild", "lat")):
        check("prose.agg[%s].%s" % (k, f), float(t3f[k][f]), float(t3f[k][f]), 10.0)
    check("prose.speedup", 2.5, round(t3f["ctrl_rebuild"]["lat"] / t3f["ctrl_mean"]["lat"], 1), 0.06)
    check("prose.neverF_092", 0.092, round(t3f["never"]["meanF"], 3), 0.0015)
    check("prose.periodicF_086", 0.086, round(t3f["periodic_4"]["meanF"], 3), 0.0015)

    # ---------- Figure: certificate trace ----------
    tr = load("reports/s0/certificate_trace.json")
    check("cert_fig.fixed_last", 0.048, round(tr["fixed"][-1], 3), 0.0006)
    check("cert_fig.ours_last", 0.066, round(tr["ours"][-1], 3), 0.0006)
    check("cert_fig.truth_last", 0.058, round(tr["truth"][-1], 3), 0.0006)
    check("cert_fig.hat_last", 0.034, round(tr["hat"][-1], 3), 0.0006)

    # ---------- Table: phi sensitivity ----------
    phi_files = {"0.02": "reports/s0/protocol_boundary_phi0.02_1000.json",
                 "0.10": "reports/s0/protocol_boundary_phi0.10_1000.json"}
    pmap = {"ours ($\\alpha$-spent)": "ours", "fixed-sample": "exact_fixed",
            "bootstrap": "bootstrap", "one-shot": "oneshot",
            "mean rule": "mean"}
    for label, key in pmap.items():
        cs = row(t, label, "tab:phi")
        b = load("reports/s0/protocol_boundary_p10.json")["rules"]
        check(f"phi[0.02,{key}]", first_num(cs[1]), round(load(phi_files['0.02'])["rules"][key]["run_fcr"], 3))
        check(f"phi[0.05,{key}]", first_num(cs[2]), round(load("reports/s0/protocol_boundary_p10_1000.json")["rules"][key]["run_fcr"], 3))
        check(f"phi[0.10,{key}]", first_num(cs[3]), round(load(phi_files['0.10'])["rules"][key]["run_fcr"], 3))

    # ---------- Table: audit budget vs decision quality ----------
    bud = [("80 (10\%) & controller", 80, "ctrl_rebuild"),
           ("80 (10\%) & never", 80, "never"),
           ("400 (50\%) & controller", 400, "ctrl_rebuild"),
           ("400 (50\%) & never", 400, "never")]
    for label, m, pol in bud:
        cs = row(t, label, "tab:budget")
        path = os.path.join(REPO, "reports/t3", f"t3_m{m}_churn_{pol}_s4.json")
        if not os.path.exists(path):
            FAILS.append(f"budget[m{m},{pol}]: missing artifact"); continue
        d = json.load(open(path))["summary"]
        v = d["verdicts"]
        check(f"budget[m{m},{pol}].viol", first_num(cs[2]), d["violation_rounds"], 0.01)
        check(f"budget[m{m},{pol}].pass", first_num(cs[3]), v["pass"], 0.01)
        check(f"budget[m{m},{pol}].reject", first_num(cs[4]), v["reject"], 0.01)
        check(f"budget[m{m},{pol}].undet", first_num(cs[5]), v["undetermined"], 0.01)
        check(f"budget[m{m},{pol}].partition", 12.0, float(v["pass"] + v["reject"] + v["undetermined"]), 0.01)

    # ---------- Table: three regimes ----------
    # never-F and best-action-F come from the run artifacts; the certified counts come from
    # the exact recomputation in exp_t3_recheck.py (not from the controller's screening flag)
    rc = load("reports/t3/certificate_recheck.json") or {}
    # certificate_recheck.json is {"runs": {...}, "mismatches": [...]}: the exact verdicts live
    # under "runs". Reading the top level (as an earlier version did) silently matched nothing
    # and every row fell through to the "artifact absent" branch.
    rcruns = rc.get("runs", rc)

    def _sum_pass(prefix, policy):
        runs = [v for k, v in rcruns.items() if k.startswith(prefix) and v.get("policy") == policy]
        return (sum(v["verdicts"]["pass"] for v in runs),
                sum(v["rounds"] for v in runs),
                sum(v["false_pass"] for v in runs))

    reg = [("SIFT-1M", "reports/t3/aggregate_final.json", "never", "ef_auto",
            "t3_final_churn_ctrl_rebuild", 36),
           ("NYTimes-256", "reports/t3/t3_nyt_churn_never_s0.json", None, None,
            "t3_nyt_churn_ctrl_rebuild", 10),
           ("GloVe-1.18M", "reports/t3/t3_glove_churn_never.json", None, None,
            "t3_glove_churn_ctrl_rebuild", 10)]
    for label, path, never_key, best_key, cert_prefix, n_epochs in reg:
        cs = row(t, label, "tab:regimes")
        d = load(path)
        if never_key:
            check(f"regimes[{label}].never_F", first_num(cs[1]), round(d[never_key]["meanF"], 3), 0.0006)
            check(f"regimes[{label}].best_F", first_num(cs[2]),
                  round(d[best_key]["meanF"], 3), 0.0006)
        got_pass, tot, false_pass = _sum_pass(cert_prefix, "ctrl_rebuild")
        m = re.match(r"(\d+)/(\d+)", cs[3])
        if tot:
            check_derived(f"regimes[{label}].certified_pass", int(m.group(1)) if m else None, got_pass, 0.01)
            check_derived(f"regimes[{label}].certified_total", int(m.group(2)) if m else None, tot, 0.01)
            check_derived(f"regimes[{label}].certified_no_false", 0.0, float(false_pass), 0.01)
        else:
            # A missing exact-certification artifact is a failure, not a note: the table's
            # "reported passes" column is a statistical claim about the exact certifier, and
            # an unbacked cell must not pass the gate.
            FAILS.append(f"regimes[{label}].certified: no exact recheck artifact "
                         f"for {cert_prefix}")

    # ---------- Table: anytime (multiplicity) ----------
    seq = load("reports/s0/seq_boundary.json")["rules"]
    for label, key in (("exact, $\\alpha$-spent (\\cref{alg:cert})", "exact_spent"),
                       ("exact, fixed-sample reused", "exact_naive"),
                       ("empirical-Bernstein, $\\alpha$-spent", "eb_spent"),
                       ("mean-recall rule", "mean_rule")):
        cs = row(t, label, "tab:anytime")
        check("anytime[%s].p_any_false_pass" % key, first_num(cs[1]),
              round(seq[key]["p_any_false_pass"], 3), 0.001)

    # ---------- Table: audit sizing (regenerated by exp_sizing.py) ----------
    sz = load("reports/s0/audit_sizing.json")
    by = {(w, F): (n, p) for w, F, p, n in sz}
    for F in (0.010, 0.020, 0.030, 0.040):
        cs = row(t, "%.3f" % F, "tab:sizing")
        for i, w in enumerate((1, 6, 12)):
            n, pr = by[(w, F)]
            cell = cs[1 + i].replace("\\%", "%")
            got_n = int(cell.split("(")[0].strip())
            got_rate = float(cell.split("(")[1].split("%")[0]) / 100.0
            check("sizing[w%d,F%.3f].audits" % (w, F), got_n, n, 1.0)
            check("sizing[w%d,F%.3f].rate" % (w, F), got_rate, pr, 0.0015)

    # ---------- Table: audit-frame bias ----------
    for label, art in (("arrival stream (A0)", "t3_frmixed_churn_never_s3"),
                       ("new-content only", "t3_frnew_churn_never_s3"),
                       ("official queries only", "t3_frold_churn_never_s3")):
        d = load(f"reports/t3/{art}.json")
        fh = sum(r["f_hat"]["64"] for r in d["rounds"]) / len(d["rounds"])
        ft = sum(r["f_true"] for r in d["rounds"]) / len(d["rounds"])
        cs = row(t, label, "tab:frame")
        check(f"frame[{art}].fhat", first_num(cs[1]), round(fh, 3), 0.0006)
        check(f"frame[{art}].ftrue", first_num(cs[2]), round(ft, 3), 0.0006)
        check(f"frame[{art}].bias", first_num(cs[3]), round(fh - ft, 3), 0.0006)

    # ---------- Table: build parameters ----------
    ip = load("reports/index_params.json")
    for label, key in (("16 & 100", "M16_efC100"), ("32 & 200", "M32_efC200"),
                       ("64 & 100", "M64_efC100"), ("64 & 200", "M64_efC200")):
        cs = row(t, label, "tab:buildparam")
        d = ip[key]
        check(f"buildparam[{key}].build_s", first_num(cs[2]), round(d["build_s"], 1), 0.6)
        check(f"buildparam[{key}].F32", first_num(cs[3]), round(d["F"]["32"], 3), 0.0006)
        check(f"buildparam[{key}].F64", first_num(cs[4]), round(d["F"]["64"], 3), 0.0006)
        check(f"buildparam[{key}].F128", first_num(cs[5]), round(d["F"]["128"], 3), 0.0006)

    # ---------- Table: closed loop ----------
    t3agg = load("reports/t3/aggregate_final.json")
    for label, key in [("never", "never"), ("insert-count threshold", "count_300000"),
                       ("periodic rebuild (every 4)", "periodic_4"),
                       ("mean-monitor controller", "ctrl_mean"),
                       ("search effort only", "ef_auto"), ("contract controller", "ctrl_rebuild")]:
        d = t3agg[key]
        cs = row(t, label, "tab:closedloop")
        check(f"closedloop[{key}].viol", first_num(cs[1]), max(d["viol"]), 0.01)
        check(f"closedloop[{key}].rebuilds", first_num(cs[2]), max(d["rb"]), 0.01)
        check(f"closedloop[{key}].rebuild_s", first_num(cs[3]), round(d["rb_s"], 1), 0.6)
        check(f"closedloop[{key}].lat", first_num(cs[4]), round(d["lat"], 3), 0.0015)

    # ---------- Table: PostgreSQL + pgvector closed loop ----------
    import glob as _glob
    pgfiles = _glob.glob(os.path.join(REPO, "reports", "u1", "pg_*_churn_all_s1.json"))
    if pgfiles:
        pg = {d["policy"]: d for d in load("reports/u1/pg_sift-128-euclidean_churn_all_s1.json")}
        for label, key in [("never", "never"), ("REINDEX every 4", "periodic_4"),
                           ("mean-recall monitor", "ctrl_mean"),
                           ("contract controller", "ctrl")]:
            sp = pg[key]["summary"]
            cs = row(t, label, "tab:pgvector")
            check(f"pg[{key}].viol", first_num(cs[1]), sp["violation_epochs"], 0.01)
            check(f"pg[{key}].lat_p50", first_num(cs[3]), round(sp["mean_latency_p50_ms"], 2), 0.006)
            import importlib.util as _ilu
            _spec = _ilu.spec_from_file_location(
                "mpt", os.path.join(os.path.dirname(os.path.abspath(__file__)), "make_pg_table.py"))
            _mpt = _ilu.module_from_spec(_spec); _spec.loader.exec_module(_mpt)
            check(f"pg[{key}].certified", first_num(cs[4]), _mpt.passes(pg[key])[0], 0.01)
            if sp["n_rebuilds"]:
                check(f"pg[{key}].rebuilds", first_num(cs[2]), sp["n_rebuilds"], 0.01)
    else:
        FAILS.append("reports/u1/pg_*_churn_all_s1.json missing (tab:pgvector unbacked)")

    print(f"checked {len(OKS)} numbers, {len(FAILS)} problems")
    if FAILS:
        print("\nFAILURES:")
        for f in FAILS:
            print("  x", f)
        return 1
    print("OK: every paper number traces to an artifact")
    return 0


if __name__ == "__main__":
    sys.exit(main())
