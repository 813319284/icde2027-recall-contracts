#!/usr/bin/env python3
"""Recompute the closed-loop certificates from the logged audit counts, with the level the
paper's Algorithm 1 actually prescribes.

Why this exists. The closed-loop runs (`exp_t3_closed_loop.py`) were driven by the controller's
*screening* statistic (an empirical-Bernstein bound) and stored a two-sided verdict taken at the
default effort `ef0`. That is not the object Theorem 1 certifies: (i) the bound must be the
exact finite-population limit, and (ii) when a policy chooses its operating point from the same
audit, the level must be split over the candidate grid. The paper now says both things, so the
numbers it reports must come from that computation.

The stored per-round log records the audited violation rate at every candidate effort, so the
certificate can be recomputed exactly without re-running the index experiments:

    k_ef     = round(F_hat(ef) * m)                      audited violations at effort ef
    alpha_w  = 6 * delta / (pi^2 * w^2)                  the spending schedule
    level    = alpha_w / 2 / |E|                         two decisions x candidate grid
    U_ef     = K+(k_ef; m, N, level) / N                 exact upper limit
    L_ef     = K-(k_ef; m, N, level) / N                 exact lower limit
    verdict  = pass if U<=phi else reject if L>phi else undetermined      (at the served ef)

    python3 scripts/exp_t3_recheck.py      # -> reports/t3/certificate_recheck.json
"""
from __future__ import annotations

import glob
import json
import os
import sys

import numpy as np
from scipy.stats import hypergeom

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _find_repo(start: str) -> str:
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
PHI, DELTA = 0.05, 0.05
EF_GRID = [16, 32, 64, 128, 256]


def kplus(k: int, n: int, N: int, alpha: float) -> int:
    if n >= N:
        return int(min(N, max(k, 0)))
    lo, hi = float(k), float(N)
    for _ in range(50):
        mid = 0.5 * (lo + hi)
        K = int(round(mid))
        if float(hypergeom.cdf(k, N, max(K, 0), n)) >= alpha:
            lo = mid
        else:
            hi = mid
    return int(round(min(float(N), lo)))


def kminus(k: int, n: int, N: int, alpha: float) -> int:
    if n >= N:
        return int(min(N, max(k, 0)))
    lo, hi = 0.0, float(N)
    for _ in range(50):
        mid = 0.5 * (lo + hi)
        K = int(round(mid))
        if float(hypergeom.sf(k - 1, N, max(K, 0), n)) >= alpha:
            hi = mid
        else:
            lo = mid
    return int(round(max(0.0, min(float(N), hi))))


def verdict_at(round_d: dict, ef: int, nq: int, m: int, w: int) -> tuple[str, float, float]:
    f_hat = round_d["f_hat"]
    key = str(ef)
    if key not in f_hat:
        key = min(f_hat, key=lambda e: abs(int(e) - ef))
    k = int(round(f_hat[key] * m))
    alpha_w = 6.0 * DELTA / (np.pi ** 2 * (w + 1) ** 2)
    level = alpha_w / 2.0 / len(EF_GRID)
    U = kplus(k, m, nq, level) / nq
    L = kminus(k, m, nq, level) / nq
    v = "pass" if U <= PHI else ("reject" if L > PHI else "undetermined")
    return v, U, L


def main() -> int:
    """Audit the stored verdicts against the exact computation, rather than re-deriving them.

    The runs now record `ef_served` (the configuration the epoch's traffic was answered at),
    so the check is: does the verdict in the log equal the exact hypergeometric decision at
    that point with the level the paper prescribes? A mismatch means the table and the
    certificate disagree, which is exactly the failure the second review found.
    """
    out, mismatches = {}, []
    for path in sorted(glob.glob(os.path.join(REPO, "reports", "t3", "t3_*_churn_*_s*.json"))):
        name = os.path.basename(path)
        if "aggregate" in name or "frame" in name or "certificate" in name:
            continue
        d = json.load(open(path))
        if isinstance(d, list):
            d = d[0] if d else {}
        rounds = d.get("rounds") or []
        if not rounds or "ef_served" not in rounds[0]:
            continue
        nq = d.get("nq") or 400
        # N is the number of *arrivals* in the epoch: with the default "mixed" audit frame the
        # epoch holds the old-frame and new-frame queries, i.e. 2 * nq. Older logs do not
        # record it, so fall back to the construction the script uses.
        n_arr = rounds[0].get("n_arrivals") or (2 * nq if d.get("audit_frame", "mixed") == "mixed" else nq)
        counts = {"pass": 0, "reject": 0, "undetermined": 0}
        false_pass = 0
        for r in rounds:
            m = int(r.get("audit_m") or 200)
            v, U, L = verdict_at(r, int(r["ef_served"]), n_arr, m, int(r["t"]))
            counts[r["verdict"]] += 1
            if r["verdict"] != v:
                # a decision whose limit lands within one count of phi is a tie: the bisection
                # in two independent implementations can land on either side. Anything else is
                # a real disagreement and must be zero.
                tie = (abs(U - PHI) <= 1.0 / n_arr) or (abs(L - PHI) <= 1.0 / n_arr)
                mismatches.append({"run": name, "t": r["t"], "stored": r["verdict"], "exact": v,
                                   "U": round(U, 4), "L": round(L, 4), "tie": bool(tie)})
            if r["verdict"] == "pass" and r.get("f_true", 1.0) > PHI:
                false_pass += 1
        out[name] = {"rounds": len(rounds), "audit_m": m, "nq": n_arr,
                     "verdicts": counts, "false_pass": false_pass,
                     "policy": d.get("policy"), "drift": d.get("drift")}
    dst = os.path.join(REPO, "reports", "t3", "certificate_recheck.json")
    json.dump({"runs": out, "mismatches": mismatches}, open(dst, "w"), indent=1)
    tot = {"pass": 0, "reject": 0, "undetermined": 0}
    fp = 0
    for v in out.values():
        for k in tot:
            tot[k] += v["verdicts"][k]
        fp += v["false_pass"]
    print("wrote %s (%d runs)" % (dst, len(out)))
    print("  verdict totals:", tot, "false passes:", fp)
    hard = [m for m in mismatches if not m["tie"]]
    print("  verdict mismatches: %d (boundary ties: %d, hard: %d)" %
          (len(mismatches), len(mismatches) - len(hard), len(hard)))
    for mm in mismatches[:5]:
        print("   ", mm)
    return 0 if not hard else 1


if __name__ == "__main__":
    sys.exit(main())
