#!/usr/bin/env python3
"""The third lever: build-time parameters. What tail is reachable at a given ef?

Measures, for (M, efConstruction) grid: build wall-clock, then F(tau) at a few
ef values on the same query set. This separates the *intrinsic* tail of a
configuration from the tombstone-induced part, which is what a rebuild can fix.
"""
from __future__ import annotations

import json
import os
import sys
import time

import faiss
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from icde_lab.datasets import initial_split, load_ann_benchmark   # noqa: E402
from icde_lab.drift import build_plan                             # noqa: E402
from icde_lab.indexes import AnnIndex                             # noqa: E402
from icde_lab.logio import dump_json                              # noqa: E402
from icde_lab.truth import ExactKNN, recall_at_k                  # noqa: E402

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))


def main():
    n_base = int(os.environ.get("NBASE", 800_000))
    data = os.environ.get("DATA", "sift-128-euclidean.hdf5")
    ds = load_ann_benchmark(data)
    base0, incoming = initial_split(ds, n_base, seed=0)
    plan = build_plan(incoming, ds.test, 3, 20_000, 500, family="append", seed=0)
    # grow to 860k so the measurement is on a drifted, non-trivial index
    exact = ExactKNN(ds.dim, ds.metric).reset_with(base0)
    for rp in plan:
        exact.add(rp.inserts)
    q = np.concatenate([plan[-1].q_old, plan[-1].q_new])
    truth = exact.knn(q, 10)
    base_all = np.concatenate([base0] + [rp.inserts for rp in plan])

    out = {}

    for M in (16, 32, 48, 64):
        for efc in (100, 200):
            t0 = time.perf_counter()
            idx = AnnIndex(ds.dim, ds.metric, "hnsw", M=M, ef_construction=efc).build(base_all)
            build_s = time.perf_counter() - t0
            row = {"M": M, "efC": efc, "build_s": build_s, "F": {}, "mean": {}}
            for ef in (32, 64, 128):
                f, _, _ = idx.search_ef(q, 10, ef)
                rec = recall_at_k(f, truth, 10)
                row["F"][str(ef)] = float((rec < 0.95).mean())
                row["mean"][str(ef)] = float(rec.mean())
            out[f"M{M}_efC{efc}"] = row
            print(f"M={M:2d} efC={efc:3d} build={build_s:6.1f}s  "
                  f"F(.95)@ef32/64/128 = {row['F']['32']:.3f}/{row['F']['64']:.3f}/{row['F']['128']:.3f}",
                  flush=True)
    dump_json(os.path.join(REPO, "reports", "index_params.json"), out)


if __name__ == "__main__":
    main()
