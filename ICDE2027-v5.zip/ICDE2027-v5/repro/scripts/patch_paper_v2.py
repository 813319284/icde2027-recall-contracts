#!/usr/bin/env python3
"""Narrative patch that follows from the database result (DECISIONS D011).

Four edits, each an assert-guarded whole-block replacement (D007):

 1. the abstract gains the one sentence a systems PC reads for: the loop also runs inside a
    database;
 2. the contributions gain the fifth bullet;
 3. ``Scope of the claims'' item (5) said no production database was integrated. That is now
    stale, and a stale scope statement is worse than a weakness---it would be wrong;
 4. the conclusion closes on the same point.

    python3 scripts/patch_paper_v2.py --apply
"""
from __future__ import annotations

import argparse
import os
import shutil
import sys
import time

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
TEX = os.path.join(REPO, "paper", "main.tex")

EDITS = [
    # ---- 1. abstract -------------------------------------------------------------
    ("mean recall 0.9498, the 0.95 target to three decimals,\nserves",
     "mean recall exactly at the 0.95 target\nserves"),
    ("the contract does not. No distribution-free, mean-only\ncertificate can do better:",
     "the contract does not. The loop runs unchanged inside PostgreSQL with pgvector, where\n"
     "rebuilds still buy no tail quality. No distribution-free, mean-only certificate can do\n"
     "better:"),
    # ---- 1b. trims that pay for 1 and keep the abstract under 300 words --------------
    ("over 1000 twelve-epoch runs near the contract boundary, a fixed-sample",
     "over 1000 boundary runs, a fixed-sample"),
    ("and across three index families the compliant intervention differs---effort,",
     "and the compliant intervention differs across index families---effort,"),
    ("redesign, or a change of representation.", "redesign, or representation."),
    ("We give an audit-sizing law\nthat converts a target margin into an audit rate,",
     "We give an audit-sizing law\nconverting a target margin into an audit rate,"),
    ("certifying a 0.95 tail at 0.05 requires a mean of at least",
     "certifying a 0.95 tail at 0.05 needs a mean of at least"),
    ("The loop runs unchanged inside PostgreSQL with pgvector, where",
     "The same loop runs inside PostgreSQL with pgvector, where"),
    ("The same loop runs inside PostgreSQL with pgvector, where\nrebuilds still buy no tail quality.",
     "The loop runs inside PostgreSQL with pgvector; rebuilds still buy no tail quality."),
    ("sign off on \\textbf{97\\%} of our drift", "sign off on \\textbf{97\\%} of drift"),
    ("while $\\alpha$-spent exact bounds", "while $\\alpha$-spent bounds"),
    ("on a bounded\nexact-audit budget", "on a bounded\naudit budget"),
    ("governed\nby one offline average", "governed\nby an offline average"),
    ("rebuilds still buy no tail quality.", "rebuilds buy no tail quality."),
    # ---- 2. contributions --------------------------------------------------------
    ("""parameters against each other, to show that rebuilds do not buy tail quality, and to
identify when no available action can comply at all.
\\end{itemize}""",
     """parameters against each other, to show that rebuilds do not buy tail quality, and to
identify when no available action can comply at all.
\\item \\textbf{The loop in a database} (\\cref{sec:repair}). The closed loop runs unchanged
inside PostgreSQL~16 with pgvector: the audit is an exact scan of the served table, the
certificate is the same one, the three levers keep the identities the prototype gives them,
and the audit-to-query ratio moves from $239\\times$ to $29\\times$---set by the engine,
next to an absolute cost set by the workload and the execution environment.
\\end{itemize}"""),
    # ---- 3. scope ---------------------------------------------------------------
    ("""(5) We do not integrate a production vector database; the prototype
uses public data and controlled drift.""",
     """(5) One real system is integrated---PostgreSQL~16 with pgvector, closed
loop and all (\\cref{sec:repair})---while the rest of the evaluation uses public data and
controlled drift; run-time behaviour is claimed only for the systems we ran."""),
    # ---- 4. conclusion ----------------------------------------------------------
    ("""rebuilds are for tombstones and memory, contracts are for the tail. Systems that
monitor the tail can say which they need; systems that monitor the mean cannot tell.""",
     """rebuilds are for tombstones and memory, contracts are for the tail. Systems that
monitor the tail can say which they need; systems that monitor the mean cannot tell. The
loop closes inside a database as it does in a prototype, which is where a contract has to
live if anyone is to be held to it."""),
]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()
    tex = open(TEX, encoding="utf-8").read()
    if "The loop runs inside PostgreSQL with pgvector" in tex:
        print("already patched")
        return 0
    if not a.apply:
        for old, new in EDITS:
            print(f"{'OK  ' if tex.count(old) == 1 else 'MISS'}  {old.splitlines()[0][:70]}")
        return 0
    for old, new in EDITS:
        assert tex.count(old) == 1, f"anchor not unique/found: {old[:60]!r} ({tex.count(old)})"
        tex = tex.replace(old, new)
    assert "The loop runs inside PostgreSQL with pgvector" in tex
    assert "One real system is integrated" in tex
    assert "The loop in a database" in tex
    bak = os.path.join(REPO, "paper", ".backup", f"main.tex.{time.strftime('%Y%m%d-%H%M%S')}")
    os.makedirs(os.path.dirname(bak), exist_ok=True)
    shutil.copy2(TEX, bak)
    open(TEX, "w", encoding="utf-8").write(tex)
    print(f"patched {TEX}\nbackup {bak}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
