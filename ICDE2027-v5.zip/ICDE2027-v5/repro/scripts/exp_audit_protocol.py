#!/usr/bin/env python3
"""Unified randomization protocol: every audit rule judged on run-level error.

Why this script exists (and why it is the paper's central experiment): the
statistical claim is about a *run* (a sequence of decision epochs), not about a
single epoch. Comparing rules per epoch rewards rules that ignore multiplicity.
Here every rule sees the SAME audit coins in the SAME epochs of the SAME
trajectory (paired design), and we report:

  run-level false-certification rate  P(any epoch PASSes while F > phi)   <- the promise
  run-level true-certification rate   P(a fully compliant run is PASSed)  <- usefulness
  per-epoch false-certification rate                                      <- the temptation

Rules: alpha-spent exact (ours), fixed-sample exact, cluster bootstrap, one-shot
audit at deployment, mean-recall rule.
"""
from __future__ import annotations

EF_GRID = [16, 32, 64, 128, 256]   # the candidate grid Algorithm 1 splits over

import argparse
import json
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from exp_t1_audit import clopper_pearson_upper, hypergeom_upper, load_worlds  # noqa: E402

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))


def alpha_spend(delta: float, w: int, mode: str = "geom", horizon: int = 12) -> float:
    """Error budget per epoch.

    geom    : 6/pi^2 * w^-2  -> sums to delta over an unbounded horizon
              (the right choice when the run length is unknown).
    uniform : delta / horizon -> the best choice when the horizon is known;
              the cost of anytime validity is then a factor `horizon` in level.
    """
    if mode == "uniform":
        return delta / max(horizon, 1)
    return delta * 6.0 / (np.pi ** 2 * max(w, 1) ** 2)


def plug_in_quantile_certify(rec_aud: np.ndarray, tau: float, phi: float) -> bool:
    """Plug-in quantile rule: certify if the phi-quantile of audited recalls is >= tau.

    This is what a practitioner does without statistical correction: estimate the tail
    from the sample and compare. It has no finite-sample correction and spends no error
    budget across epochs, which is exactly what we want to contrast against.
    """
    m = len(rec_aud)
    k = max(1, int(np.ceil(phi * (m + 1))))      # the phi-quantile, not its complement
    if k > m:
        return False
    return bool(np.sort(rec_aud)[k - 1] >= tau)


def wilson(k: int, n: int, z: float = 1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))


def cluster_bootstrap_upper(viol: np.ndarray, cl: np.ndarray, alpha: float,
                            rng: np.random.Generator, B: int = 200) -> float:
    uniq = np.unique(cl)
    if len(uniq) < 3:
        return 1.0
    idx = {c: np.flatnonzero(cl == c) for c in uniq}
    boots = np.empty(B)
    for b in range(B):
        pick = rng.choice(uniq, size=len(uniq), replace=True)
        vals = np.concatenate([viol[idx[c]] for c in pick])
        boots[b] = vals.mean()
    return float(np.quantile(boots, 1 - alpha))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tau", type=float, default=0.95)
    ap.add_argument("--phi", type=float, default=0.05)
    ap.add_argument("--p", type=float, default=0.15)
    ap.add_argument("--delta", type=float, default=0.05)
    ap.add_argument("--spend", default="geom", choices=["geom", "uniform"])
    ap.add_argument("--runs", type=int, default=300)
    ap.add_argument("--seed-base", type=int, default=1_000_003)
    ap.add_argument("--epochs", type=int, default=12)
    ap.add_argument("--min-n", type=int, default=2000)
    ap.add_argument("--regime", default="mixed", choices=["mixed", "boundary", "alternating"],
                    help="boundary: resample each epoch to sit just above/below phi")
    ap.add_argument("--margin", type=float, default=0.006)
    ap.add_argument("--epoch-n", type=int, default=4000)
    ap.add_argument("--adaptive-rate", action="store_true",
                    help="let the audit rate depend on past verdicts (still predictable)")
    ap.add_argument("--out", default="reports/s0/audit_protocol.json")
    a = ap.parse_args()

    worlds = load_worlds(min_n=a.min_n)
    truth = {k: float((v["recall"] < a.tau).mean()) for k, v in worlds.items()}
    compliant = [k for k in worlds if truth[k] <= a.phi]
    violating = [k for k in worlds if truth[k] > a.phi]
    print(f"worlds={len(worlds)}  compliant={len(compliant)}  violating={len(violating)}"
          f"  p={a.p} delta={a.delta} runs={a.runs} epochs={a.epochs}")
    if not compliant or not violating:
        raise SystemExit("need both compliant and violating worlds")

    rules = ["ours", "exact_fixed", "bootstrap", "plugin", "oneshot", "mean"]
    run_false = {r: 0 for r in rules}
    run_true = {r: 0 for r in rules}
    run_both = {r: 0 for r in rules}      # mixed runs (compliant then violating)
    epoch_fp = {r: 0 for r in rules}
    epoch_cert = {r: 0 for r in rules}
    epoch_tp = {r: 0 for r in rules}
    epoch_good = 0
    epoch_total = 0

    for run in range(a.runs):
        rng = np.random.default_rng(a.seed_base + run)
        p_hist = [a.p]                       # adaptive rate state, reset per run
        # trajectory: half compliant epochs, then half violating (drift story),
        # worlds drawn independently per run -> independent world draws + audit coins
        if a.regime == "alternating":
            # worst case for a spending schedule: violations interleaved with compliant epochs,
            # so every late epoch carries a small alpha_w and a violating world behind it
            seq = []
            for w in range(a.epochs):
                seq.append(rng.choice(violating) if w % 2 == 1 else rng.choice(compliant))
        else:
            seq = ([rng.choice(compliant) for _ in range(a.epochs // 2)] +
                   [rng.choice(violating) for _ in range(a.epochs - a.epochs // 2)])
        cert = {r: np.zeros(len(seq), dtype=bool) for r in rules}
        oneshot_ub = None
        for w, name in enumerate(seq):
            W = worlds[name]
            viol_full = (W["recall"] < a.tau).astype(float)
            if a.regime == "boundary":
                # resample the epoch's query population so its true violation rate sits
                # at phi +/- margin: the only regime where certification is tight
                target = (a.phi - a.margin) if truth[name] <= a.phi else (a.phi + a.margin)
                n_ep = a.epoch_n
                n_v = int(round(target * n_ep))
                i_v = np.flatnonzero(viol_full > 0.5)
                i_c = np.flatnonzero(viol_full <= 0.5)
                if len(i_v) == 0 or len(i_c) == 0:
                    sel = rng.choice(len(viol_full), size=n_ep, replace=True)
                else:
                    sel = np.concatenate([rng.choice(i_v, size=n_v, replace=True),
                                          rng.choice(i_c, size=n_ep - n_v, replace=True)])
                    rng.shuffle(sel)
                W = {"recall": W["recall"][sel], "cluster": W["cluster"][sel]}
            viol = (W["recall"] < a.tau).astype(float)
            cl = W["cluster"]
            N = len(viol)
            p_epoch = p_hist[-1] if a.adaptive_rate else a.p
            aud = rng.random(N) < p_epoch        # ONE set of coins, shared by all rules
            m = max(int(aud.sum()), 1)
            k = int(viol[aud].sum())
            aw = alpha_spend(a.delta, w + 1, a.spend, a.epochs)
            # Algorithm 1 makes two decisions per epoch (PASS and REJECT) and, when a
            # controller picks the operating point from the same audit, also splits over the
            # candidate grid. The power table must therefore be computed at alpha_w/2/|E|,
            # not at the full alpha_w, or it reports the power of a one-sided PASS-only rule.
            cert["ours"][w] = hypergeom_upper(k, m, N, aw / 2.0 / len(EF_GRID)) <= a.phi
            cert["exact_fixed"][w] = hypergeom_upper(k, m, N, a.delta) <= a.phi
            cert["bootstrap"][w] = cluster_bootstrap_upper(viol[aud], cl[aud], a.delta, rng) <= a.phi
            if oneshot_ub is None:
                oneshot_ub = hypergeom_upper(k, m, N, a.delta)
            cert["oneshot"][w] = oneshot_ub <= a.phi
            rec_aud = W["recall"][aud]
            cert["plugin"][w] = plug_in_quantile_certify(rec_aud, a.tau, a.phi)
            lb = float(rec_aud.mean() - 1.645 * rec_aud.std(ddof=1) / math.sqrt(m))
            cert["mean"][w] = lb >= a.tau
            if a.adaptive_rate:
                # predictable: the next epoch's rate depends only on verdicts already issued
                p_hist.append(min(0.40, p_hist[-1] * 2.0) if cert["ours"][w]
                              else max(a.p, p_hist[-1] / 2.0))

        tr = np.array([float((worlds[s]["recall"] < a.tau).mean()) if a.regime in ("mixed", "alternating")
                       else ((a.phi - a.margin) if truth[s] <= a.phi else (a.phi + a.margin))
                       for s in seq])
        bad = tr > a.phi
        good = ~bad
        epoch_total += len(seq)
        for r in rules:
            if np.any(cert[r] & bad):
                run_false[r] += 1
                run_both[r] += 1
            if np.all(cert[r][good]) and good.any():
                run_true[r] += 1
            epoch_fp[r] += int(np.sum(cert[r] & bad))
            epoch_tp[r] += int(np.sum(cert[r] & good))
            epoch_cert[r] += int(cert[r].sum())
        epoch_good += int(good.sum())

    print(f"\n{'rule':12s} {'run FCR':>8s} {'95% CI':>16s} {'run TCR':>8s} {'epoch TCR':>10s} {'epoch FCR':>10s} {'cert/ep':>9s}")
    out = {"args": vars(a), "n_worlds": len(worlds), "rules": {}}
    for r in rules:
        fcr = run_false[r] / a.runs
        lo, hi = wilson(run_false[r], a.runs)
        tcr = run_true[r] / a.runs
        efcr = epoch_fp[r] / max(epoch_total, 1)
        ce = epoch_cert[r] / max(epoch_total, 1)
        ptcr = epoch_tp[r] / max(epoch_good, 1)
        print(f"{r:12s} {fcr:8.3f} [{lo:.3f},{hi:.3f}] {tcr:8.3f} {ptcr:10.3f} {efcr:10.3f} {ce:11.3f}")
        out["rules"][r] = {"run_fcr": fcr, "ci": [lo, hi], "run_tcr": tcr,
                           "epoch_tcr": ptcr, "epoch_fcr": efcr, "cert_per_epoch": ce}
    with open(os.path.join(REPO, a.out), "w") as f:
        json.dump(out, f, indent=1)
    print(f"\nwrote {a.out}")
    print("判据：run FCR 才是合同承诺的量（应 ≤ delta）；epoch FCR 是单期视角，会奖励不做误差预算的规则。")


if __name__ == "__main__":
    main()
