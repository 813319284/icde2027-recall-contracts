#!/usr/bin/env python3
"""Aggregate the closed-loop runs into the table the paper prints, from the per-seed artifacts.

The closed-loop table used to be a hand-maintained table in LaTeX. It is now generated here, so
the table, the prose and the logs cannot drift: every cell is max/mean over the seeds of the
runs the scripts actually produced.

What is measured, and at which configuration (this is the point the second review made):
`ef_served` is the effort in force while the epoch's arrivals were answered. The certificate and
the held-out violation rate are both taken there; the action chosen from that audit applies to
the next epoch (`ef_next`). So a controller's first epoch can be out of contract and later ones
compliant, and the table says exactly that.

    python3 scripts/make_t3_table.py            # -> reports/t3/aggregate_final.json + tex block
"""
from __future__ import annotations

import glob
import json
import os
import sys

import numpy as np

def _find_repo(start: str) -> str:
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle."""
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d); d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
POLICIES = ["never", "count_300000", "periodic_4", "ctrl_mean", "ef_auto", "ctrl_rebuild"]
LABELS = {
    "never": "never",
    "count_300000": "insert-count threshold",
    "periodic_4": "periodic rebuild (every 4)",
    "ctrl_mean": "mean-monitor controller",
    "ef_auto": "search effort only",
    "ctrl_rebuild": "contract controller",
}


def load_runs(tag="final", drift="churn"):
    out = {}
    for pol in POLICIES:
        runs = []
        for path in sorted(glob.glob(os.path.join(REPO, "reports", "t3", f"t3_{tag}_{drift}_{pol}_s*.json"))):
            if "aggregate" in path:
                continue
            runs.append(json.load(open(path)))
        if runs:
            out[pol] = runs
    return out


def summarise(runs):
    viol = [sum(1 for r in d["rounds"] if r["f_true"] > 0.05) for d in runs]
    rb = [sum(1 for r in d["rounds"] if r["action"] == "rebuild") for d in runs]
    rb_s = float(sum(d["summary"]["rebuild_s"] for d in runs) / len(runs))
    lat = float(np.mean([np.mean([r["latency_ms"] for r in d["rounds"]]) for d in runs]))
    passes = [sum(1 for r in d["rounds"] if r["verdict"] == "pass") for d in runs]
    false_pass = [sum(1 for r in d["rounds"] if r["verdict"] == "pass" and r["f_true"] > 0.05)
                  for d in runs]
    mean_f = float(np.mean([np.mean([r["f_true"] for r in d["rounds"]]) for d in runs]))
    lat_each = [round(float(np.mean([r["latency_ms"] for r in d["rounds"]])), 3) for d in runs]
    return {"viol": viol, "rb": rb, "rb_s": rb_s, "lat": lat, "meanF": mean_f,
            "lat_each": lat_each,
            "passes": passes, "false_pass": false_pass, "n": len(runs),
            "verdicts": {v: sum(1 for d in runs for r in d["rounds"] if r["verdict"] == v)
                         for v in ("pass", "reject", "undetermined")}}


def main() -> int:
    runs = load_runs()
    if not runs:
        print("no closed-loop artifacts"); return 1
    agg = {pol: summarise(rs) for pol, rs in runs.items()}
    dst = os.path.join(REPO, "reports", "t3", "aggregate_final.json")
    json.dump(agg, open(dst, "w"), indent=1)

    lines = []
    for pol in POLICIES:
        if pol not in agg:
            continue
        a = agg[pol]
        lines.append("%s & %d/%d & %d & %.1f & %.3f\\\\" % (
            LABELS[pol], max(a["viol"]), max(len(r["rounds"]) for r in runs[pol]),
            max(a["rb"]), a["rb_s"], a["lat"]))
    block = ("\\midrule\n" + "\n".join(lines) + "\n\\bottomrule")
    open(os.path.join(REPO, "reports", "t3", "closedloop_rows.tex"), "w").write(block + "\n")
    print(block)
    print("\nwrote", dst)
    for pol in POLICIES:
        if pol in agg:
            a = agg[pol]
            print(f"  {pol:14s} viol={a['viol']} rb={a['rb']} rb_s={a['rb_s']:.1f} "
                  f"lat={a['lat']:.3f} passes={a['passes']} false={a['false_pass']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
