#!/usr/bin/env python3
"""Literature search over arXiv (+ Crossref fallback) via plain HTTPS.

Why not the web_search plugin: it intermittently fails (ByteString error on
non-Latin prompts) and cannot be relied on for a 55h sprint. This helper is
deterministic, scriptable, and prints dates so we can see how crowded a slot is
*right now* (the decisive signal: a slot colonised last week is not a slot).
"""
from __future__ import annotations

import argparse
import html
import re
import sys
import urllib.parse
import urllib.request

ARXIV = "https://export.arxiv.org/api/query"


def _get(url: str, timeout: int = 30) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": "icde-litsearch/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def arxiv(query: str, n: int = 10, sort: str = "relevance"):
    q = urllib.parse.quote(query)
    url = f"{ARXIV}?search_query={q}&max_results={n}&sortBy={sort}&sortOrder=descending"
    xml = _get(url)
    out = []
    for e in re.findall(r"<entry>(.*?)</entry>", xml, re.S):
        def g(tag):
            m = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", e, re.S)
            return html.unescape(re.sub(r"\s+", " ", m.group(1))).strip() if m else ""
        out.append({"title": g("title"), "date": g("published")[:10], "id": g("id"),
                    "abs": g("summary")})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("queries", nargs="+")
    ap.add_argument("-n", type=int, default=6)
    ap.add_argument("--abs", type=int, default=320, help="chars of abstract to print")
    ap.add_argument("--sort", default="relevance", choices=["relevance", "submittedDate"])
    a = ap.parse_args()
    for q in a.queries:
        print("=" * 100)
        print("QUERY:", q)
        try:
            res = arxiv(q, a.n, a.sort)
        except Exception as exc:  # noqa: BLE001
            print("  FAILED:", exc)
            continue
        if not res:
            print("  (no results)")
        for r in res:
            print(f"  [{r['date']}] {r['title']}\n      {r['id']}\n      {r['abs'][:a.abs]}...")


if __name__ == "__main__":
    main()
