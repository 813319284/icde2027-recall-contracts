#!/usr/bin/env python3
"""U1: the recall contract, closed loop, inside PostgreSQL + pgvector.

The FAISS prototype in ``exp_t3_closed_loop.py`` is an index in a Python process. ICDE
reviewers are entitled to ask whether the loop survives contact with a real database: a
storage engine that decides on its own when to compact, an index that keeps dead tuples
after ``DELETE``, and a planner that will happily ignore the index if the cost says so.

This script runs the same protocol against a real PostgreSQL 16 server with pgvector
0.8.7 (``env/pgvector/Dockerfile``), so every number below is a database number:

  * base vectors are written with ``COPY``, the index is a real ``CREATE INDEX ... USING
    hnsw``, and the effort lever is ``SET hnsw.ef_search`` (a session GUC, not a knob we
    invented);
  * drift is churn implemented as ``DELETE`` + ``COPY`` against the same table, so the
    index accumulates dead tuples exactly as it would in production, until ``REINDEX``;
  * the audit frame is the arriving query stream; an audited query is answered *exactly*
    by the same table with ``SET LOCAL enable_indexscan = off``, which is the deployment
    situation the paper assumes (you hold the vectors and the right to scan them). The
    wall-clock cost of that scan is measured, not assumed;
  * the certificate is the exact finite-population limit with geometric alpha spending
    (``hypergeom_upper``/``hypergeom_lower`` from ``exp_t1_audit.py``), i.e. the same code
    the paper's numbers come from;
  * the held-out queries that measure the realized violation rate are never shown to any
    policy.

Policies (all see the same trajectory and the same audit budget):

  never        do nothing                     (what a deployment does by default)
  periodic_k   REINDEX every k epochs         (the maintenance reflex)
  ef_auto      effort lever only              (never rebuild)
  ctrl         contract controller            (effort first, then REINDEX when the
                                               post-rebuild bound is projected to pass)
  ctrl_mean    same controller, mean-recall certificate (the ablation that matters)

    python3 scripts/exp_u1_pgvector.py --policies never,ctrl
    python3 scripts/exp_u1_pgvector.py                     # full matrix

Exit code 0 on success; artifacts under reports/u1/.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

import faiss
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from icde_lab.datasets import load_ann_benchmark          # noqa: E402
from icde_lab.logio import dump_json                      # noqa: E402
from exp_t1_audit import hypergeom_lower, hypergeom_upper  # noqa: E402

import psycopg                                            # noqa: E402

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
EF_GRID = [16, 32, 64, 128, 256]
VEC = "vector(128)"


def eb_upper(k: int, m: int, delta: float) -> float:
    """Empirical-Bernstein upper bound (used only for the mean-recall ablation)."""
    if m == 0:
        return 1.0
    phat = k / m
    lt = np.log(2.0 / delta)
    hw = np.sqrt(2.0 * phat * (1 - phat) * lt / m) + 7.0 * lt / (3.0 * max(m - 1, 1))
    return float(min(1.0, phat + hw))


def lit(vec: np.ndarray) -> str:
    """pgvector text literal."""
    return "[" + ",".join(f"{x:.6g}" for x in vec) + "]"


class PG:
    """Thin wrapper: connection + the calls the protocol needs."""

    def __init__(self, dsn: str):
        self.conn = psycopg.connect(dsn, autocommit=True)
        self.cur = self.conn.cursor()

    def q(self, sql, params=None):
        self.cur.execute(sql, params)
        if self.cur.description is None:          # DDL/DML carry no result set
            return []
        return self.cur.fetchall()

    def setup(self, table: str = "items", autovacuum: bool = False):
        """Empty table, no index: the index is built once, in bulk, after the base load.

        autovacuum is off on this table by default: dead tuples are the point of the churn
        experiment (pgvector's HNSW keeps its entries until REINDEX), and letting a
        background vacuum run mid-epoch would make two policies' timings incomparable.
        It is recorded in the artifact.
        """
        self.q(f"DROP TABLE IF EXISTS {table}")
        self.q(f"CREATE TABLE {table} (id bigint PRIMARY KEY, vec {VEC})")
        self.q(f"ALTER TABLE {table} SET (autovacuum_enabled = {str(autovacuum).lower()})")

    def create_index(self, m: int, efc: int, table: str = "items"):
        t0 = time.perf_counter()
        self.q(f"CREATE INDEX {table}_hnsw ON {table} USING hnsw (vec vector_l2_ops) "
               f"WITH (m = {m}, ef_construction = {efc})")
        self.q(f"ANALYZE {table}")
        return time.perf_counter() - t0

    def copy_rows(self, ids: np.ndarray, vecs: np.ndarray, table: str = "items"):
        with self.cur.copy(f"COPY {table} (id, vec) FROM STDIN") as cp:
            for i, v in zip(ids, vecs):
                cp.write_row((int(i), lit(v)))

    def delete_ids(self, ids: np.ndarray, table: str = "items"):
        self.q(f"DELETE FROM {table} WHERE id = ANY(%s)", (list(map(int, ids)),))

    def set_ef(self, ef: int):
        self.q(f"SET hnsw.ef_search = {int(ef)}")

    def knn(self, vecs: np.ndarray, k: int, table: str = "items", exact: bool = False):
        """One query at a time (real latency); returns (ids, per-query milliseconds)."""
        out, times = [], []
        if exact:                        # the audit: a scan of the same table, planner told so
            self.q("SET enable_indexscan = off")
            self.q("SET enable_bitmapscan = off")
        for v in vecs:
            t0 = time.perf_counter()
            rows = self.q(f"SELECT id FROM {table} ORDER BY vec <-> %s::vector LIMIT %s",
                          (lit(v), k))
            times.append((time.perf_counter() - t0) * 1e3)
            out.append([r[0] for r in rows])
        if exact:
            self.q("SET enable_indexscan = on")
            self.q("SET enable_bitmapscan = on")
        return out, np.asarray(times)

    def reindex(self, table: str = "items"):
        t0 = time.perf_counter()
        self.q(f"REINDEX INDEX {table}_hnsw")
        return time.perf_counter() - t0

    def vacuum(self, table: str = "items"):
        t0 = time.perf_counter()
        self.cur.execute(f"VACUUM (VERBOSE, ANALYZE) {table}")
        return time.perf_counter() - t0

    def counts(self, table: str = "items"):
        live = self.q(f"SELECT count(*) FROM {table}")[0][0]
        return int(live)


class Live:
    """In-process mirror of the live set, used for exact truth and for re-seeding."""

    def __init__(self, dim: int):
        self.dim = dim
        self.ids = np.zeros(0, dtype=np.int64)
        self.X = np.zeros((0, dim), dtype="float32")

    def add(self, ids: np.ndarray, vecs: np.ndarray):
        self.ids = np.concatenate([self.ids, ids])
        self.X = np.vstack([self.X, vecs])

    def drop(self, ids: np.ndarray):
        keep = ~np.isin(self.ids, ids)
        self.ids, self.X = self.ids[keep], self.X[keep]

    def flat(self):
        index = faiss.IndexFlatL2(self.dim)
        index.add(self.X)
        return index

    def exact_ids(self, queries: np.ndarray, k: int) -> list[list[int]]:
        """Exact k-NN over the live set, returned as *row ids* (not flat positions)."""
        _, pos = self.flat().search(np.ascontiguousarray(queries, dtype="float32"), k)
        return [[int(self.ids[p]) for p in row if p >= 0] for row in pos]


def recall_at_k(found: list[list[int]], truth: list[list[int]], k: int) -> np.ndarray:
    return np.array([len(set(f[:k]) & set(g[:k])) / k for f, g in zip(found, truth)], dtype=float)


def run(ds, args, policy: str) -> dict:
    rng = np.random.default_rng(args.seed + 7)
    pg = PG(args.dsn)
    pg.setup()

    Xtr = np.asarray(ds.train, dtype="float32")
    Qall = np.asarray(ds.test, dtype="float32")
    n_base = min(args.n_base, len(Xtr) - args.batch * args.rounds - 10)
    base = Xtr[:n_base]
    stream = Xtr[n_base:n_base + args.batch * args.rounds]

    base_ids = np.arange(n_base, dtype=np.int64)
    pg.copy_rows(base_ids, base)
    live = Live(ds.dim)
    live.add(base_ids, base)
    build_s = pg.create_index(args.m, args.efc)
    next_id = n_base
    deleted_total = 0

    ef_cur = args.ef0
    rounds, ref_F, last_rebuild = [], None, -10 ** 9
    wall0 = time.perf_counter()

    for t in range(args.rounds):
        t_phase = time.perf_counter()
        # ---- churn: DELETE a random block of live rows, COPY a block of new ones
        n_del = int(round(args.delete_frac * len(live.ids)))
        if n_del:
            victims = rng.choice(live.ids, size=n_del, replace=False)
            pg.delete_ids(victims)
            live.drop(victims)
            deleted_total += n_del
        ins = stream[t * args.batch:(t + 1) * args.batch]
        ins_ids = np.arange(next_id, next_id + len(ins), dtype=np.int64)
        next_id += len(ins)
        pg.copy_rows(ins_ids, ins)
        live.add(ins_ids, ins)

        t_ins = time.perf_counter() - t_phase
        t_phase = time.perf_counter()
        # ---- arrivals this epoch; p of them audited
        arrival = Qall[rng.choice(len(Qall), size=args.nq, replace=False)]
        a_idx = np.sort(rng.choice(args.nq, size=min(args.audit_m, args.nq // 2), replace=False))
        qa, qv = arrival[a_idx], np.delete(arrival, a_idx, axis=0)
        m = len(qa)

        # ---- THE AUDIT, inside the database: exact answers by scanning the same table
        truth_a, t_audit = pg.knn(qa, args.k, exact=True)
        audit_ms = float(np.mean(t_audit))
        t_audit_ph = time.perf_counter() - t_phase
        t_phase = time.perf_counter()

        rec_by_ef, lat_by_ef = {}, {}
        for ef in EF_GRID:
            pg.set_ef(ef)
            found, tt = pg.knn(qa, args.k)
            rec_by_ef[ef] = recall_at_k(found, truth_a, args.k)
            lat_by_ef[ef] = float(np.mean(tt))

        delta_w = args.delta * 6.0 / (np.pi ** 2 * (t + 1) ** 2)
        f_hat = {ef: float(np.mean(rec_by_ef[ef] < args.tau)) for ef in EF_GRID}
        f_ub = {ef: eb_upper(int(np.sum(rec_by_ef[ef] < args.tau)), m, delta_w / len(EF_GRID))
                for ef in EF_GRID}
        # NB: the verdict is computed *after* the policy acts (below), at the operating
        # point the service actually serves. Because that point is chosen from the same
        # audit sample, the one-sided budget is split over the ef grid -- a union bound
        # over |EF_GRID| candidate operating points -- so validity survives data-dependent
        # ef selection.

        # ---- policy: decides from the audit alone
        action, rebuild_s, vacuum_s, certified = "none", 0.0, 0.0, False
        ok_efs = [ef for ef in sorted(f_ub) if f_ub[ef] <= args.phi]
        if policy == "never":
            pass
        elif policy.startswith("periodic_"):
            if (t + 1) % int(policy.split("_")[1]) == 0:
                rebuild_s = pg.reindex()
                action = "rebuild"
        elif policy == "ef_auto":
            ef_cur = ok_efs[0] if ok_efs else min(f_ub, key=lambda e: f_ub[e])
            action = "ef"
        elif policy in ("ctrl", "ctrl_mean"):
            if policy == "ctrl":
                certified = bool(ok_efs)
            else:                              # mean-recall certificate: the ablation
                rec = rec_by_ef[ef_cur]
                lb = float(rec.mean() - 1.645 * rec.std(ddof=1) / np.sqrt(max(len(rec), 2)))
                certified = bool(lb >= args.tau)
            if certified:
                pass                      # the statistic it trusts says fine: do nothing
            elif ok_efs:
                if ok_efs[0] != ef_cur:
                    action, ef_cur = "ef", ok_efs[0]
            else:
                ef_cur = min(f_ub, key=lambda e: f_ub[e])
                action = "ef"
                projected = ref_F if ref_F is not None else 0.5 * (1.0 - np.mean(list(f_hat.values())))
                proj_ub = eb_upper(int(round(projected * m)), m, delta_w)
                if proj_ub <= args.phi and (t - last_rebuild) >= args.cooldown:
                    rebuild_s = pg.reindex()
                    vacuum_s = pg.vacuum()
                    action, ef_cur, last_rebuild = "rebuild", args.ef0, t
                    certified = True
        if action == "rebuild":
            ref_F = None

        t_grid_ph = time.perf_counter() - t_phase
        t_phase = time.perf_counter()
        # ---- verdict at the operating point chosen above
        k_cur = int(np.sum(rec_by_ef[ef_cur] < args.tau))
        u_cur = hypergeom_upper(k_cur, m, args.nq, delta_w / 2.0 / len(EF_GRID))
        l_cur = hypergeom_lower(k_cur, m, args.nq, delta_w / 2.0 / len(EF_GRID))
        verdict = ("pass" if u_cur <= args.phi else
                   ("reject" if l_cur > args.phi else "undetermined"))

        # ---- held-out verification: exact k-NN offline, never seen by any policy
        truth_v = live.exact_ids(qv, args.k)
        pg.set_ef(ef_cur)
        found_v, tt_v = pg.knn(qv, args.k)
        rec_v = recall_at_k(found_v, truth_v, args.k)
        f_true = float(np.mean(rec_v < args.tau))
        t_hold_ph = time.perf_counter() - t_phase

        rounds.append({
            "t": t, "live_rows": pg.counts(), "deleted_total": deleted_total,
            "audit_m": m, "arrivals": args.nq,
            "f_hat": f_hat, "f_ub": f_ub, "U": float(u_cur), "L": float(l_cur),
            "F_hat_op": float(np.mean(rec_by_ef[ef_cur] < args.tau)),
            "verdict": verdict, "certified": certified, "action": action, "ef": ef_cur,
            "rebuild_s": rebuild_s, "vacuum_s": vacuum_s, "audit_ms": audit_ms,
            "latency_ms": float(np.mean(tt_v)),
            "latency_p50_ms": float(np.percentile(tt_v, 50)),
            "latency_p95_ms": float(np.percentile(tt_v, 95)),
            "f_true": f_true,
        })
        if action == "rebuild":
            ref_F = f_true
        print(f"      phases: churn={t_ins:5.1f}s audit={t_audit_ph:5.1f}s grid={t_grid_ph:5.1f}s "
              f"heldout={t_hold_ph:5.1f}s", flush=True)
        print(f"  [{policy}] t={t:2d} live={pg.counts():7d} del={deleted_total:6d} "
              f"F_hat={np.mean(rec_by_ef[ef_cur] < args.tau):.3f} U={u_cur:.3f} {verdict:<12s} F_true={f_true:.3f} "
              f"ef={ef_cur:3d} lat={float(np.mean(tt_v)):6.3f}ms audit={audit_ms:6.1f}ms "
              f"act={action}", flush=True)

    live_rows = pg.counts()
    out = {
        "engine": "postgresql16+pgvector0.8.7", "dataset": ds.name, "drift": "churn",
        "policy": policy, "tau": args.tau, "phi": args.phi, "delta": args.delta,
        "nq": args.nq, "audit_m": args.audit_m, "k": args.k, "n_base": n_base,
        "batch": args.batch, "rounds": args.rounds, "m": args.m, "efc": args.efc,
        "delete_frac": args.delete_frac, "autovacuum_enabled": False, "wall_s": time.perf_counter() - wall0,
        "build_s": build_s, "live_rows_end": live_rows,
        "rounds_detail": rounds,
        "summary": {
            "violation_epochs": int(sum(r["f_true"] > args.phi for r in rounds)),
            "n_epochs": len(rounds),
            "n_rebuilds": int(sum(r["action"] == "rebuild" for r in rounds)),
            "rebuild_s": float(sum(r["rebuild_s"] for r in rounds)),
            "vacuum_s": float(sum(r["vacuum_s"] for r in rounds)),
            "mean_latency_ms": float(np.mean([r["latency_ms"] for r in rounds])),
            "mean_latency_p50_ms": float(np.mean([r["latency_p50_ms"] for r in rounds])),
            "mean_latency_p95_ms": float(np.mean([r["latency_p95_ms"] for r in rounds])),
            "mean_audit_ms": float(np.mean([r["audit_ms"] for r in rounds])),
            "audit_over_service_ratio": float(np.mean([r["audit_ms"] / r["latency_ms"] for r in rounds])),
            "mean_f_true": float(np.mean([r["f_true"] for r in rounds])),
            "certified_epochs": int(sum(r["certified"] for r in rounds)),
            "false_cert": int(sum(r["certified"] and r["f_true"] > args.phi for r in rounds)),
            "verdicts": {v: int(sum(r["verdict"] == v for r in rounds))
                         for v in ("pass", "reject", "undetermined")},
            "verdicts_while_violating": {v: int(sum(r["verdict"] == v and r["f_true"] > args.phi for r in rounds))
                                         for v in ("pass", "reject", "undetermined")},
            "final_ef": rounds[-1]["ef"] if rounds else None,
        },
    }
    pg.conn.close()
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="sift-128-euclidean.hdf5")
    ap.add_argument("--dsn", default="host=127.0.0.1 port=5433 user=postgres password=icde dbname=icde")
    ap.add_argument("--policies", default="never,periodic_4,ef_auto,ctrl,ctrl_mean")
    ap.add_argument("--n-base", type=int, default=200_000)
    ap.add_argument("--batch", type=int, default=5_000)
    ap.add_argument("--rounds", type=int, default=12)
    ap.add_argument("--nq", type=int, default=600)
    ap.add_argument("--audit-m", type=int, default=250)
    ap.add_argument("--k", type=int, default=10)
    ap.add_argument("--m", type=int, default=16)
    ap.add_argument("--efc", type=int, default=64)
    ap.add_argument("--ef0", type=int, default=64)
    ap.add_argument("--tau", type=float, default=0.95)
    ap.add_argument("--phi", type=float, default=0.05)
    ap.add_argument("--delta", type=float, default=0.05)
    ap.add_argument("--delete-frac", type=float, default=0.025)
    ap.add_argument("--cooldown", type=int, default=3)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--outdir", default=os.path.join(REPO, "reports", "u1"))
    a = ap.parse_args()

    ds = load_ann_benchmark(a.data)
    os.makedirs(a.outdir, exist_ok=True)
    results = []
    for pol in a.policies.split(","):
        t0 = time.perf_counter()
        res = run(ds, a, pol)
        results.append(res)
        s = res["summary"]
        print(f"[{pol:10s}] {time.perf_counter()-t0:6.0f}s viol={s['violation_epochs']}/{s['n_epochs']} "
              f"rebuilds={s['n_rebuilds']} rebuild_s={s['rebuild_s']:6.1f} "
              f"lat={s['mean_latency_ms']:6.3f}ms cert={s['certified_epochs']} "
              f"false_cert={s['false_cert']} ef*final={s['final_ef']}", flush=True)
        dump_json(os.path.join(a.outdir, f"pg_{ds.name}_churn_{pol}_s{a.seed}.json"), res)
    dump_json(os.path.join(a.outdir, f"pg_{ds.name}_churn_all_s{a.seed}.json"), results)
    print("[done]", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
