#!/usr/bin/env python3
"""Fill the `\\author{...}` block of paper/main.tex from a plain text file, then prove
the PDF is still submittable.

Why this exists
---------------
The author block is the last red item in `scripts/preflight.py` and the only thing on the
submission path that an executor is not allowed to invent. But typing LaTeX by hand at
T-24h is exactly how a 36/36 paper becomes a 34/36 paper: IEEEtran lays the block out at
the top of page 1, so its height moves every page break after it, and an over-long email
list produces `Overfull \\hbox` that preflight counts as a defect.

This script makes the operation atomic and reversible:

    python3 scripts/set_authors.py --check      # parse + show the LaTeX, touch nothing
    python3 scripts/set_authors.py --apply      # patch main.tex (timestamped backup)
    python3 scripts/set_authors.py --run        # apply + build + preflight + page report
    python3 scripts/set_authors.py --restore    # put the previous main.tex back

Input file (`relay/authors.txt`, one author per line, `|`-separated):

    # name | affiliation | email
    Zhang San | Dept. of Computer Science, Example University | zs@example.edu
    Li Si     | Dept. of Computer Science, Example University | ls@example.edu
    Wang Wu   | Example Research Institute | ww@example.org

Lines starting with `#` and blank lines are ignored. Column 3 (email) may be empty.
Authors are grouped by affiliation, in first-appearance order; one `\\IEEEauthorblock`
per distinct affiliation, joined with `\\and`. Append `*` to a name to mark the
corresponding author.

The file is never written to by this script; it only reads it.
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import time

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_TEX = os.path.join(REPO, "paper", "main.tex")
DEFAULT_AUTHORS = os.path.join(REPO, "relay", "authors.txt")

TEX_ESCAPE = {
    "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_",
    "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}",
}


def esc(s: str) -> str:
    """Escape the characters that are special in LaTeX text mode."""
    return "".join(TEX_ESCAPE.get(ch, ch) for ch in s)


def parse_authors(path: str) -> list[tuple[str, str, str, str]]:
    """Read `name | affiliation | email | location`; the last two columns are optional.

    `affiliation` may contain `;` to split the department from the organisation (the
    template lays those out on separate italic lines). A trailing `*` on the name marks the
    corresponding author.
    """
    if not os.path.exists(path):
        raise SystemExit(
            f"no author file at {path}\n"
            "create it as `name | affiliation | email | city, country`, one author per line")
    rows: list[tuple[str, str, str, str]] = []
    for lineno, raw in enumerate(open(path, encoding="utf-8"), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = [p.strip() for p in line.split("|")]
        if len(parts) < 2 or not parts[0] or not parts[1]:
            raise SystemExit(f"{path}:{lineno}: need at least `name | affiliation`, got {raw!r}")
        name, affil = parts[0], parts[1]
        email = parts[2] if len(parts) > 2 else ""
        location = parts[3] if len(parts) > 3 else ""
        rows.append((name, affil, email, location))
    if not rows:
        raise SystemExit(f"{path}: no author rows found")
    return rows


def group(rows) -> list[tuple[str, list[tuple[str, str]]]]:
    """(affiliation, [(name, email), ...]) in first-appearance order."""
    order: list[str] = []
    buckets: dict[str, list[tuple[str, str]]] = {}
    for name, affil, email, *_ in rows:
        if affil not in buckets:
            order.append(affil)
            buckets[affil] = []
        buckets[affil].append((name, email))
    return [(a, buckets[a]) for a in order]


ORDINALS = {1: "st", 2: "nd", 3: "rd"}


def ordinal_suffix(n: int) -> str:
    if 10 <= n % 100 <= 20:
        return "th"
    return ORDINALS.get(n % 10, "th")


def _affil_lines(affil: str) -> list[str]:
    """`A; B` becomes two italic lines, which is how the template lays out dept + organisation."""
    return [p.strip() for p in affil.split(";") if p.strip()]


def render(rows: list[tuple[str, str, str, str]]) -> str:
    r"""The author block in the official conference template's form.

    conference-latex-template-062824 (2024-06-27) writes one ``\IEEEauthorblock`` per
    author, the position as a superscript on the name, the affiliation in italics, the
    address and e-mail each on their own line, and ``\and`` between authors::

        \IEEEauthorblockN{1\textsuperscript{st} Given Name Surname}
        \IEEEauthorblockA{\textit{dept. name of organization}\\
        \textit{name of organization}\\ City, Country\\ email address or ORCID}

    A row is ``name | affiliation | email | location``, where ``affiliation`` may contain
    ``;`` to split department from organisation, ``location`` is ``City, Country`` and is
    optional, and a trailing ``*`` on the name marks the corresponding author.
    """
    blocks = []
    for i, (name, affil, email, location) in enumerate(rows, start=1):
        name = name.strip()
        corresponding = name.endswith("*")
        if corresponding:
            name = name.rstrip("*").strip()
        lines = ["\\textit{" + esc(a) + "}" for a in _affil_lines(affil)]
        if location:
            lines.append(esc(location))
        if email:
            mail = "\\texttt{" + esc(email) + "}"
            if corresponding:
                mail += " (corresponding author)"
            lines.append(mail)
        body = "\\\\\n".join(lines)
        head = "\\IEEEauthorblockN{%d\\textsuperscript{%s} %s}" % (
            i, ordinal_suffix(i), esc(name))
        blocks.append(head + "\n\\IEEEauthorblockA{" + body + "}")
    return "\\author{" + "\n\\and\n".join(blocks) + "}"


def find_author_span(tex: str) -> tuple[int, int]:
    """(start, end) of the `\\author{...}` command, brace-matched."""
    m = re.search(r"\\author\s*\{", tex)
    if not m:
        raise SystemExit("main.tex has no \\author{...} command — refusing to guess")
    start = m.start()
    i = m.end() - 1
    depth = 0
    while i < len(tex):
        ch = tex[i]
        if ch == "\\":
            i += 2
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return start, i + 1
        i += 1
    raise SystemExit("unbalanced braces in the \\author block")


def patch(tex_path: str, rows, backup_dir: str | None = None) -> str:
    tex = open(tex_path, encoding="utf-8").read()
    start, end = find_author_span(tex)
    old = tex[start:end]
    new = render(rows)
    # D007 discipline: never patch silently.
    assert old.startswith("\\author"), old[:40]
    assert old in tex, "author block vanished between scan and patch"
    out = tex[:start] + new + tex[end:]
    assert out != tex, "patch was a no-op"
    assert r"\IEEEauthorblockN" in out
    # exactly one \author command must survive
    assert len(re.findall(r"\\author\s*\{", out)) == 1, "more than one \\author command"

    if backup_dir:
        os.makedirs(backup_dir, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        dst = os.path.join(backup_dir, f"main.tex.{stamp}")
        shutil.copy2(tex_path, dst)
        print(f"backup: {dst}")
    with open(tex_path, "w", encoding="utf-8") as fh:
        fh.write(out)
    return new


def build(paper_dir: str) -> dict:
    """Deterministic build of paper_dir/main.tex (same sequence as build_paper.sh)."""
    src = os.path.abspath(paper_dir)
    b = os.path.join(src, "build")
    shutil.rmtree(b, ignore_errors=True)
    os.makedirs(b, exist_ok=True)
    for name in ("main.tex", "refs.bib"):
        if os.path.exists(os.path.join(src, name)):
            shutil.copy2(os.path.join(src, name), b)
    figs = os.path.join(src, "figures")
    if os.path.isdir(figs):
        shutil.copytree(figs, os.path.join(b, "figures"))
    run = lambda *a: subprocess.run(a, cwd=b, capture_output=True, text=True)
    r1 = run("pdflatex", "-interaction=nonstopmode", "-halt-on-error", "main.tex")
    if r1.returncode != 0:
        return {"ok": False, "stage": "pdflatex#1", "tail": (r1.stdout or "")[-1500:]}
    run("bibtex", "main")
    r2 = run("pdflatex", "-interaction=nonstopmode", "-halt-on-error", "main.tex")
    r3 = run("pdflatex", "-interaction=nonstopmode", "-halt-on-error", "main.tex")
    log_path = os.path.join(b, "main.log")
    log = open(log_path, encoding="utf-8", errors="replace").read() if os.path.exists(log_path) else ""
    pdf = os.path.join(b, "main.pdf")
    if not os.path.exists(pdf):
        return {"ok": False, "stage": "no pdf", "tail": log[-1500:]}
    info = subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout
    pages = int(re.search(r"Pages:\s+(\d+)", info).group(1))
    txt = subprocess.run(["pdftotext", pdf, "-"], capture_output=True, text=True).stdout
    bbl = os.path.join(b, "main.bbl")
    return {
        "ok": True,
        "pages": pages,
        "errors": len(re.findall(r"^!", log, flags=re.M)),
        "overfull": len(re.findall(r"Overfull \\hbox", log)),
        "unresolved": len(re.findall(r"Citation.*undefined", log)),
        "bibitems": open(bbl).read().count("\\bibitem") if os.path.exists(bbl) else 0,
        "text": txt,
        "pdf": pdf,
        "rc3": r3.returncode,
    }


def names_in_pdf(rows, txt: str) -> list[str]:
    """Which author surnames appear in the PDF text layer (whitespace-normalised)."""
    flat = re.sub(r"\s+", " ", txt)
    return [r[0] for r in rows if re.sub(r"\s+", " ", r[0].replace("*", "").strip()) in flat]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--authors", default=DEFAULT_AUTHORS)
    ap.add_argument("--tex", default=DEFAULT_TEX)
    ap.add_argument("--check", action="store_true", help="parse and print the LaTeX, write nothing")
    ap.add_argument("--apply", action="store_true", help="patch main.tex (with backup)")
    ap.add_argument("--run", action="store_true", help="apply, then build + gate")
    ap.add_argument("--restore", action="store_true", help="restore the newest backup")
    ap.add_argument("--measure", action="store_true",
                    help="build the tree in place and report pages/overfull/name hits")
    ap.add_argument("--no-backup", action="store_true")
    args = ap.parse_args()

    backup_dir = os.path.join(os.path.dirname(os.path.abspath(args.tex)), ".backup")

    if args.restore:
        cands = sorted(f for f in os.listdir(backup_dir)) if os.path.isdir(backup_dir) else []
        cands = [c for c in cands if c.startswith("main.tex.")]
        if not cands:
            raise SystemExit(f"no backup in {backup_dir}")
        src = os.path.join(backup_dir, cands[-1])
        shutil.copy2(src, args.tex)
        print(f"restored {args.tex} from {src}")
        return 0

    rows = parse_authors(args.authors)
    block = render(rows)

    if args.check or not (args.apply or args.run or args.measure):
        print(f"authors parsed: {len(rows)}  affiliations: {len(group(rows))}")
        for name, affil, email, *_ in rows:
            print(f"  - {name:<24} {affil:<50} {email}")
        print("\n--- LaTeX that would be written ---")
        print(block)
        return 0

    if args.apply or args.run:
        patch(args.tex, rows, None if args.no_backup else backup_dir)
        print(f"patched {args.tex}")

    if args.run or args.measure:
        res = build(os.path.dirname(os.path.abspath(args.tex)))
        if not res["ok"]:
            print(f"BUILD FAILED at {res['stage']}\n{res['tail']}")
            return 1
        hits = names_in_pdf(rows, res["text"])
        print(f"pages={res['pages']}  latex_errors={res['errors']}  overfull={res['overfull']}  "
              f"bibitems={res['bibitems']}  unresolved={res['unresolved']}")
        print(f"names visible in PDF text layer: {len(hits)}/{len(rows)}")
        missing = [r[0] for r in rows if r[0] not in hits]
        if missing:
            print(f"  MISSING: {missing}")
        bad = (res["errors"] or res["overfull"] or res["unresolved"]
               or res["bibitems"] < 20 or res["pages"] > 13)
        if bad:
            print("GATE FAILED — restore with ... --restore")
            return 1
        print("GATE OK (pages/errors/overfull/bibitems)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
