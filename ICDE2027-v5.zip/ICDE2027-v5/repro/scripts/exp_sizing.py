#!/usr/bin/env python3
"""The audit-sizing law: the smallest audit count that certifies an epoch.

The paper defines it as

    p* = min{ p : K+(ceil(F p N); pN, N, alpha_w) <= phi N } / N

and this script is the one place that computes it, so the table, the figure and the text
cannot drift apart. `ceil` is the conservative reading of "the audited sample shows the
planned rate": the audited violation count is the smallest integer that is at least F n, so
the bound is evaluated where the sample already looks as bad as planned.

    python3 scripts/exp_sizing.py          # -> reports/s0/audit_sizing.json

Each row is [epoch w, planned rate F, audit rate p*, audits n*] and the fitted exponents
p* ~ (phi - F)^-gamma are written alongside, because the paper quotes them.
"""
from __future__ import annotations

import json
import math
import os
import sys

import numpy as np
from scipy.stats import hypergeom

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(REPO, "reports", "s0", "audit_sizing.json")

N = 4000          # arrivals per epoch
PHI = 0.05        # contract
DELTA = 0.05      # promise
FS = [0.005, 0.01, 0.02, 0.03, 0.04]
WS = [1, 6, 12]


def kplus(k: int, n: int, N: int, alpha: float) -> int:
    """Exact finite-population upper limit (same routine the certificate uses)."""
    if n >= N:
        return int(min(N, max(k, 0)))
    lo, hi = float(k), float(N)
    for _ in range(50):
        mid = 0.5 * (lo + hi)
        K = int(round(mid))
        if float(hypergeom.cdf(k, N, max(K, 0), n)) >= alpha:
            lo = mid
        else:
            hi = mid
    return int(round(min(float(N), lo)))


def smallest_audits(F: float, w: int) -> int:
    # Algorithm 1 splits the level between the two decisions (PASS and REJECT), so the
    # sizing law must use alpha_w/2 -- the same object the paper tabs. Using the full
    # alpha_w here would price a one-sided PASS-only procedure that Algorithm 1 is not.
    alpha = 6.0 * DELTA / (np.pi ** 2 * w ** 2) / 2.0
    target = PHI * N
    for n in range(1, N + 1):
        k = math.ceil(F * n)
        if kplus(k, n, N, alpha) <= target:
            return n
    return N


def main() -> int:
    rows = []
    for w in WS:
        for F in FS:
            n = smallest_audits(F, w)
            rows.append([w, F, round(n / N, 3), n])
    # exponents of p* ~ (phi - F)^-gamma, fitted per epoch on the three largest margins
    slopes = {}
    for w in WS:
        xs = np.array([PHI - r[1] for r in rows if r[0] == w])
        ys = np.array([r[2] for r in rows if r[0] == w])
        keep = xs > 0.004
        slopes[str(w)] = float(-np.polyfit(np.log(xs[keep]), np.log(ys[keep]), 1)[0])
    with open(OUT, "w") as f:
        json.dump(rows, f, indent=1)
    print(f"wrote {OUT}")
    print("  w  F     p*     n")
    for w, F, p, n in rows:
        print(f"  {w:2d} {F:.3f} {p:.3f} {n:5d}")
    print("  fitted gamma:", {k: round(v, 2) for k, v in slopes.items()})
    return 0


if __name__ == "__main__":
    sys.exit(main())
