#!/usr/bin/env python3
"""Insert the PostgreSQL closed-loop subsection (paragraph + table + targeting remark).

Two blocks, inserted as wholes before the controller algorithm, with asserts on every
replacement (DECISIONS D007) and a refusal to insert twice.

    python3 scripts/patch_paper_pg.py --apply     # patch main.tex (backup first)
    python3 scripts/patch_paper_pg.py --check     # is it already there and consistent?
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_pg_table  # noqa: E402

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
TEX = os.path.join(REPO, "paper", "main.tex")
ANCHOR = "\\begin{algorithm}[t]\n\\caption{Contract controller"


def load(path):
    with open(os.path.join(REPO, path)) as f:
        return json.load(f)



FIGURE = """\\begin{figure}[t]
\\centering
\\includegraphics[width=\\columnwidth]{pgvector.pdf}
\\caption{The loop inside PostgreSQL, epoch by epoch, from the same log as
\\cref{tab:pgvector}: realized tail $F_t(0.95)$ measured on held-out queries (top) and the
p50 latency the rule was serving (bottom). The mean-recall monitor reports a pass in every
epoch while the tail sits above the contract; the contract controller moves the effort
lever, pays the latency, and holds the tail at the boundary.}
\\label{fig:pgvector}
\\end{figure}
"""

def numbers() -> dict:
    """Every number in the paragraph, read from the artifacts (never typed by hand)."""
    u1 = {d["policy"]: d for d in load("reports/u1/pg_sift-128-euclidean_churn_all_s1.json")}
    never, periodic = u1["never"]["summary"], u1["periodic_4"]["summary"]
    ctrl, mean = u1["ctrl"]["summary"], u1["ctrl_mean"]["summary"]
    marg = load("reports/u5/margin_sift.json")["deciles"]["ef128"]
    auc128 = load("reports/u5/margin_sift.json")["per_ef"]["ef128"]["abs_dk"]["auc"]
    s2 = load("reports/u5/allocation_sift_ef128_s2_even.json")["planned"]
    s4 = load("reports/u5/allocation_sift_ef128_s4_even.json")["planned"]
    return {
        "rounds": never["n_epochs"],
        "never_viol": never["violation_epochs"],
        "periodic_viol": periodic["violation_epochs"],
        "periodic_rebuilds": periodic["n_rebuilds"],
        "periodic_rebuild_s": periodic["rebuild_s"],
        "ctrl_viol": ctrl["violation_epochs"],
        "ctrl_passes": ctrl["verdicts"]["pass"],
        "mean_viol": mean["violation_epochs"],
        "mean_self": mean["certified_epochs"],
        "mean_p50": mean["mean_latency_p50_ms"],
        "lat_p50": never["mean_latency_p50_ms"],
        "lat_p50_ctrl": ctrl["mean_latency_p50_ms"],
        "audit_ms": never["mean_audit_ms"],
        "ratio_audit": never["audit_over_service_ratio"],
        "auc": auc128,
        "dec_ratio": marg["top_bottom_decile_ratio"],
        "dec_top": marg["top_decile_rate"],
        "dec_bottom": marg["bottom_decile_rate"],
        "saving2": 100.0 * abs(s2["audit_saving_vs_uniform"]),
        "saving4": 100.0 * abs(s4["audit_saving_vs_uniform"]),
    }


def paragraph(n: dict) -> str:
    return f"""\\paragraph{{The loop, closed inside a database}}
The results so far come from an index in a Python process. To check that they are a
property of the contract rather than of our own bookkeeping, we repeat the closed loop on
\\textbf{{PostgreSQL~16 with pgvector}} under the engine's stock index parameters
($m{{=}}16$, $\\mathrm{{efConstruction}}{{=}}64$): the vectors are rows in a table, the
effort lever is the server's own \\texttt{{hnsw.ef\\_search}}, churn is \\texttt{{DELETE}}
plus \\texttt{{COPY}} against the same table, and an audited query is answered exactly by
scanning that table with \\texttt{{enable\\_indexscan=off}}---the deployment situation
\\cref{{sec:cert}} assumes, with the scan timed, and the operating point covered by the
split of \\cref{{sec:cert}}. The levers keep the identities \\cref{{sec:repair}} gave them
(\\cref{{tab:pgvector}}, \\cref{{fig:pgvector}}). Three \\texttt{{REINDEX}}
operations ({n['periodic_rebuild_s']:.1f}\\,s) leave {n['periodic_viol']}/{n['rounds']}
epochs in violation, exactly as in the prototype: a rebuild collects tombstones, and the
tail here is intrinsic. The mean-recall monitor certifies {n['mean_self']} of
{n['rounds']} epochs and {n['mean_viol']} of them are in violation, at the same price as
doing nothing ({n['mean_p50']:.2f}\\,ms p50). Only the effort lever clears the contract:
{n['ctrl_viol']}/{n['rounds']} violating epochs at {n['lat_p50_ctrl']:.2f}\\,ms p50 against
{n['lat_p50']:.2f}\\,ms, with {n['ctrl_passes']} certifications and no false one. The engine
sets the audit-to-query ratio---{n['ratio_audit']:.0f}$\\times$ here against $239\\times$
in-process---while the cost of knowing is set by the workload and the execution environment:
{n['audit_ms']:.0f}\\,ms per exact audit here, 41\\,ms for 800k rows in-process. That ratio
is what a capacity plan needs: auditing a fraction $p$ of a stream served at
$\\lambda$ queries per second costs about ${n['ratio_audit']:.0f}p\\lambda$
query-equivalents."""


def remark(n: dict) -> str:
    return f"""\\paragraph{{Auditing the risky queries is not a substitute for auditing more}}
The $k$-th neighbour radius the index already returns ranks the violating queries with AUC
{n['auc']:.2f}, and at $\\mathrm{{ef}}{{=}}128$ the top decile violates
{n['dec_ratio']:.0f}$\\times$ more often than the bottom one---so the tail is predictable, for
free. Cashing that in does not work, because an exact bound is dearer on a smaller population:
stratifying the audit costs \\textbf{{more}} than the pooled design, {n['saving2']:.1f}\\% with two
strata and {n['saving4']:.1f}\\% with four. Pooled auditing is the cheap end of the exact
designs, and the score's real use is prediction, not allocation."""


def blocks() -> str:
    return (paragraph(numbers()) + "\n\n" + make_pg_table.block() + "\n\n" + FIGURE + "\n\n"
            + remark(numbers()) + "\n\n")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--refresh", action="store_true")
    a = ap.parse_args()
    tex = open(TEX, encoding="utf-8").read()
    if "\\label{tab:pgvector}" in tex:
        if not a.refresh:
            print("already patched (tab:pgvector present); pass --refresh to rebuild the block")
            return 0
        i = tex.index("\\label{tab:pgvector}")
        start = tex.rfind("\\begin{table}", 0, i)
        end = tex.index("\\end{table}", i) + len("\\end{table}")
        # also rebuild the two prose blocks that carry this run's numbers
        a0 = tex.index("\\paragraph{The loop, closed inside a database}")
        t0 = tex.index("\\begin{table}[t]", a0)
        tex = tex[:a0] + paragraph(numbers()) + "\n\n" + tex[t0:]
        a1 = tex.index("\\paragraph{Auditing the risky queries is not a substitute")
        # the span ends at the next paragraph or section -- never at an environment, which is
        # what silently swallowed the controller algorithm once
        nxt = [i for i in (tex.find("\\paragraph{", a1 + 10), tex.find("\\section{", a1 + 10))
               if i > 0]
        t1 = min(nxt)
        tex = tex[:a1] + remark(numbers()) + "\n\n" + tex[t1:]
        i = tex.index("\\label{tab:pgvector}")
        start = tex.rfind("\\begin{table}", 0, i)
        end = tex.index("\\end{table}", i) + len("\\end{table}")
        new = tex[:start] + make_pg_table.block() + tex[end:]
        if "\\label{fig:pgvector}" not in new:
            j = new.index("\\end{table}", new.index("\\label{tab:pgvector}")) + len("\\end{table}")
            new = new[:j] + "\n\n" + FIGURE + new[j:]
        assert new.count("\\label{tab:pgvector}") == 1
        bak = os.path.join(REPO, "paper", ".backup", f"main.tex.{time.strftime('%Y%m%d-%H%M%S')}")
        os.makedirs(os.path.dirname(bak), exist_ok=True)
        shutil.copy2(TEX, bak)
        open(TEX, "w", encoding="utf-8").write(new)
        print("table block refreshed from the artifact")
        return 0
    if a.check:
        print("not patched yet")
        return 1
    assert tex.count(ANCHOR) == 1, f"anchor not unique: {tex.count(ANCHOR)}"
    new = tex.replace(ANCHOR, blocks() + ANCHOR)
    assert new != tex and new.count("\\label{tab:pgvector}") == 1
    assert new.count("\\paragraph{The loop, closed inside a database}") == 1
    bak = os.path.join(REPO, "paper", ".backup", f"main.tex.{time.strftime('%Y%m%d-%H%M%S')}")
    os.makedirs(os.path.dirname(bak), exist_ok=True)
    shutil.copy2(TEX, bak)
    open(TEX, "w", encoding="utf-8").write(new)
    print(f"patched {TEX}\nbackup {bak}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
