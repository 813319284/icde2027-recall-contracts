#!/usr/bin/env python3
"""Honest latency lever: per-query latency (single thread, median/p95) vs ef.

Batch-level means hide the lever (threads overlap queries); the controller prices
per-query latency, so that is what must be measured.
"""
from __future__ import annotations

import os
import sys

import faiss
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from icde_lab.datasets import initial_split, load_ann_benchmark   # noqa: E402
from icde_lab.drift import build_plan                             # noqa: E402
from icde_lab.indexes import AnnIndex                             # noqa: E402
from icde_lab.logio import dump_json                              # noqa: E402


def main():
    n_base = int(os.environ.get("NBASE", 800_000))
    data = os.environ.get("DATA", "sift-128-euclidean.hdf5")
    ds = load_ann_benchmark(data)
    base0, incoming = initial_split(ds, n_base, seed=0)
    idx = AnnIndex(ds.dim, ds.metric, "hnsw", M=32, ef_construction=200).build(base0)
    rng = np.random.default_rng(0)
    q = ds.test[:300]
    faiss.omp_set_num_threads(1)
    out = {}
    for ef in (16, 32, 64, 128, 256, 512):
        idx.index.hnsw.efSearch = ef
        lat = []
        for i in range(len(q)):
            t0 = __import__("time").perf_counter()
            idx.index.search(q[i:i + 1], 10)
            lat.append((__import__("time").perf_counter() - t0) * 1e3)
        lat = np.array(lat)
        out[str(ef)] = {"p50": float(np.percentile(lat, 50)), "p95": float(np.percentile(lat, 95)),
                        "mean": float(lat.mean())}
        print(f"ef={ef:4d}  p50={out[str(ef)]['p50']:.3f}ms  p95={out[str(ef)]['p95']:.3f}ms")
    dump_json(os.path.join(os.path.dirname(__file__), "..", "reports", "latency.json"), out)


if __name__ == "__main__":
    main()
