#!/usr/bin/env python3
"""S0 analysis: does the mean hide the tail, and are naive CIs too narrow?

Reads reports/s0/perquery_*.jsonl and prints, per (dataset, drift, arm):
  mean recall, p05/p10, SLA violation rate at tau, naive 95% CI half-width,
  between-round spread, and the "certified-by-naive-CI but wrong" rate.
"""
from __future__ import annotations

import glob
import json
import os
import sys

import numpy as np

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))


def naive_ci(x: np.ndarray, z: float = 1.96) -> tuple[float, float, float]:
    n = len(x)
    m, s = float(np.mean(x)), float(np.std(x, ddof=1))
    hw = z * s / np.sqrt(n)
    return m, hw, s


def main(tags=None, tau=0.90):
    files = sorted(glob.glob(os.path.join(REPO, "reports", "s0", "perquery_*.jsonl")))
    print(f"{'run':32s} {'fam':4s} {'n':>5s} {'mean':>6s} {'p05':>5s} {'p10':>5s} "
          f"{'viol@%.2f' % tau:>9s} {'naive_hw':>8s} {'round_sd':>8s}")
    print("-" * 100)
    for f in files:
        run = os.path.basename(f)[len("perquery_"):-len(".jsonl")]
        recs = [json.loads(l) for l in open(f)]
        for fam in ("old", "new"):
            xs = np.array([r["recall"] for r in recs if r["family"] == fam])
            if len(xs) == 0:
                continue
            m, hw, sd = naive_ci(xs)
            viol = float(np.mean(xs < tau))
            # between-round spread of the round means (workload composition effect)
            rounds = sorted({r["round"] for r in recs if r["family"] == fam})
            rm = [np.mean([r["recall"] for r in recs if r["family"] == fam and r["round"] == t]) for t in rounds]
            print(f"{run:32s} {fam:4s} {len(xs):5d} {m:6.4f} {np.percentile(xs,5):5.3f} "
                  f"{np.percentile(xs,10):5.3f} {viol:9.3f} {hw:8.4f} {np.std(rm):8.4f}")
    print("\n口径：viol@tau = 单查询 recall < tau 的比例（这才是 SLA 真正会漏掉的那部分用户）。")


if __name__ == "__main__":
    tau = float(sys.argv[1]) if len(sys.argv) > 1 else 0.90
    main(tau=tau)
