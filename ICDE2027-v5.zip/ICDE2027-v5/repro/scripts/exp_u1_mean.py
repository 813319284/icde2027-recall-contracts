#!/usr/bin/env python3
"""Mean recall of the PostgreSQL + pgvector run, measured the same way as the prototype.

The paper's central measurement is a contrast: a mean that looks fine while the tail does
not. The database run of ``exp_u1_pgvector.py`` records the tail (its certificate works on
percentiles) but not the mean, exactly because the mean is not what it certifies. To state
the contrast for the *same* engine and the same configuration, this script measures the mean
on the same table and the same query sample, and writes it next to the tail.

    python3 scripts/exp_u1_mean.py            # -> reports/u1/pg_mean.json
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from icde_lab.datasets import load_ann_benchmark   # noqa: E402
from icde_lab.logio import dump_json               # noqa: E402
import importlib.util

spec = importlib.util.spec_from_file_location("u1", os.path.join(os.path.dirname(__file__), "exp_u1_pgvector.py"))
u1 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u1)

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))


def main() -> int:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="sift-128-euclidean.hdf5")
    ap.add_argument("--dsn", default="host=127.0.0.1 port=5433 user=postgres password=icde dbname=icde")
    ap.add_argument("--n-base", type=int, default=200_000)
    ap.add_argument("--nq", type=int, default=1000)
    ap.add_argument("--k", type=int, default=10)
    ap.add_argument("--m", type=int, default=16)
    ap.add_argument("--efc", type=int, default=64)
    ap.add_argument("--tau", type=float, default=0.95)
    ap.add_argument("--seed", type=int, default=11)
    a = ap.parse_args()

    ds = load_ann_benchmark(a.data)
    X = np.ascontiguousarray(ds.train[:a.n_base].astype("float32"))
    rng = np.random.default_rng(a.seed)
    Q = ds.test[rng.choice(len(ds.test), size=a.nq, replace=False)].astype("float32")

    pg = u1.PG(a.dsn)
    pg.setup(table="itemsmean")
    ids = np.arange(len(X), dtype=np.int64)
    pg.copy_rows(ids, X, table="itemsmean")
    build_s = pg.create_index(a.m, a.efc, table="itemsmean")
    truth, _ = pg.knn(Q, a.k, table="itemsmean", exact=True)

    out = {"engine": "postgresql16+pgvector0.8.7", "dataset": ds.name, "n_base": a.n_base,
           "nq": a.nq, "m": a.m, "efc": a.efc, "tau": a.tau, "build_s": build_s, "per_ef": {}}
    for ef in (32, 64, 128, 256):
        pg.set_ef(ef)
        found, lat = pg.knn(Q, a.k, table="itemsmean")
        rec = u1.recall_at_k(found, truth, a.k)
        out["per_ef"][str(ef)] = {
            "mean_recall": float(rec.mean()),
            "F_tau": float(np.mean(rec < a.tau)),
            "p05": float(np.percentile(rec, 5)),
            "latency_ms_mean": float(np.mean(lat)),
        }
        print(f"ef={ef:3d} mean={rec.mean():.4f} F({a.tau})={np.mean(rec < a.tau):.4f} "
              f"p05={np.percentile(rec,5):.3f} lat={np.mean(lat):.2f}ms", flush=True)
    pg.q("DROP TABLE IF EXISTS itemsmean")
    pg.conn.close()
    os.makedirs(os.path.join(REPO, "reports", "u1"), exist_ok=True)
    dump_json(os.path.join(REPO, "reports", "u1", "pg_mean.json"), out)
    print("wrote reports/u1/pg_mean.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
