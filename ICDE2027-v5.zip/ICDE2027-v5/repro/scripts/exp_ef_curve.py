#!/usr/bin/env python3
"""ef/recall/latency curves along a drift trajectory.

Purpose: produce worlds on *both* sides of a contract — worlds that satisfy
F(tau) <= phi (so a certifier must be able to SAY YES) and worlds that violate
it (so a certifier must refuse). Without the first kind, a false-certification
table is vacuous.

Records: one per query per ef, with cluster id -> replayable by exp_t1_audit.py.
"""
from __future__ import annotations

import argparse
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from icde_lab.datasets import initial_split, load_ann_benchmark   # noqa: E402
from icde_lab.drift import build_plan                             # noqa: E402
from icde_lab.indexes import AnnIndex                             # noqa: E402
from icde_lab.logio import JsonlWriter, dump_json                 # noqa: E402
from icde_lab.truth import ExactKNN, recall_at_k                  # noqa: E402

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="sift-128-euclidean.hdf5")
    ap.add_argument("--tag", default="sift")
    ap.add_argument("--drift", default="append")
    ap.add_argument("--family", default="hnsw", choices=["hnsw", "ivfflat", "ivfpq"])
    ap.add_argument("--nlist", type=int, default=1024)
    ap.add_argument("--pq-m", type=int, default=32)
    ap.add_argument("--n-base", type=int, default=800_000)
    ap.add_argument("--batch", type=int, default=20_000)
    ap.add_argument("--rounds", type=int, default=10)
    ap.add_argument("--nq", type=int, default=500)
    ap.add_argument("--k", type=int, default=10)
    ap.add_argument("--M", type=int, default=32)
    ap.add_argument("--ef-construction", type=int, default=200)
    ap.add_argument("--efs", default="16,32,64,128,256")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--eval-rounds", default="0,5,9")
    a = ap.parse_args()
    efs = [int(v) for v in a.efs.split(",")]
    eval_rounds = {int(v) for v in a.eval_rounds.split(",")}

    ds = load_ann_benchmark(a.data)
    base0, incoming = initial_split(ds, a.n_base, seed=a.seed)
    plan = build_plan(incoming, ds.test, a.rounds, a.batch, a.nq, family=a.drift, seed=a.seed)
    idx = AnnIndex(ds.dim, ds.metric, a.family, M=a.M, ef_construction=a.ef_construction,
                   nlist=a.nlist, pq_m=a.pq_m)
    idx.build(base0)
    exact = ExactKNN(ds.dim, ds.metric).reset_with(base0)
    rng = np.random.default_rng(a.seed + 11)

    out = os.path.join(REPO, "reports", "s0", f"perquery_{a.tag}_efcurve.jsonl")
    rows, meta = [], []
    t0 = time.perf_counter()
    with JsonlWriter(out) as w:
        for t, rp in enumerate(plan):
            if rp.inserts is not None and len(rp.inserts):
                idx.add(rp.inserts)
                exact.add(rp.inserts)
            if rp.delete_frac > 0:
                idx.remove(rp.delete_frac, rng)
                exact.set_dead(idx.dead)
            if t not in eval_rounds:
                continue
            for fam, q, cl in (("old", rp.q_old, rp.cluster_old), ("new", rp.q_new, rp.cluster_new)):
                truth = exact.knn(q, a.k)
                for ef in efs:
                    found, dist, lat = idx.search_ef(q, a.k, ef)
                    rec = recall_at_k(found, truth, a.k)
                    for i in range(len(q)):
                        rows.append({"arm": "none", "round": t, "family": fam, "qid": i,
                                     "cluster": int(cl[i]), "ef": ef,
                                     "recall": float(rec[i]), "latency_ms": lat * 1e3})
                    meta.append({"round": t, "family": fam, "ef": ef,
                                 "recall_mean": float(np.nanmean(rec)),
                                 "latency_ms": lat * 1e3})
            w.write_many(rows)
            print(f"[r{t}] rows={len(rows)} wall={time.perf_counter()-t0:.1f}s", flush=True)
            rows = []

    dump_json(os.path.join(REPO, "reports", "s0", f"summary_{a.tag}_efcurve.json"),
              {"args": vars(a), "curve": meta})
    print("[done]", flush=True)


if __name__ == "__main__":
    main()
