#!/usr/bin/env bash
# Write supp/MANIFEST.txt: what is in the package, and the hashes that prove it.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=supp/MANIFEST.txt
{
  echo "== ICDE 2027 supplementary package =="
  echo "generated     : $(date -Is)"
  echo "paper pdf     : paper/build/main.pdf   sha256=$(sha256sum paper/build/main.pdf | cut -d' ' -f1)"
  echo "paper pages   : $(pdfinfo paper/build/main.pdf | awk '/^Pages:/{print $2}')"
  echo "supplement    : supp/build/supplement.pdf sha256=$(sha256sum supp/build/supplement.pdf | cut -d' ' -f1)"
  echo "supp pages    : $(pdfinfo supp/build/supplement.pdf | awk '/^Pages:/{print $2}')"
  echo "source hash   : $(cat paper/build/SOURCE_HASH 2>/dev/null || echo MISSING)"
  echo
  echo "-- artifacts backing the numbers --"
  find reports -name '*.json' | sort | while read -r f; do
    echo "$(sha256sum "$f" | cut -c1-16)  $f"
  done
  echo
  echo "-- reproduction bundle --"
  echo "scripts       : $(find scripts -name '*.py' -o -name '*.sh' | wc -l) files"
  echo "report files  : $(find reports -type f \( -name '*.json' -o -name '*.jsonl' -o -name '*.npz' \) | wc -l) artifacts"
  echo
  echo "-- generated tables --"
  find supp/tables -name '*.tex' | sort
  echo
  echo "-- environment --"
  echo "python        : $(python3 -V 2>&1)"
  echo "faiss         : $(python3 -c 'import faiss;print(faiss.__version__)' 2>/dev/null || echo n/a)"
  echo "postgres      : $(docker exec icde-pg psql -U postgres -d icde -tAc 'select version()' 2>/dev/null | cut -d, -f1 || echo 'not running')"
  echo "pgvector      : $(docker exec icde-pg psql -U postgres -d icde -tAc "select extversion from pg_extension where extname='vector'" 2>/dev/null || echo 'not running')"
} > "$OUT"
echo "wrote $OUT"
