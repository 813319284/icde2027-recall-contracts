#!/usr/bin/env python3
"""Keep the CMT copy of the abstract equal to the PDF, because CMT freezes it on submit.

The paper's abstract changed (the database result joined it). `scripts/preflight.py`
compares the numbers in the two, which catches a mismatch but not a wording drift, and the
organisers' rule is that the CMT metadata cannot be edited after submission. So the block in
SUBMIT.md is regenerated from the PDF rather than maintained by hand.

    python3 scripts/sync_submit_abstract.py            # rewrite the block
    python3 scripts/sync_submit_abstract.py --check    # exit 1 if it differs
"""
from __future__ import annotations

import argparse
import difflib
import re
import subprocess
import sys
import os

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
PDF = os.path.join(REPO, "paper", "build", "main.pdf")
SUBMIT = os.path.join(REPO, "SUBMIT.md")


def pdf_abstract() -> str:
    txt = subprocess.run(["pdftotext", PDF, "-"], capture_output=True, text=True).stdout
    m = re.search(r"Abstract[—\-](.*?)Index Terms", txt, re.S)
    if not m:
        raise SystemExit("cannot find the abstract in the PDF")
    body = re.sub(r"\s+", " ", m.group(1)).strip()
    body = body.replace("-\n", "")
    return body.strip()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    text = open(SUBMIT, encoding="utf-8").read()
    m = re.search(r"(\*\*Abstract\*\*[^\n]*\n```\n)(.*?)(```)", text, re.S)
    if not m:
        raise SystemExit("cannot find the **Abstract** block in SUBMIT.md")
    cur = re.sub(r"\s+", " ", m.group(2)).strip()
    new = pdf_abstract()
    if a.check:
        if cur == new:
            print("SUBMIT.md abstract == PDF abstract")
            return 0
        sim = difflib.SequenceMatcher(None, cur, new).ratio()
        print(f"SUBMIT.md abstract differs from the PDF (similarity {sim:.4f})")
        for ln in difflib.unified_diff(cur.split(". "), new.split(". "), lineterm="", n=0):
            if ln.startswith(("+", "-")) and not ln.startswith(("+++", "---")):
                print(" ", ln[:160])
        return 1
    text = text[:m.start(2)] + new + "\n" + text[m.end(2):]
    open(SUBMIT, "w", encoding="utf-8").write(text)
    print(f"SUBMIT.md abstract replaced from the PDF ({len(new.split())} words)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
