#!/usr/bin/env python3
"""Build relay/claims.json: the single source of truth for headline numbers.

Each entry records a claim, the artifact field it comes from, its value, and the string
that must appear in the PDF. `scripts/preflight.py` verifies both directions, so a number
that changes in the artifacts without the paper following it (or vice versa) fails the
submission check. Run this after any experiment rerun:

    python3 scripts/make_claims.py
"""
from __future__ import annotations

import json
import os

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))


def load(rel):
    with open(os.path.join(REPO, rel)) as f:
        return json.load(f)


def fmt(x: float, nd: int = 3) -> str:
    return f"{x:.{nd}f}"


def main():
    claims = []

    def add(claim, source, path, nd=3, tol=None, as_text=None):
        d = load(source)
        v = d
        for part in path.split("."):
            v = v[int(part)] if (isinstance(v, list) and part.isdigit()) else v[part]
        v = float(v)
        claims.append({
            "claim": claim,
            "source": source,
            "field": path,
            "value": v,
            "tol": tol if tol is not None else (0.0006 if nd == 3 else 0.006),
            "pdf_text": as_text if as_text is not None else fmt(v, nd),
        })

    B = "reports/s0/protocol_boundary_p10_1000.json"
    for key, label in (("ours", "boundary run FCR, alpha-spent"),
                       ("exact_fixed", "boundary run FCR, fixed sample"),
                       ("bootstrap", "boundary run FCR, bootstrap"),
                       ("oneshot", "boundary run FCR, one-shot audit"),
                       ("mean", "boundary run FCR, mean rule")):
        add(label, B, f"rules.{key}.run_fcr")

    M = "reports/s0/protocol_mixed_p30.json"
    for key, label in (("oneshot", "mixed run FCR, one-shot audit"),
                       ("mean", "mixed run FCR, mean rule")):
        add(label, M, f"rules.{key}.run_fcr")
    # the two percentages quoted in abstract/intro/conclusion, pinned to their source
    add("prose: one-shot signs off on 97%", M, "rules.oneshot.run_fcr", nd=0, tol=0.6, as_text="signs off on 97%")
    add("prose: mean monitor signs off on 86%", M, "rules.mean.run_fcr", nd=0, tol=0.6, as_text="signs off on 86%")

    for phi, f in (("0.02", "reports/s0/protocol_boundary_phi0.02_1000.json"),
                   ("0.10", "reports/s0/protocol_boundary_phi0.10_1000.json")):
        add(f"phi={phi}, alpha-spent FCR", f, "rules.ours.run_fcr")
        add(f"phi={phi}, fixed-sample FCR", f, "rules.exact_fixed.run_fcr")

    C = "reports/t3/aggregate_final.json"
    add("closed loop: mean F, no maintenance", C, "never.meanF")
    add("closed loop: mean F, search effort", C, "ef_auto.meanF")
    add("closed loop: p50 latency, no maintenance", C, "never.lat")
    add("closed loop: p50 latency, contract controller", C, "ctrl_rebuild.lat")
    add("closed loop: rebuild seconds, periodic", C, "periodic_4.rb_s", nd=1, tol=0.6)

    A = "reports/audit_cost.json"
    add("audit: single-core exact kNN, ms", A, "single_1thread_ms", nd=0, tol=0.6, as_text="41")
    add("audit: ratio to one ANN query", A, "ratio_single_core", nd=0, tol=1.0, as_text="239")
    add("audit: batched throughput, q/s", A, "qps_1024", nd=0, tol=6.0, as_text="845")

    # ---- the PostgreSQL + pgvector closed loop (table tab:pgvector) --------------
    PG = "reports/u1/pg_sift-128-euclidean_churn_all_s1.json"
    order = [d["policy"] for d in load(PG)]
    idx = {name: order.index(name) for name in order}
    add("pg: no maintenance violates every epoch", PG,
        f"{idx['never']}.summary.violation_epochs", nd=0, tol=0.01, as_text="12/12")
    add("pg: REINDEX every 4 violates every epoch", PG,
        f"{idx['periodic_4']}.summary.violation_epochs", nd=0, tol=0.01, as_text="12/12")
    add("pg: REINDEX seconds, periodic", PG, f"{idx['periodic_4']}.summary.rebuild_s",
        nd=1, tol=0.6)
    add("pg: contract controller clears the contract", PG,
        f"{idx['ctrl']}.summary.violation_epochs", nd=0, tol=0.01, as_text="0/12")
    add("pg: audit over service, ratio", PG, f"{idx['never']}.summary.audit_over_service_ratio",
        nd=0, tol=1.0, as_text="29")
    add("pg: mean monitor certifies while violating", PG,
        f"{idx['ctrl_mean']}.summary.verdicts.pass", nd=0, tol=0.01, as_text="12")
    PM = "reports/u1/pg_mean.json"
    add("pg: mean recall at ef=64", PM, "per_ef.64.mean_recall", nd=3, tol=0.002, as_text=None)
    add("pg: tail at ef=64", PM, "per_ef.64.F_tau", nd=3, tol=0.002, as_text="11.2%")

    F1 = "reports/t3/t3_frnew_churn_never_s3.json"
    rounds = load(F1)["rounds"]
    hat = sum(r["f_hat"].get("64", 0.0) for r in rounds) / len(rounds)
    tru = sum(r["f_true"] for r in rounds) / len(rounds)
    claims.append({"claim": "frame bias factor (new-content frame)", "source": F1,
                   "field": "derived:true/hate", "value": tru / hat, "tol": 0.1, "pdf_text": "2.9"})

    out = os.path.join(REPO, "relay", "claims.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w") as f:
        json.dump(claims, f, indent=1)
    print(f"wrote {out} with {len(claims)} claims")


if __name__ == "__main__":
    main()
