#!/usr/bin/env python3
"""Figure: the closed loop inside PostgreSQL, from the per-epoch log (not from summaries).

Two panels sharing the epoch axis:

  (a) the *realized* violation rate F_t(0.95) of every epoch, measured on held-out queries
      that no policy ever saw, with the contract line phi = 0.05;
  (b) the p50 query latency the policy was serving at in that epoch.

Two rules are drawn: the mean-recall monitor, which reports a pass in every epoch while the
top panel stays above the contract line, and the contract controller, which moves the effort
lever and therefore pays latency. The other two rules are in the table.

Every point comes from `rounds_detail` of reports/u1/pg_*_s1.json, so the figure and the
table cannot disagree.

    python3 scripts/make_fig_pgvector.py      # -> paper/figures/pgvector.pdf
"""
from __future__ import annotations

import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
ART = os.path.join(REPO, "reports", "u1", "pg_sift-128-euclidean_churn_all_s1.json")
OUT = os.path.join(REPO, "paper", "figures", "pgvector.pdf")

STYLE = {
    "ctrl_mean": dict(color="#c0392b", marker="o", label="mean-recall monitor"),
    "ctrl": dict(color="#1f6f3f", marker="s", label="contract controller"),
}


def main() -> int:
    data = {d["policy"]: d for d in json.load(open(ART))}
    plt.rcParams.update({"font.size": 7.5, "axes.linewidth": 0.6,
                         "xtick.major.width": 0.6, "ytick.major.width": 0.6})
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(3.4, 2.15), sharex=True,
                                   gridspec_kw={"height_ratios": [1.3, 1.0], "hspace": 0.12})
    phi = None
    for pol, st in STYLE.items():
        d = data[pol]
        phi = d["phi"]
        rd = d["rounds_detail"]
        t = [r["t"] for r in rd]
        ax1.plot(t, [r["f_true"] for r in rd], lw=1.5, ms=3.6, **st)
        ax2.plot(t, [r["latency_p50_ms"] for r in rd], lw=1.5, ms=3.6,
                 color=st["color"], marker=st["marker"], label=st["label"])
    ax1.axhline(phi, color="#444", ls="--", lw=0.8)
    ax1.text(0.2, phi + 0.013, r"contract $\phi$", fontsize=6.5, color="#444")
    ax1.set_ylabel(r"$F_t(0.95)$, held out")
    ax1.set_ylim(0, 0.26)
    ax1.text(0.02, 0.93, "(a)", transform=ax1.transAxes, fontsize=6.4, fontweight="bold")
    ax2.set_ylabel("p50 (ms)")
    ax2.set_xlabel("epoch")
    ax2.set_ylim(0, 6.6)
    ax2.text(0.02, 0.86, "(b)", transform=ax2.transAxes, fontsize=6.4, fontweight="bold")
    ax2.set_xticks(range(0, 12, 2))
    ax1.legend(frameon=False, fontsize=6.0, loc="upper center", ncol=2, handlelength=1.4,
               bbox_to_anchor=(0.5, 1.02), columnspacing=1.0)
    for ax in (ax1, ax2):
        ax.grid(axis="y", lw=0.3, alpha=0.5)
        for side in ("top", "right"):
            ax.spines[side].set_visible(False)
    fig.subplots_adjust(left=0.17, right=0.985, top=0.97, bottom=0.18, hspace=0.1)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    fig.savefig(OUT, format="pdf")
    print(f"wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
