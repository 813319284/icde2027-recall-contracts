#!/usr/bin/env python3
"""Template conformance: is the paper still the IEEE conference template, or has it drifted?

`scripts/preflight.py` checks what a submission system rejects (pages, fonts, text layer).
This checks something different: that the document *is* the supplied template's document —
same class file, the template's preamble block, the template's algorithm environment, the
template's author-block shape, the template's bibliography style. That property is easy to
lose one package at a time, so it gets a gate of its own.

    python3 scripts/check_template.py          # exit 0 = conforms
    python3 scripts/check_template.py -v       # list every check

Reference: conference-latex-template-062824 (2024-06-27), IEEEtran.cls V1.8b.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import re
import subprocess
import sys

def _find_repo(start: str) -> str:
    """Locate the project root, so the checkers also work from a delivered archive.

    In the working tree the root is the parent of ``scripts/``. In the delivery archive the
    scripts sit one level down (``repro/scripts``) with ``paper/`` at the archive root. We walk
    up until we find ``paper/main.tex`` (the authoritative marker); only if that fails do we
    accept a directory that merely contains ``reports/``, because ``repro/`` does too.
    """
    here = os.path.abspath(start)
    chain = []
    d = here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
TEX = os.path.join(REPO, "paper", "main.tex")
CLS = os.path.join(REPO, "paper", "IEEEtran.cls")

# sha256 of the IEEEtran.cls that ships inside conference-latex-template-062824
TEMPLATE_CLS_SHA = "c972aca108fda004c3514d63658e02816da2e54d9a1451e870b9bd970e003f55"

rows: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = ""):
    rows.append((name, ok, detail))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args()
    raw = open(TEX, encoding="utf-8").read()
    # strip comments first: the preamble documents *why* \IEEEoverridecommandlockouts is
    # absent, and a checker that reads comments would fail on its own documentation
    tex = re.sub(r"(?m)(?<!\\)%.*$", "", raw)
    body = tex[tex.index("\\begin{document}"):] if "\\begin{document}" in tex else ""

    # 1. the class and its options, exactly as the template declares them
    m = re.search(r"\\documentclass(\[[^\]]*\])?\{IEEEtran\}", tex)
    check("class is IEEEtran with the conference option",
          bool(m) and m.group(1) == "[conference]",
          (m.group(1) or "(no options)") if m else "no \\documentclass")

    # 2. the class file that ships with these sources is the template's own file
    if os.path.exists(CLS):
        sha = hashlib.sha256(open(CLS, "rb").read()).hexdigest()
        check("paper/IEEEtran.cls is the template's class file", sha == TEMPLATE_CLS_SHA,
              f"{sha[:12]} (template {TEMPLATE_CLS_SHA[:12]})")
    else:
        check("paper/IEEEtran.cls is the template's class file", False, "file missing")

    # 3. the template's own preamble block
    for pkg in ("cite", "amsmath,amssymb,amsfonts", "algorithmic", "graphicx", "textcomp", "xcolor"):
        pat = r"\\usepackage(?:\[[^\]]*\])?\{" + re.escape(pkg) + r"\}"
        check(f"template preamble keeps \\usepackage{{{pkg}}}", bool(re.search(pat, tex)))
    check("template's \\BibTeX logo macro present", "\\def\\BibTeX" in tex)

    # 4. the template states \IEEEoverridecommandlockouts is only for a funding footnote;
    #    if it is used, there must be a footnote for it to carry
    if "\\IEEEoverridecommandlockouts" in tex:
        check("\\IEEEoverridecommandlockouts is justified by a \\thanks",
              "\\thanks{" in tex, "used without a funding footnote")
    else:
        check("\\IEEEoverridecommandlockouts omitted with no funding footnote",
              "\\thanks{" not in tex)

    # 5. algorithms use the template's algorithmic, not algpseudocode
    check("algorithm bodies use the template's algorithmic",
          "\\begin{algorithmic}" in body and "algpseudocode" not in tex)
    check("no algpseudocode commands left",
          not re.search(r"\\(State|EndIf|ElsIf|EndFor|EndWhile)\b", body))

    # 6. author block in the template's multi-author shape
    ab = re.search(r"\\author\{(.*?)\n\n\\maketitle", tex, re.S)
    block = ab.group(1) if ab else ""
    check("author block uses \\IEEEauthorblockN/\\IEEEauthorblockA",
          "\\IEEEauthorblockN{" in block and "\\IEEEauthorblockA{" in block)
    check("author block numbers each author (template form)",
          bool(re.search(r"\\IEEEauthorblockN\{\d\\textsuperscript\{(st|nd|rd|th)\}", block)))
    check("multiple authors are separated by \\and", "\\and" in block or block.count("IEEEauthorblockN") == 1)
    check("no \\thanks inside the author block", "\\thanks" not in block)

    # 7. abstract and index terms in the template's order, and no title footnote
    i_abs = body.find("\\begin{abstract}")
    i_kw = body.find("\\begin{IEEEkeywords}")
    check("abstract precedes IEEEkeywords", 0 <= i_abs < i_kw)
    # the template's own title carries a \thanks for the funding footnote, so a \thanks is
    # allowed; what is not allowed is the template's example subtitle hack
    check("title has no subtitle marker", "\\textsuperscript{*}" not in tex[:tex.find("\\author")])

    # 8. bibliography built with the IEEE style
    check("\\bibliographystyle{IEEEtran)", bool(re.search(r"\\bibliographystyle\{IEEEtran\}", tex)))
    bst = subprocess.run(["kpsewhich", "IEEEtran.bst"], capture_output=True, text=True).stdout.strip()
    ver = ""
    if bst and os.path.exists(bst):
        first = open(bst, encoding="latin-1").read(400)
        mm = re.search(r"Version\s+([0-9.]+)", first)
        ver = mm.group(1) if mm else ""
    check("IEEEtran.bst resolves to the IEEE release", bool(bst) and ver.startswith("1."),
          f"v{ver} at {bst}")

    # 9. nothing in the preamble redefines the class's layout
    check("no geometry/margins override", not re.search(r"\\usepackage(\[[^\]]*\])?\{geometry\}", tex))
    check("no font-size class option", not re.search(r"\\documentclass\[[^\]]*\b(9pt|10pt|11pt)\b", tex))

    width = max(len(r[0]) for r in rows)
    bad = 0
    for name, ok, detail in rows:
        if a.verbose or not ok:
            print(f"[{'✓' if ok else '✗'}] {name:<{width}}  {detail}")
        bad += 0 if ok else 1
    print(f"\n{len(rows) - bad}/{len(rows)} template checks passed")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
