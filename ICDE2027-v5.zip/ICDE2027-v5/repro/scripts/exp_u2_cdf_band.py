import numpy as np
rng = np.random.default_rng(11)

def one_trial(N, n, kind, trials=400):
    # population recalls in [0,1]
    if kind == "beta":
        pop = rng.beta(8, 1, size=N)          # mass near 1, thin tail (like SIFT)
    elif kind == "twopoint":
        pop = (rng.random(N) < 0.1).astype(float)*0.5 + (rng.random(N) >= 0.1)*1.0
    else:
        pop = rng.random(N)
    grid = np.linspace(0.05, 0.95, 91)
    F_N = np.array([(pop < t).mean() for t in grid])
    exceed = 0
    for _ in range(trials):
        idx = rng.choice(N, size=n, replace=False)
        samp = pop[idx]
        F_hat = np.array([(samp < t).mean() for t in grid])
        # candidate bound: epsilon from DKW with finite-population correction
        alpha = 0.05
        eps = np.sqrt((1 - (n - 1)/N) * np.log(2/alpha) / (2*n))
        if np.max(np.abs(F_hat - F_N)) > eps:
            exceed += 1
    return exceed / trials, eps

print(f"{'N':>7} {'n':>6} {'kind':>10} {'empirical sup-violation rate':>28} {'eps':>7}")
for N, n in ((2000, 200), (2000, 1000), (10000, 500), (10000, 5000)):
    for kind in ("beta", "twopoint", "uniform"):
        rate, eps = one_trial(N, n, kind)
        flag = "OK" if rate <= 0.05 else "BOUND VIOLATED"
        print(f"{N:7d} {n:6d} {kind:>10} {rate:28.3f} {eps:7.4f}   {flag}")
