#!/usr/bin/env bash
# Assemble the three deliverables the PI asked for: the PDF, the LaTeX source, and the
# supplementary package. Everything is copied, nothing is rewritten, and every file that
# ships is hashed into dist/SHA256SUMS.
#
#   bash scripts/package_deliverables.sh
#
# Output:
#   dist/paper.pdf                     the submission PDF (byte-identical to paper/build/main.pdf)
#   dist/source/                       main.tex, refs.bib, figures/  (.tex only, no build dir)
#   dist/supplementary/                supplement.pdf + source + generated tables + env + repro
#   dist/ICDE2027-source-and-supp.zip  the two folders above, zipped
#   dist/SHA256SUMS                    hashes of everything that ships
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT=$(pwd)
DIST="$ROOT/dist"

# regenerate first: never package a stale artifact (DECISIONS D006)
bash scripts/build_paper.sh >/dev/null
bash scripts/build_supp.sh >/dev/null
python3 scripts/sync_submit_abstract.py >/dev/null

rm -rf "$DIST"; mkdir -p "$DIST/source" "$DIST/supplementary"

cp paper/build/main.pdf "$DIST/paper.pdf"
cp paper/main.tex paper/refs.bib paper/IEEEtran.cls "$DIST/source/"
cp -r paper/figures "$DIST/source/"
cp -r supp/build "$DIST/supplementary/build"
cp supp/supplement.tex supp/README.md supp/repro.sh supp/MANIFEST.txt "$DIST/supplementary/"
cp -r supp/tables "$DIST/supplementary/"
mkdir -p "$DIST/supplementary/env"
cp -r env/pgvector "$DIST/supplementary/env/"
rm -f "$DIST/supplementary/build"/*.aux "$DIST/supplementary/build"/*.log "$DIST/supplementary/build"/*.out
rm -rf "$DIST/repro/scripts/__pycache__"

# the reviewer asked for the artifacts behind the numbers, not just the paper: ship the
# scripts and the report JSONs that regenerate every table, plus a one-command entry point
mkdir -p "$DIST/repro"
cp -r scripts "$DIST/repro/"
rsync -a --include='*/' --include='*.json' --include='*.npz' --include='*.jsonl' \
      --exclude='*' reports "$DIST/repro/" 2>/dev/null || {
  mkdir -p "$DIST/repro/reports"
  ( cd reports && find . -type f \( -name '*.json' -o -name '*.jsonl' -o -name '*.npz' \) \
      -exec cp --parents {} "$DIST/repro/reports/" \; )
}
cp supp/repro.sh supp/README.md "$DIST/repro/" 2>/dev/null || true
cat > "$DIST/repro/README.md" <<'EOR'
# Reproduction bundle

`scripts/` holds every experiment and every gate; `reports/` holds the JSON artifacts those
scripts produce. Nothing here is needed to read the paper: this bundle exists so that a
reviewer can recompute any number in it.

```bash
bash repro.sh --gates       # rebuild the paper and re-run every number check (~3 min)
python3 scripts/exp_sizing.py
python3 scripts/check_numbers.py
python3 scripts/check_prose_numbers.py --strict
bash scripts/verify_all.sh
```

The heavy experiments (`exp_s0_decay.py`, `exp_audit_protocol.py`, `exp_t3_closed_loop.py`,
`exp_u1_pgvector.py`, `exp_u5_*.py`) need the ann-benchmarks HDF5 datasets and, for the last
group, Docker (see `env/pgvector/Dockerfile` in the supplementary material); each script
regenerates exactly the artifact that backs the corresponding table.
EOR

( cd "$DIST" && find paper.pdf source supplementary repro -type f | sort | xargs sha256sum > SHA256SUMS )
( cd "$DIST" && zip -qr ICDE2027-source-and-supp.zip source supplementary repro )
( cd "$DIST" && sha256sum ICDE2027-source-and-supp.zip >> SHA256SUMS )

echo "dist/paper.pdf            $(pdfinfo "$DIST/paper.pdf" | awk '/^Pages:/{print $2}') pages"
echo "dist/supplementary        $(pdfinfo "$DIST/supplementary/build/supplement.pdf" | awk '/^Pages:/{print $2}') pages"
echo "dist/source               $(find "$DIST/source" -type f | wc -l) files"
echo "zip                       $(du -h "$DIST/ICDE2027-source-and-supp.zip" | cut -f1)"
