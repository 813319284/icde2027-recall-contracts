#!/usr/bin/env bash
# Delivery-integrity check: rebuild from the delivered files only, then prove that what was
# delivered and what the delivered sources produce are the same document.
#
# This is not a re-run of the research. It answers one question: *are the three deliverables
# (PDF, LaTeX source, supplementary package) the same version as each other?* It is the last
# gate before hand-off, because the one failure mode that survives every other check is
# shipping a PDF that the shipped sources do not produce.
#
#   bash scripts/package_deliverables.sh    # first
#   bash scripts/verify_delivery.sh
#
# PDF bytes are not comparable across runs (pdfTeX stamps a creation date), so the comparison
# is on the *text layer* and the page count: identical extracted text, identical pages.
set -euo pipefail
cd "$(dirname "$0")/.."
DIST=dist
[ -d "$DIST/source" ] || { echo "no dist/ — run scripts/package_deliverables.sh first" >&2; exit 1; }

TMP=$(mktemp -d /tmp/delivery-XXXXXX)
trap 'rm -rf "$TMP"' EXIT

echo "== 1/4 rebuild the paper from dist/source only"
mkdir -p "$TMP/paper"
cp "$DIST/source/main.tex" "$DIST/source/refs.bib" "$TMP/paper"/
for f in "$DIST/source"/*.cls "$DIST/source"/*.bst; do [ -e "$f" ] && cp "$f" "$TMP/paper"/ || true; done
cp -r "$DIST/source/figures" "$TMP/paper"/
( cd "$TMP/paper" \
  && pdflatex -interaction=nonstopmode -halt-on-error main.tex >/dev/null \
  && bibtex main >/dev/null \
  && pdflatex -interaction=nonstopmode -halt-on-error main.tex >/dev/null \
  && pdflatex -interaction=nonstopmode -halt-on-error main.tex >/dev/null )
errs=$(grep -c '^!' "$TMP/paper/main.log" || true)
[ "$errs" -eq 0 ] || { echo "rebuilt paper has $errs LaTeX errors" >&2; exit 1; }
p_new=$(pdfinfo "$TMP/paper/main.pdf" | awk '/^Pages:/{print $2}')
p_old=$(pdfinfo "$DIST/paper.pdf" | awk '/^Pages:/{print $2}')
[ "$p_new" = "$p_old" ] || { echo "page count differs: rebuilt $p_new vs delivered $p_old" >&2; exit 1; }

echo "== 2/4 compare the text layer of the delivered PDF and the rebuilt one"
pdftotext "$DIST/paper.pdf" "$TMP/a.txt"
pdftotext "$TMP/paper/main.pdf" "$TMP/b.txt"
if ! cmp -s "$TMP/a.txt" "$TMP/b.txt"; then
  echo "TEXT DIFFERS between dist/paper.pdf and the PDF built from dist/source" >&2
  diff <(head -50 "$TMP/a.txt") <(head -50 "$TMP/b.txt") >&2 || true
  exit 1
fi
echo "   identical text layer ($(wc -c < "$TMP/a.txt") bytes), $p_new pages"

echo "== 3/4 rebuild the supplement from dist/supplementary only"
mkdir -p "$TMP/supp"
cp "$DIST/supplementary/supplement.tex" "$TMP/supp"/
cp -r "$DIST/supplementary/tables" "$TMP/supp"/
( cd "$TMP/supp" \
  && pdflatex -interaction=nonstopmode -halt-on-error supplement.tex >/dev/null \
  && pdflatex -interaction=nonstopmode -halt-on-error supplement.tex >/dev/null )
serrs=$(grep -c '^!' "$TMP/supp/supplement.log" || true)
[ "$serrs" -eq 0 ] || { echo "rebuilt supplement has $serrs LaTeX errors" >&2; exit 1; }
s_new=$(pdfinfo "$TMP/supp/supplement.pdf" | awk '/^Pages:/{print $2}')
pdftotext "$DIST/supplementary/build/supplement.pdf" "$TMP/sa.txt"
pdftotext "$TMP/supp/supplement.pdf" "$TMP/sb.txt"
if ! cmp -s "$TMP/sa.txt" "$TMP/sb.txt"; then
  echo "SUPPLEMENT TEXT DIFFERS from the delivered build" >&2
  exit 1
fi
echo "   supplement reproduces: $s_new pages, identical text"

echo "== 4/4 hashes on record"
( cd "$DIST" && sha256sum -c SHA256SUMS --quiet ) && echo "   dist/SHA256SUMS verifies"
echo
echo "DELIVERY OK: dist/paper.pdf, dist/source/ and dist/supplementary/ are one version."
