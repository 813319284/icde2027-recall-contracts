#!/usr/bin/env python3
"""Curves for the paper: quality (F(tau)) vs the two levers (ef latency, rebuild).

Output: reports/curves.md (paste-ready table) + reports/curves.json.
"""
from __future__ import annotations

import glob
import json
import os
from collections import defaultdict

import numpy as np

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
S0 = os.path.join(REPO, "reports", "s0")
TAUS = [0.80, 0.90, 0.95, 0.99]


def main():
    rows = defaultdict(list)      # (tag, ef) -> records
    for f in sorted(glob.glob(os.path.join(S0, "perquery_*efcurve.jsonl"))):
        tag = os.path.basename(f)[len("perquery_"):-len("_efcurve.jsonl")]
        for line in open(f):
            r = json.loads(line)
            rows[(tag, int(r["ef"]))].append(r)

    out = {}
    lines = ["| world | ef | mean recall | F(0.80) | F(0.90) | F(0.95) | F(0.99) | mean lat (ms) |",
             "|---|---|---|---|---|---|---|---|"]
    for (tag, ef), rs in sorted(rows.items()):
        rec = np.array([r["recall"] for r in rs])
        lat = np.array([r["latency_ms"] for r in rs])
        # latency is measured per batch -> collapse duplicates
        lat_batch = float(np.mean(sorted(set(np.round(lat, 4)))))
        entry = {"n": len(rec), "mean": float(rec.mean()), "lat_ms": lat_batch,
                 "F": {f"{t:.2f}": float((rec < t).mean()) for t in TAUS}}
        out[f"{tag}|ef{ef}"] = entry
        lines.append(f"| {tag} | {ef} | {rec.mean():.4f} | " +
                     " | ".join(f"{entry['F'][f'{t:.2f}']:.3f}" for t in TAUS) +
                     f" | {lat_batch:.3f} |")

    with open(os.path.join(REPO, "reports", "curves.md"), "w") as f:
        f.write("\n".join(lines) + "\n")
    with open(os.path.join(REPO, "reports", "curves.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("\n".join(lines))


if __name__ == "__main__":
    main()
