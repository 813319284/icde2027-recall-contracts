#!/usr/bin/env python3
"""U5-b: audit *allocation* under an exact certificate --- what targeted auditing is worth.

``exp_u5_margin.py`` establishes that the violating queries are not exchangeable: the 10-NN
radius the index already returned ranks them with AUC ~0.70 and the top score decile
violates 6-14x more often than the bottom one, at no extra cost. That is a fact about the
workload. This script turns it into a design and prices it.

Design (exact, no new inequality): split the arrival stream into S strata by the score that
is computable *before* the audit decision. Audit stratum s at its own rate p_s. Within a
stratum the audited subset is still a uniform sample of that stratum, so the paper's exact
hypergeometric limit applies verbatim, and a union bound over strata costs only a factor S
in alpha. Validity is therefore inherited, not re-proved.

The question is cost. Given a contract (tau, phi), a planned per-stratum violation rate F_s
and stratum sizes N_s, the audit rate each stratum needs is the sizing law of the paper
inverted per stratum:

    p_s(phi_s) = min{ p : K^+(F_s N_s, p N_s, N_s, alpha_s) / N_s <= phi_s },

and the certificate over the whole epoch is the weighted sum of the per-stratum limits,
sum_s (N_s/N) phi_s <= phi. So the allocation problem is to choose the per-stratum targets
phi_s --- and hence the audit rates --- that meet the contract for the fewest audits:

    minimise  sum_s N_s p_s(phi_s)   subject to   sum_s (N_s/N) phi_s = phi.

Solved by bisection on the Lagrange multiplier over a grid of phi_s (the per-stratum cost is
decreasing and convex in phi_s). The uniform design (S = 1) is the baseline the paper uses.

Outputs: reports/u5/allocation_<tag>_ef<ef>.json  plus a validity simulation
(sample audits under the plan, check the certificate never undercuts the realized rate).

    python3 scripts/exp_u5_strat.py --tag sift --ef 64 --strata 4 --phi 0.05
"""
from __future__ import annotations

import argparse
import os
import sys

import numpy as np
from scipy.stats import hypergeom

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from icde_lab.logio import dump_json   # noqa: E402

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))


def kplus(k: int, n: int, N: int, alpha: float) -> int:
    """Exact upper limit on the number of violations in a finite population of N."""
    if n >= N:
        return int(min(N, max(k, 0)))
    lo, hi = float(k), float(N)
    for _ in range(50):
        mid = (lo + hi) / 2.0
        K = int(round(mid))
        if float(hypergeom.cdf(k, N, max(K, 0), n)) >= alpha:
            lo = mid
        else:
            hi = mid
    return int(round(min(float(N), lo)))


def p_star(F: float, N: int, phi: float, alpha: float, iters: int = 30) -> float:
    """Audit rate a stratum of size N needs so its exact limit drops to phi (sizing law)."""
    if phi >= 1.0:
        return 0.0
    lo, hi = 0.0, 1.0
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        n = max(1, int(round(mid * N)))
        if kplus(int(round(F * n)), n, N, alpha) / N <= phi:
            hi = mid
        else:
            lo = mid
    return hi


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="sift")
    ap.add_argument("--ef", type=int, default=64)
    ap.add_argument("--strata", type=int, default=4)
    ap.add_argument("--N", type=int, default=1000)
    ap.add_argument("--phi", type=float, default=0.05)
    ap.add_argument("--delta", type=float, default=0.05)
    ap.add_argument("--tau", type=float, default=0.95)
    ap.add_argument("--grid", type=int, default=60)
    ap.add_argument("--reps", type=int, default=400)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--alpha-mode", default="even", choices=["even", "share"],
                    help="even = alpha/S (plain union bound); share = alpha proportional to "
                         "planned violation mass (weighted Bonferroni)")
    a = ap.parse_args()

    d = np.load(os.path.join(REPO, "reports", "u5", f"margin_{a.tag}.npz"))
    score, viol = d[f"score_ef{a.ef}"], d[f"viol_ef{a.ef}"].astype(bool)
    half = len(score) // 2
    sc_cal, vi_cal = score[:half], viol[:half]

    qs = np.quantile(sc_cal, np.linspace(0, 1, a.strata + 1)[1:-1])
    strat = lambda s: np.digitize(s, qs)
    st_cal = strat(sc_cal)
    F_s = np.array([vi_cal[st_cal == s].mean() if (st_cal == s).any() else 0.0 for s in range(a.strata)])
    share = np.array([(st_cal == s).mean() for s in range(a.strata)])
    N_s = np.maximum(np.round(share * a.N).astype(int), 1)

    delta_w = a.delta * 6.0 / (np.pi ** 2)      # first epoch of the geometric schedule
    alpha_uni = delta_w / 2.0
    if a.alpha_mode == "even":
        alpha_s_vec = np.full(a.strata, alpha_uni / a.strata)
    else:                                   # weighted Bonferroni: alpha tracks planned mass
        mass = N_s * F_s + 1e-12
        alpha_s_vec = alpha_uni * mass / mass.sum()
    alpha_s = float(alpha_s_vec.min())      # kept for the S=1 path below

    F_all = float((F_s * N_s).sum() / N_s.sum())
    p_uni = p_star(F_all, a.N, a.phi, alpha_uni)
    budget_uni = p_uni * a.N

    # stratified optimum: minimise sum N_s p_s(phi_s) s.t. sum (N_s/N) phi_s = phi
    grid = np.linspace(1e-4, a.phi, a.grid)
    cost = np.zeros((a.strata, a.grid))
    for s in range(a.strata):
        for j, ph in enumerate(grid):
            cost[s, j] = N_s[s] * p_star(F_s[s], int(N_s[s]), float(ph), float(alpha_s_vec[s]))

    def pick(lam: float):
        j = np.argmin(cost + lam * (N_s[:, None] / N_s.sum()) * grid[None, :], axis=1)
        return j

    lo, hi = 0.0, 1e9
    for _ in range(80):
        lam = 0.5 * (lo + hi)
        j = pick(lam)
        met = float((N_s / N_s.sum() * grid[j]).sum())
        if met > a.phi:
            lo = lam
        else:
            hi = lam
    j = pick(hi)
    phi_s = grid[j]
    p_s = np.array([p_star(F_s[s], int(N_s[s]), float(phi_s[s]), float(alpha_s_vec[s]))
                    for s in range(a.strata)])
    budget_str = float((p_s * N_s).sum())

    # ---- validity simulation: draw epochs from the held-out half, audit under each plan
    sc_ev, vi_ev = score[half:], viol[half:]
    rng = np.random.default_rng(a.seed)
    res = {"uniform": [], "strat": []}
    truth = []
    for _ in range(a.reps):
        idx = rng.choice(len(sc_ev), size=a.N, replace=True)
        v_ep, st = vi_ev[idx], strat(sc_ev[idx])
        K_tot = int(v_ep.sum())
        truth.append(K_tot / a.N)
        # uniform design: one stratum, rate p_uni
        n_u = rng.binomial(a.N, p_uni)
        k_u = int(rng.hypergeometric(K_tot, a.N - K_tot, n_u)) if 0 < n_u < a.N else (K_tot if n_u >= a.N else 0)
        res["uniform"].append(kplus(k_u, n_u, a.N, alpha_uni) / a.N)
        # stratified design
        acc = 0.0
        for s in range(a.strata):
            mask = st == s
            Ns = int(mask.sum())
            if Ns == 0:
                continue
            Ks = int(v_ep[mask].sum())
            ns = rng.binomial(Ns, float(min(max(p_s[s], 0.0), 1.0)))
            ks = int(rng.hypergeometric(Ks, Ns - Ks, ns)) if 0 < ns < Ns else (Ks if ns >= Ns else 0)
            acc += kplus(ks, ns, Ns, float(alpha_s_vec[s]))
        res["strat"].append(acc / a.N)

    truth = np.array(truth)
    summary = {}
    for k, v in res.items():
        v = np.array(v)
        summary[k] = {
            "mean_U": float(v.mean()),
            "p90_U": float(np.percentile(v, 90)),
            "false_cert": int(np.sum(v < truth)),        # certificate below the realized rate
            "p_certify_contract": float((v <= a.phi).mean()),
        }

    out = {
        "tag": a.tag, "ef": a.ef, "strata": a.strata, "N": a.N, "phi": a.phi, "delta": a.delta,
        "tau": a.tau, "reps": a.reps,
        "planned": {"F_s": F_s.tolist(), "N_s": N_s.tolist(), "share": share.tolist(),
                    "F_pooled": F_all, "thresholds": qs.tolist(),
                    "p_uniform": p_uni, "audits_uniform": budget_uni,
                    "alpha_mode": a.alpha_mode, "alpha_s": alpha_s_vec.tolist(),
                    "phi_s": phi_s.tolist(), "p_s": p_s.tolist(), "audits_stratified": budget_str,
                    "audit_saving_vs_uniform": 1.0 - budget_str / budget_uni if budget_uni else 0.0},
        "validity_sim": summary,
        "realized_F_mean": float(truth.mean()),
    }
    os.makedirs(os.path.join(REPO, "reports", "u5"), exist_ok=True)
    dump_json(os.path.join(REPO, "reports", "u5", f"allocation_{a.tag}_ef{a.ef}_s{a.strata}_{a.alpha_mode}.json"), out)

    print(f"S={a.strata} N={a.N} F_pooled={F_all:.3f}")
    print(f"  planned F_s={np.round(F_s,3).tolist()}  N_s={N_s.tolist()}")
    print(f"  uniform   : p*={p_uni:.3f}  audits={budget_uni:.0f}")
    print(f"  stratified: p_s={np.round(p_s,3).tolist()}  phi_s={np.round(phi_s,4).tolist()}  audits={budget_str:.0f}"
          f"   saving={100*(1-budget_str/budget_uni):.1f}%")
    for k, v in summary.items():
        print(f"  {k:8s} mean_U={v['mean_U']:.4f} p90={v['p90_U']:.4f} false_cert={v['false_cert']}/{a.reps} "
              f"certify@phi={v['p_certify_contract']:.3f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
