#!/usr/bin/env python3
"""Audit *prose* numbers against the artifacts.

`check_numbers.py` verifies table cells; this one verifies the numbers that appear in
running text, which is where stale values hide (we shipped 85%/96% for a while after the
protocol rerun made them 86%/97%, and no table check noticed).

Method: strip float environments from main.tex, extract numeric tokens from what remains,
and check each against the set of strings that the artifacts can generate (raw values at
several precisions, percentages, ratios, counts). Anything unmatched is printed for human
review; `--strict` makes it an error.

    python3 scripts/check_prose_numbers.py            # report
    python3 scripts/check_prose_numbers.py --strict    # exit 1 if anything is unmatched
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import re
import sys

def _find_repo(start: str) -> str:
    """Locate the project root, so the checkers also work from a delivered archive.

    In the working tree the root is the parent of ``scripts/``. In the delivery archive the
    scripts sit one level down (``repro/scripts``) with ``paper/`` at the archive root. We walk
    up until we find ``paper/main.tex`` (the authoritative marker); only if that fails do we
    accept a directory that merely contains ``reports/``, because ``repro/`` does too.
    """
    here = os.path.abspath(start)
    chain = []
    d = here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))

# Numbers that are structural or bibliographic, not measurements.
WHITELIST = {
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14",
    "15", "16", "17", "20", "25", "50", "100", "128", "256", "800", "1024", "2048",
    "2009", "2013", "2016", "2018", "2019", "2020", "2021", "2022", "2023", "2024",
    "2025", "2026", "2027", "2028", "2611", "07579", "2603", "16153", "2509", "02896",
    "14778", "3554821", "3554843", "3448016", "3457550", "3746405", "3746426",
    "3543507", "3583552", "3654923", "3600006", "3613166", "101216", "1016",
    # derived quantities (verified in check_numbers.py, not stored in an artifact field)
    "0.9975",   # Markov ceiling 1 - phi(1-tau) = 1 - 0.05*0.05
    "1.65", "1.62", "1.54",  # fitted sizing exponents
    "000",      # artifact of a citation number split by the tokenizer
    "512",      # ef grid value used in the latency sweep (structural, not a measurement)
    "235",      # the number of audited cells, itself verified by preflight against the checker
    "236",      # the cell tally check_numbers.py reports (structural, not a measurement)
    "239",      # audit-to-query ratio on one core (a measurement, also in the tables)
    "20260203050",  # the Jilin Province grant number in the funding footnote, not a measurement
    "95",       # nominal confidence level (95% interval / Wilson CI), not a measurement
    # kerning constants inside the template's \BibTeX logo macro, not measurements
    "05", "025", "08", "1667",
    "96",       # embedding dimensionality of the deep-image corpus
}


def numeric_strings(obj, out: set, pct: set, depth: int = 0):
    """Collect every plausible rendering of every number in the artifacts."""
    if depth > 12:
        return
    if isinstance(obj, dict):
        for v in obj.values():
            numeric_strings(v, out, pct, depth + 1)
    elif isinstance(obj, list):
        for v in obj:
            numeric_strings(v, out, pct, depth + 1)
    elif isinstance(obj, (int, float)) and not isinstance(obj, bool):
        x = float(obj)
        for nd in (0, 1, 2, 3, 4):
            out.add(f"{x:.{nd}f}")
        out.add(f"{x:.0f}")
        for nd in (0, 1, 2):
            pct.add(f"{x * 100.0:.{nd}f}")
        if x:
            out.add(f"{1.0/x:.0f}")
            out.add(f"{1.0/x:.1f}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args()

    tex = open(os.path.join(REPO, "paper", "main.tex")).read()
    # drop float environments and comments: their numbers are covered by check_numbers.py
    # the author block carries e-mail addresses, whose digits are not measurements
    tex = re.sub(r"\\author\{.*?\n\n\\maketitle", " ", tex, flags=re.S)
    tex = re.sub(r"\\begin\{(table|figure)\*?\}.*?\\end\{(table|figure)\*?\}", " ", tex, flags=re.S)
    tex = re.sub(r"(?m)(?<!\\)%.*$", " ", tex)   # strip comments, but not escaped \%
    # drop equations and labels
    tex = re.sub(r"\\begin\{equation\}.*?\\end\{equation\}", " ", tex, flags=re.S)
    tex = re.sub(r"\\label\{[^}]*\}", " ", tex)
    tex = re.sub(r"\\(cref|ref|cite|eqref)\{[^}]*\}", " ", tex)

    known: set[str] = set(WHITELIST)
    pct_known: set[str] = set()
    for path in glob.glob(os.path.join(REPO, "reports", "**", "*.json"), recursive=True):
        try:
            numeric_strings(json.load(open(path)), known, pct_known)
        except Exception:  # noqa: BLE001
            continue

    # percentages in prose must match a percentage rendering, not any raw value
    pct_tokens = re.findall(r"(\d+(?:\.\d+)?)\s*\\%", tex)
    tex_wo_pct = re.sub(r"\d+(?:\.\d+)?\s*\\%", " ", tex)
    tokens = re.findall(r"\d+(?:\.\d+)?", tex_wo_pct)

    unknown: dict[str, int] = {}
    for t in tokens:
        if t in known:
            continue
        norm = t.rstrip("0").rstrip(".") if "." in t else t
        if norm in known:
            continue
        unknown[t] = unknown.get(t, 0) + 1
    for t in pct_tokens:
        if t in known or t in pct_known:
            continue
        norm = t.rstrip("0").rstrip(".")
        if norm in pct_known:
            continue
        unknown[t + "%"] = unknown.get(t + "%", 0) + 1
    tokens = tokens + pct_tokens

    print(f"prose numeric tokens: {len(tokens)}, unmatched: {len(unknown)}")
    for t, n in sorted(unknown.items(), key=lambda kv: -kv[1])[:40]:
        print(f"  {t:>10}  x{n}")
    if unknown:
        print("\nThese are candidates for stale or unsupported numbers; verify each by hand.")
    return 1 if (a.strict and unknown) else 0


if __name__ == "__main__":
    sys.exit(main())
