"""U3 validation: Ville bound for the HT martingale under predictable, varying audit rates.

Reproduces the 0/200-violation check reported in relay/NOTES_U3.md.
"""
import numpy as np
rng = np.random.default_rng(7)
delta = 0.05
T = 2000
R = None
def run(pmin=0.05):
    # predictable audit rates: depend on history only
    p = np.clip(0.05 + 0.3*np.abs(np.sin(np.arange(T)/50.0)), pmin, 1.0)
    b = 1.0/p - 1.0            # per-step upper increment bound
    Rmax = b.max() + 1.0       # range of increments
    # adversarial-ish violation stream: drifts from 0.02 to 0.30
    q = 0.02 + 0.28*(np.arange(T)/T)
    Y = (rng.random(T) < q).astype(float)
    X = (rng.random(T) < p).astype(float)
    M = np.cumsum(X*Y/p - Y)
    t = np.arange(1, T+1)
    # Ville bound for a fixed lambda: P(exists t: M_t >= (log(1/delta) + lam^2 R^2 t/8)/lam) <= delta
    lams = 2.0**np.arange(-6, 4)          # discrete grid
    weights = np.ones_like(lams)/len(lams)
    viol = 0
    for lam, w in zip(lams, weights):
        bound = (np.log(1.0/(delta*w)) + lam**2 * Rmax**2 * t/8.0)/lam
        if np.any(M >= bound):
            viol += 1
    return viol, M, Rmax
bad = 0
trials = 200
for _ in range(trials):
    viol,_,_ = run()
    if viol > 0: bad += 1
print(f"fraction of runs where ANY lambda's Ville bound was violated: {bad}/{trials} = {bad/trials:.3f}  (should be <= delta={delta})")
