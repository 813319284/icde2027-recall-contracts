#!/usr/bin/env bash
# Deterministic paper build (independent of the shared tex.py wrapper).
#
# Why this exists: tex.py compiles with an out-of-tree build directory, and bibtex then
# cannot see ../refs.bib. A clean build therefore produced a PDF with 19 unresolved
# citations while still reporting success. This script stages the sources into
# paper/build/ and runs the classic pdflatex -> bibtex -> pdflatex x2 sequence there.
set -euo pipefail
HERE=$(cd "$(dirname "$0")/.." && pwd)
# locate the project root: in the working tree it is the parent of scripts/, in a delivered
# archive the scripts sit under repro/ with paper/ at the archive root
ROOT=$HERE
for cand in "$HERE" "$(dirname "$HERE")" "$(dirname "$(dirname "$HERE")")"; do
  if [ -e "$cand/paper/main.tex" ]; then ROOT=$cand; break; fi
done
SRC="$ROOT/paper"
B="$SRC/build"

rm -rf "$B"; mkdir -p "$B"
cp "$SRC/main.tex" "$SRC/refs.bib" "$B"/
# ship the venue class/bib files with the sources so the build does not depend on which
# IEEEtran revision happens to be installed (paper/IEEEtran.cls is the template's own file)
for f in "$SRC"/*.cls "$SRC"/*.bst; do [ -e "$f" ] && cp "$f" "$B"/ || true; done
[ -d "$SRC/figures" ] && cp -r "$SRC/figures" "$B/"

cd "$B"
# Reproducible output: with a fixed SOURCE_DATE_EPOCH pdfTeX stops stamping the wall clock
# into CreationDate/ModDate, so rebuilding the same sources gives the same bytes. That makes
# `sha256sum` a meaningful identity for "the PDF I checked is the PDF I uploaded".
export SOURCE_DATE_EPOCH=${SOURCE_DATE_EPOCH:-1757484000}   # 2025-09-10T10:00:00Z, fixed
export FORCE_SOURCE_DATE=1
pdflatex -interaction=nonstopmode -halt-on-error main.tex >/dev/null
bibtex main >/dev/null
pdflatex -interaction=nonstopmode -halt-on-error main.tex >/dev/null
pdflatex -interaction=nonstopmode -halt-on-error main.tex >/dev/null

errors=$(grep -c '^!' main.log || true)
unresolved=$(grep -c "Citation.*undefined" main.log || true)
bibitems=$(grep -c '\\bibitem' main.bbl || true)
echo "bibitems=$bibitems  unresolved_citations=$unresolved"
echo "latex_errors=$errors"
if [ "$bibitems" -lt 20 ] || [ "$unresolved" -ne 0 ] || [ "$errors" -ne 0 ]; then
  echo "BUILD FAILED: errors=$errors bibitems=$bibitems unresolved=$unresolved" >&2
  grep -m3 '^!' main.log >&2 || true
  exit 1
fi
# provenance: hash the sources this PDF was built from
( cd "$SRC" && { sha256sum main.tex refs.bib; \
    find figures -name '*.pdf' 2>/dev/null | sort | xargs -r sha256sum; } \
  | sha256sum | cut -d" " -f1 ) > "$B/SOURCE_HASH"
echo "source hash: $(cat "$B/SOURCE_HASH")"
# self-contained PDF hygiene (no dependency on the shared tex.py wrapper, which lives
# outside this archive): fonts embedded, text extractable, page size
# the "emb" column is the fourth from the right; every font must say yes there
fonts_missing=$(pdffonts "$B/main.pdf" | awk 'NR>2 && NF>5 && $(NF-4) != "yes"' | wc -l)
chars=$(pdftotext "$B/main.pdf" - | wc -c)
pages=$(pdfinfo "$B/main.pdf" | awk '/^Pages:/{print $2}')
echo "pdf: pages=$pages embedded_fonts_ok=$([ "$fonts_missing" -eq 0 ] && echo yes || echo no) text_chars=$chars"
if [ "$fonts_missing" -ne 0 ] || [ "$chars" -lt 10000 ]; then
  echo "PDF CHECK FAILED: unembedded fonts=$fonts_missing chars=$chars" >&2; exit 1
fi
