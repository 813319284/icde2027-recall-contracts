#!/usr/bin/env python3
"""Render the pgvector closed-loop table from its artifacts (whole block, never a patch).

Discipline (DECISIONS D009): a table body is *rebuilt* from the JSON, never edited cell by
cell. This prints the complete ``table`` environment so a human can paste it, and
``--check`` verifies that the block already in main.tex matches what the artifacts say.

    python3 scripts/make_pg_table.py            # print the block
    python3 scripts/make_pg_table.py --check     # exit 1 if the paper disagrees
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

def _find_repo(start: str) -> str:
    """Locate the project root, so the checkers also work from a delivered archive.

    In the working tree the root is the parent of ``scripts/``. In the delivery archive the
    scripts sit one level down (``repro/scripts``) with ``paper/`` at the archive root. We walk
    up until we find ``paper/main.tex`` (the authoritative marker); only if that fails do we
    accept a directory that merely contains ``reports/``, because ``repro/`` does too.
    """
    here = os.path.abspath(start)
    chain = []
    d = here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
ART = os.path.join(REPO, "reports", "u1", "pg_sift-128-euclidean_churn_all_s1.json")
TEX = os.path.join(REPO, "paper", "main.tex")

# label in the table -> policy key in the artifact
# Four rows: the default, physical maintenance, the monitor the field uses today, and the
# contract controller. At ef=64 the mean recall is 0.966 while 12-15% of queries fall below
# the target, which is exactly the configuration in which a mean SLA is the wrong object.
ROWS = [
    ("never", "never"),
    ("REINDEX every 4", "periodic_4"),
    ("mean-recall monitor", "ctrl_mean"),
    ("contract controller", "ctrl"),
]


def load():
    data = json.load(open(ART))
    return {d["policy"]: d for d in data}



def passes(d: dict) -> tuple[int, int]:
    """(epochs the rule told its operator were fine, how many of those were wrong).

    The rules certify with different statistics by construction: the mean monitor tests a
    mean SLA and the others test the contract. So the column reports what each rule *said*,
    not what one shared oracle said---that is the comparison the table is making.
    """
    s = d["summary"]
    if d["policy"] == "ctrl_mean":
        n = s["certified_epochs"]
        bad = sum(1 for r in d["rounds_detail"] if r["certified"] and r["f_true"] > d["phi"])
    else:
        n = s["verdicts"]["pass"]
        bad = sum(1 for r in d["rounds_detail"]
                  if r["verdict"] == "pass" and r["f_true"] > d["phi"])
    return n, bad

def fmt_row(label: str, d: dict) -> str:
    s = d["summary"]
    viol = f"{s['violation_epochs']}/{s['n_epochs']}"
    reb = f"{s['n_rebuilds']} ({s['rebuild_s']:.1f})" if s["n_rebuilds"] else "0 (0.0)"
    p50 = f"{s['mean_latency_p50_ms']:.2f}"
    cert, false_pass = passes(d)
    if false_pass:
        cert_s = f"{cert} (\\textbf{{{false_pass} false}})"
    else:
        cert_s = str(cert)
    return f"{label} & {viol} & {reb} & {p50} & {cert_s}\\\\"


def block() -> str:
    data = load()
    d0 = data["never"]
    d0p = data["periodic_4"]
    cfg = (f"SIFT-128, {d0['n_base']//1000}k live rows, stock index parameters "
           f"$m{{=}}{d0['m']}$, $\\mathrm{{efConstruction}}{{=}}{d0['efc']}$, "
           f"churn {100*d0['delete_frac']:g}\\%/epoch")
    body = "\n".join(fmt_row(label, data[key]) for label, key in ROWS)
    return (
        "\\begin{table}[t]\n"
        "\\centering\n"
        "\\caption{The same closed loop inside PostgreSQL~16 with pgvector~0.8.7 "
        f"({cfg}; {d0['rounds']} epochs of {d0['nq']} arrivals, "
        f"{d0['audit_m']} audited, $\\tau{{=}}{d0['tau']}$, $\\phi{{=}}{d0['phi']}$). "
        f"Periodic \\texttt{{REINDEX}} spends {d0p['summary']['rebuild_s']:.1f}\\,s across "
        f"{d0p['summary']['n_rebuilds']} rebuilds and leaves all {d0p['summary']['violation_epochs']} "
        "epochs in violation; search effort is the lever that clears the contract. "
        "``reported passes'' counts the epochs in which a rule told its operator the target "
        "was met, by the statistic that rule trusts; the bracket is how many of those epochs "
        "were in violation.}\n"
        "\\label{tab:pgvector}\n"
        "\\footnotesize\\setlength{\\tabcolsep}{3pt}\n"
        "\\begin{tabular}{lcccc}\n"
        "\\toprule\n"
        "strategy & violating & rebuilds & p50 & reported passes\\\\\n"
        " & epochs & (count, s) & (ms) & (of "
        f"{d0['rounds']})\\\\\n"
        "\\midrule\n"
        f"{body}\n"
        "\\bottomrule\n"
        "\\end{tabular}\n"
        "\\end{table}"
    )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    if not os.path.exists(ART):
        print(f"no artifact at {ART} — run scripts/exp_u1_pgvector.py first")
        return 1
    b = block()
    if not a.check:
        print(b)
        return 0
    tex = open(TEX).read()
    i = tex.find("\\label{tab:pgvector}")
    if i < 0:
        print("table tab:pgvector is not in the paper yet")
        return 1
    start, end = tex.rfind("\\begin{table}", 0, i), tex.find("\\end{table}", i) + len("\\end{table}")
    have = tex[start:end]
    norm = lambda s: re.sub(r"\s+", " ", s).strip()
    if norm(have) != norm(b):
        print("MISMATCH between paper and artifact")
        for ln_e, ln_h in zip(norm(b).split("\n")[0].split("\\\\"), norm(have).split("\n")[0].split("\\\\")):
            if ln_e != ln_h:
                print(f"  want: {ln_e}\n  have: {ln_h}")
        return 1
    print("tab:pgvector matches the artifact")
    return 0


if __name__ == "__main__":
    sys.exit(main())
