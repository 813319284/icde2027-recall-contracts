#!/usr/bin/env python3
"""Power sweep with a persisted artifact.

Table V in the paper reports certification power against audit rate. Those numbers were
originally read off console output and never persisted, which breaks the paper's own rule
that every number traces to an artifact. This script regenerates them from the same
boundary protocol used everywhere else and writes reports/s0/power_sweep.json.

    python3 scripts/exp_power_sweep.py --runs 400
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
P_GRID = [0.02, 0.05, 0.10, 0.20, 0.40]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=400)
    ap.add_argument("--regime", default="mixed", choices=["mixed", "boundary"])
    a = ap.parse_args()
    out = {}
    for p in P_GRID:
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            tmp = f.name
        subprocess.run([sys.executable, os.path.join(REPO, "scripts", "exp_audit_protocol.py"),
                        "--runs", str(a.runs), "--p", str(p), "--regime", a.regime,
                        "--spend", "uniform", "--out", tmp],
                       check=True, capture_output=True, text=True)
        r = json.load(open(tmp))["rules"]
        out[f"{p:.2f}"] = {
            "power_ours": r["ours"]["epoch_tcr"],
            "power_fixed": r["exact_fixed"]["epoch_tcr"],
            "fp_mean": r["mean"]["epoch_fcr"],
            "fcr_ours": r["ours"]["run_fcr"],
            "fcr_fixed": r["exact_fixed"]["run_fcr"],
        }
        os.unlink(tmp)
        print(f"p={p:.2f}  power ours={out[f'{p:.2f}']['power_ours']:.3f} "
              f"fixed={out[f'{p:.2f}']['power_fixed']:.3f} "
              f"mean fp/epoch={out[f'{p:.2f}']['fp_mean']:.3f}", flush=True)
    path = os.path.join(REPO, "reports", "s0", f"power_sweep_{a.regime}.json")
    json.dump(out, open(path, "w"), indent=1)
    print(f"wrote {path}")


if __name__ == "__main__":
    main()
