#!/usr/bin/env python3
"""T2/T1-sequential: is a *running* contract actually valid?

The cross-sectional decision matrix (exp_t1_audit.py) answers "one audit, one
decision". A deployed contract makes a decision at every epoch, so any interval
without alpha-spending is invalidated by multiplicity: a fixed-sample 95%
interval checked 36 times misses ~1-(1-0.05)^36 = 84% of the time.

Stream = concatenation of worlds (segments). At each segment boundary the
certifier issues PASS/FAIL. Headline numbers:
  P(any false PASS over the whole run)   <- the contract's actual guarantee
  TCR (fraction of compliant segments passed)
  revocation lag (segments until FAIL after a violation starts)
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + "/scripts")
from exp_t1_audit import clopper_pearson_upper, eb_upper          # noqa: E402
from exp_t1_audit import load_worlds, t_upper_mean                # noqa: E402

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))


def alpha_spend(delta: float, w: int, mode: str = "geom", horizon: int = 12) -> float:
    """Error budget per epoch (geom: unbounded horizon; uniform: known horizon)."""
    if mode == "uniform":
        return delta / max(horizon, 1)
    return delta * 6.0 / (np.pi ** 2 * max(w, 1) ** 2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tau", type=float, default=0.95)
    ap.add_argument("--phi", type=float, default=0.05)
    ap.add_argument("--p", type=float, default=0.05)
    ap.add_argument("--delta", type=float, default=0.05)
    ap.add_argument("--spend", default="geom", choices=["geom", "uniform"])
    ap.add_argument("--reps", type=int, default=200)
    ap.add_argument("--order", default="bad_last", choices=["bad_last", "interleaved"])
    ap.add_argument("--out", default="reports/s0/t1_sequential.json")
    ap.add_argument("--worlds-good", default="")
    ap.add_argument("--worlds-bad", default="")
    ap.add_argument("--synthetic-f", default="",
                    help="comma list of true F values; overrides worlds with Bernoulli(F) segments")
    ap.add_argument("--boundary", action="store_true",
                    help="resample each segment so its true F sits just above phi (multiplicity stress)")
    a = ap.parse_args()

    worlds = load_worlds()
    names = sorted(worlds)
    bad = [n for n in names if worlds[n]["recall"].__len__() and
           float((worlds[n]["recall"] < a.tau).mean()) > a.phi]
    good = [n for n in names if n not in bad]
    if not bad or not good:
        raise SystemExit(f"need both sides: good={len(good)} bad={len(bad)}")

    n_seg = 12
    if a.worlds_good:
        good = a.worlds_good.split(",")
    if a.worlds_bad:
        bad = a.worlds_bad.split(",")
    for n in good + bad:
        if n not in worlds:
            raise SystemExit(f"unknown world {n}; available: {names}")
    seq = [good[i % len(good)] for i in range(n_seg // 2)] + [bad[i % len(bad)] for i in range(n_seg - n_seg // 2)]
    if a.order == "interleaved":
        seq = [good[0], bad[0]] * (n_seg // 2)

    syn = [float(v) for v in a.synthetic_f.split(",") if v] if a.synthetic_f else []
    tru = np.array([float((worlds[n]["recall"] < a.tau).mean()) for n in seq])
    if syn:
        n_seg = len(syn)
        seq = seq[:n_seg] if len(seq) >= n_seg else [seq[0]] * n_seg
        tru = np.array(syn)

    rules = ["exact_spent", "exact_naive", "eb_spent", "mean_rule"]
    any_false = {r: 0 for r in rules}
    any_cert = {r: 0 for r in rules}
    tp = {r: 0 for r in rules}
    fn = {r: 0 for r in rules}
    lag = {r: [] for r in rules}

    for rep in range(a.reps):
        rng = np.random.default_rng(10_000 + rep)
        certified = {r: np.zeros(n_seg, bool) for r in rules}
        for w, n in enumerate(seq):
            if syn:
                rec = np.where(rng.random(4000) < tru[w], 0.0, 1.0)
            else:
                rec = worlds[n]["recall"]
            if a.boundary:
                # resample to land just above phi: sample m0 queries, keep drawing until
                # the realised violation rate is in [phi, phi+0.02]
                pool = rec
                viol_pool = (pool < a.tau)
                want = a.phi + 0.01
                for _try in range(200):
                    cand = rng.choice(len(pool), size=1200, replace=False)
                    fr = float(viol_pool[cand].mean())
                    if a.phi <= fr <= a.phi + 0.03:
                        rec = pool[cand]
                        break
            viol = (rec < a.tau).astype(float)
            m_all = len(rec)
            aud = rng.random(m_all) < a.p
            m = max(int(aud.sum()), 1)
            k = int(viol[aud].sum())
            a_w = alpha_spend(a.delta, w + 1, a.spend, n_seg)
            certified["exact_spent"][w] = clopper_pearson_upper(k, m, a_w) <= a.phi
            certified["exact_naive"][w] = clopper_pearson_upper(k, m, a.delta) <= a.phi
            certified["eb_spent"][w] = eb_upper(k, m, a_w) <= a.phi
            lb_mean = float(viol[aud].mean() - 1.645 * viol[aud].std(ddof=1) / np.sqrt(m))
            certified["mean_rule"][w] = lb_mean >= a.tau if False else (
                float(rec[aud].mean() - 1.645 * rec[aud].std(ddof=1) / np.sqrt(m)) >= a.tau)
        for r in rules:
            false_pass = np.any(certified[r] & (tru > a.phi))
            any_false[r] += int(false_pass)
            any_cert[r] += int(certified[r].any())
            ok = tru <= a.phi
            tp[r] += int(np.sum(certified[r][ok]))
            fn[r] += int(np.sum(~certified[r][ok]))
            # revocation lag: first violation segment -> first FAIL at/after it
            first_bad = int(np.argmax(tru > a.phi)) if np.any(tru > a.phi) else None
            if first_bad is not None:
                after = np.where(~certified[r][first_bad:])[0]
                lag[r].append(int(after[0]) if len(after) else 99)

    print(f"stream: {n_seg} segments  good={sum(tru <= a.phi)} bad={sum(tru > a.phi)}  "
          f"p={a.p} delta={a.delta} reps={a.reps} order={a.order}")
    print(f"{'rule':14s} {'P(any false PASS)':>18s} {'P(pass>=1 seg)':>15s} {'TCR':>6s} {'median revoke lag':>18s}")
    out = {"args": vars(a), "sequence": seq, "truth": tru.tolist(), "rules": {}}
    for r in rules:
        fpr = any_false[r] / a.reps
        pcr = any_cert[r] / a.reps
        tcr = tp[r] / max(tp[r] + fn[r], 1)
        ml = float(np.median(lag[r])) if lag[r] else float("nan")
        print(f"{r:14s} {fpr:18.3f} {pcr:15.3f} {tcr:6.3f} {ml:18.1f}")
        out["rules"][r] = {"p_any_false_pass": fpr, "p_pass_any": pcr, "tcr": tcr,
                           "median_revoke_lag": ml}
    with open(os.path.join(REPO, a.out), "w") as f:
        json.dump(out, f, indent=1)
    print("\n判据：'P(any false PASS)' 才是合同真正承诺的量（应 ≤ delta）；固定样本区间在多次决策下会爆。")


if __name__ == "__main__":
    main()
