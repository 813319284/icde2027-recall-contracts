#!/usr/bin/env python3
"""Generate the supplementary-material table fragments from the artifacts.

The supplement must not contain a number that no script produced, so every table in it is
written by this file and ``\\input`` by ``supp/supplement.tex``:

    supp/tables/pg_closedloop.tex   PostgreSQL + pgvector closed loop (reports/u1)
    supp/tables/pg_per_epoch.tex    per-epoch log of the two extreme policies
    supp/tables/u5_deciles.tex      risk-score deciles (reports/u5/margin_*)
    supp/tables/u5_allocation.tex   iso-budget audit cost of stratifying (reports/u5/allocation_*)

    python3 scripts/make_supp_tables.py
"""
from __future__ import annotations

import json
import os

import numpy as np
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_pg_table  # noqa: E402

def _find_repo(start: str) -> str:
    """Locate the project root, so the checkers also work from a delivered archive.

    In the working tree the root is the parent of ``scripts/``. In the delivery archive the
    scripts sit one level down (``repro/scripts``) with ``paper/`` at the archive root. We walk
    up until we find ``paper/main.tex`` (the authoritative marker); only if that fails do we
    accept a directory that merely contains ``reports/``, because ``repro/`` does too.
    """
    here = os.path.abspath(start)
    chain = []
    d = here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
def _supp_dir(root: str) -> str:
    """The supplementary source directory: `supp/` in the tree, `supplementary/` in a bundle."""
    for name in ("supp", "supplementary"):
        if os.path.isdir(os.path.join(root, name)):
            return os.path.join(root, name)
    return os.path.join(root, "supp")


OUT = os.path.join(_supp_dir(REPO), "tables")


def load(path):
    with open(os.path.join(REPO, path)) as f:
        return json.load(f)


def write(name: str, body: str):
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, name), "w", encoding="utf-8") as f:
        f.write(body)
    print(f"wrote supp/tables/{name}")


def pg_closedloop():
    d = {x["policy"]: x for x in load("reports/u1/pg_sift-128-euclidean_churn_all_s1.json")}
    s0 = d["never"]
    rows = []
    for label, key in make_pg_table.ROWS:
        s = d[key]["summary"]
        reb = f"{s['n_rebuilds']} ({s['rebuild_s']:.1f})" if s["n_rebuilds"] else "0 (0.0)"
        cert_n, false_pass = make_pg_table.passes(d[key])
        cert = str(cert_n)
        if false_pass:
            cert += f" (\\emph{{{false_pass} false}})"
        rows.append(f"{label} & {s['violation_epochs']}/{s['n_epochs']} & {reb} & "
                    f"{s['mean_latency_p50_ms']:.2f} & {s['mean_latency_p95_ms']:.2f} & "
                    f"{s['mean_audit_ms']:.1f} & {cert}\\\\")
    body = (
        "\\begin{tabular}{lcccccc}\n\\toprule\n"
        "strategy & violating & rebuilds & p50 & p95 & exact audit & certified\\\\\n"
        " & epochs & (count, s) & (ms) & (ms) & (ms) & (epochs)\\\\\n\\midrule\n"
        + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}\n")
    write("pg_closedloop.tex", body)
    cfg = {
        "n_base": s0["n_base"], "batch": s0["batch"], "rounds": s0["rounds"],
        "nq": s0["nq"], "audit_m": s0["audit_m"], "m": s0["m"], "efc": s0["efc"],
        "delete_frac": s0["delete_frac"], "tau": s0["tau"], "phi": s0["phi"],
        "delta": s0["delta"], "build_s": s0["build_s"], "wall_s": s0["wall_s"],
    }
    pretty = {
        "live rows (base)": f"{cfg['n_base']}", "churn inserted per epoch": f"{cfg['batch']}",
        "epochs": f"{cfg['rounds']}", "arrivals per epoch": f"{cfg['nq']}",
        "audited per epoch": f"{cfg['audit_m']}", "HNSW m": f"{cfg['m']}",
        "efConstruction": f"{cfg['efc']}", "delete fraction": f"{cfg['delete_frac']}",
        "tau": f"{cfg['tau']}", "phi": f"{cfg['phi']}", "delta": f"{cfg['delta']}",
        "bulk index build (s)": f"{cfg['build_s']:.1f}",
    }
    rows = "\n".join(f"{k} & {v}\\\\" for k, v in pretty.items())
    write("pg_config.tex",
          "\\begin{tabular}{lr}\n\\toprule\nsetting & value\\\\\n\\midrule\n"
          + rows + "\n\\bottomrule\n\\end{tabular}\n")


def pg_per_epoch():
    d = {x["policy"]: x for x in load("reports/u1/pg_sift-128-euclidean_churn_all_s1.json")}
    rows = []
    for key in ("never", "ctrl_mean", "ctrl"):
        for r in d[key]["rounds_detail"]:
            label = key.replace("_", "\\_")
            rows.append(f"{label} & {r['t']} & {r['live_rows']} & {r['F_hat_op']:.3f} & "
                        f"{r['f_true']:.3f} & {r['U']:.3f} & {r['verdict']} & {r['ef']} & "
                        f"{r['latency_p50_ms']:.2f} & {r['audit_ms']:.1f} & {r['action']}\\\\")
    body = (
        "\\begin{tabular}{lcccccccccc}\n\\toprule\n"
        "policy & epoch & live rows & $\\hat F$ & $F$ & $U$ & verdict & ef & p50 & audit & action\\\\\n"
        "\\midrule\n" + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}\n")
    write("pg_per_epoch.tex", body)


def u5_deciles():
    d = load("reports/u5/margin_sift.json")
    rows = []
    for ef in ("32", "64", "128"):
        dd = d["deciles"][f"ef{ef}"]
        rates = dd["violation_by_decile_high_to_low"]
        rows.append(f"ef={ef} & " + " & ".join(f"{x:.3f}" for x in rates) +
                    f" & {dd['top_bottom_decile_ratio']:.1f}\\\\")
    body = (
        "\\begin{tabular}{lccccccccccc}\n\\toprule\n"
        "setting & D1 & D2 & D3 & D4 & D5 & D6 & D7 & D8 & D9 & D10 & D1/D10\\\\\n"
        "\\midrule\n" + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}\n")
    write("u5_deciles.tex", body)
    auc_rows = []
    for ef in ("32", "64", "128"):
        sc = d["per_ef"][f"ef{ef}"]
        auc_rows.append(f"ef={ef} & " + " & ".join(f"{sc[n]['auc']:.3f}"
                                                   for n in ("spread", "gap_tail", "abs_dk")) + "\\\\")
    write("u5_auc.tex",
          "\\begin{tabular}{lccc}\n\\toprule\nsetting & $d_k/d_1$ & tail gap & $d_k$\\\\\n"
          "\\midrule\n" + "\n".join(auc_rows) + "\n\\bottomrule\n\\end{tabular}\n")


def u5_allocation():
    rows = []
    for S, mode in (("2", "even"), ("4", "even"), ("2", "share"), ("4", "share")):
        path = f"reports/u5/allocation_sift_ef128_s{S}_{mode}.json"
        if not os.path.exists(os.path.join(REPO, path)):
            continue
        d = load(path)
        p = d["planned"]
        rows.append(f"S={S} {mode} & {p['p_uniform']:.3f} & {p['audits_uniform']:.0f} & "
                    f"{p['audits_stratified']:.0f} & "
                    f"{100*p['audit_saving_vs_uniform']:.1f}\\% & "
                    f"{d['validity_sim']['uniform']['false_cert']} & "
                    f"{d['validity_sim']['strat']['false_cert']}\\\\")
    if not rows:
        write("u5_allocation.tex", "% no allocation artifacts yet\n")
        return
    body = (
        "\\begin{tabular}{lcccccc}\n\\toprule\n"
        "design & $p^{\\star}$ pooled & audits pooled & audits stratified & saving & "
        "false cert.\\ (pooled) & false cert.\\ (stratified)\\\\\n\\midrule\n"
        + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}\n")
    write("u5_allocation.tex", body)



def cross_engine():
    """The same nominal HNSW parameters measured in two engines."""
    faiss = np.load(os.path.join(REPO, "reports", "u5", "margin_sift.npz"))
    pg = load("reports/u1/pg_mean.json")
    rows = []
    for ef in (64, 128):
        if f"recall_ef{ef}" in faiss:
            r = faiss[f"recall_ef{ef}"]
            rows.append(f"FAISS (no churn) & 200k & 16 & 64 & {ef} & {r.mean():.3f} & "
                        f"{float((r < 0.95).mean()):.3f} & {np.percentile(r, 5):.2f} \\\\")
        pe = pg["per_ef"][str(ef)]
        rows.append(f"pgvector (2.5\\%/epoch churn) & 200k & 16 & 64 & {ef} & "
                    f"{pe['mean_recall']:.3f} & {pe['F_tau']:.3f} & {pe['p05']:.2f} \\\\")
    body = ("\\begin{tabular}{lccccc lcc}\n\\toprule\n"
            "engine & base & $m$ & efC & ef & mean & $F(0.95)$ & p05\\\\\n"
            "\\midrule\n" + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}\n")
    write("cross_engine.tex", body)


def main() -> int:
    if not os.path.exists(os.path.join(REPO, "reports", "u1",
                                       "pg_sift-128-euclidean_churn_all_s1.json")):
        print("U1 artifact missing — run scripts/exp_u1_pgvector.py first")
        return 1
    pg_closedloop()
    pg_per_epoch()
    u5_deciles()
    u5_allocation()
    cross_engine()
    return 0


if __name__ == "__main__":
    sys.exit(main())
