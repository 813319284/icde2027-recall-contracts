#!/usr/bin/env python3
"""T1 experiment: does each audit rule certify the truth?

Replays the per-query logs as "worlds" (dataset × drift × ef) and asks, for an
audit budget p and contract (tau, phi):

  * truth        F(τ) = P[recall < τ] over the whole world
  * our bound    time-uniform empirical-Bernstein bound on F built from audited
                 queries with predictable inclusion probability (Ville/Freedman)
  * baselines    (1) mean-recall t-interval  (what deployments actually check)
                 (2) i.i.d. Hoeffding on the tail fraction
                 (3) one-shot audit at t0, then certify forever (stale audit)
                 (4) cluster bootstrap over query clusters

A rule "certifies" when its upper bound is <= phi. A **false certification** is
certifying a world whose true F(τ) > phi. That single number is the paper's
headline for T1: it is what an SLA actually buys.
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

import numpy as np
from scipy.stats import binom, hypergeom

def _find_repo(start):
    """Project root: the parent of scripts/ in the tree, the archive root in a bundle.

    In the delivery archive the scripts sit in ``repro/scripts`` while ``reports/`` and
    ``paper/`` are at the archive root, so a fixed ``dirname(dirname(__file__))`` would
    resolve to ``repro/``. Walk up to the first directory that carries ``paper/main.tex``.
    """
    here = os.path.abspath(start)
    chain, d = [], here
    for _ in range(4):
        chain.append(d)
        d = os.path.dirname(d)
    for cand in chain:
        if os.path.exists(os.path.join(cand, "paper", "main.tex")):
            return cand
    for cand in chain:
        if os.path.isdir(os.path.join(cand, "reports")):
            return cand
    return here


REPO = _find_repo(os.path.dirname(os.path.abspath(__file__)))
S0 = os.path.join(REPO, "reports", "s0")


# ----------------------------------------------------------------------------- bounds
def eb_upper(k: int, n: int, alpha: float) -> float:
    """Empirical-Bernstein (Freedman-style) one-sided upper bound for a Bernoulli mean."""
    if n == 0:
        return 1.0
    phat = k / n
    logterm = np.log(2.0 / alpha)
    # Maurer-Pontil style empirical Bernstein
    hw = np.sqrt(2.0 * phat * (1 - phat) * logterm / n) + 7.0 * logterm / (3.0 * (n - 1 if n > 1 else 1))
    return float(min(1.0, phat + hw))


def hypergeom_upper(k: int, n: int, N: int, alpha: float) -> float:
    """Exact upper bound on the number of violations in a finite window of N.

    Auditing a simple random sample of n out of N queries -> hypergeometric.
    Bisection on the population count K such that P(X <= k | K) >= alpha.
    This is the tight, exact tool; empirical-Bernstein's additive slack is what
    made an earlier version powerless (TCR 0.09).
    """
    if n >= N:
        return k / N
    lo, hi = k, N
    for _ in range(60):
        mid = (lo + hi) / 2.0
        K = int(round(mid))
        p = float(hypergeom.cdf(k, N, max(K, 0), n))
        if p >= alpha:
            lo = mid
        else:
            hi = mid
    return float(min(1.0, lo / N))


def hypergeom_lower(k: int, n: int, N: int, alpha: float) -> float:
    """Exact lower limit on the number of violations in a finite window of N.

    Dual to hypergeom_upper: smallest K for which observing >= k audited violations is
    not surprising. Used to separate "confirmed violation" from "not yet certified".
    """
    if n >= N:
        return k / N
    lo, hi = 0.0, float(N)
    for _ in range(60):
        mid = (lo + hi) / 2.0
        K = int(round(mid))
        p = float(hypergeom.sf(k - 1, N, max(K, 0), n))  # P_K(X >= k), increasing in K
        if p >= alpha:
            hi = mid
        else:
            lo = mid
    return float(max(0.0, min(1.0, hi / N)))


def clopper_pearson_upper(k: int, n: int, alpha: float) -> float:
    if n == 0:
        return 1.0
    if k >= n:
        return 1.0
    lo, hi = k / n, 1.0
    for _ in range(60):
        mid = (lo + hi) / 2.0
        if float(binom.cdf(k, n, mid)) >= alpha:
            lo = mid
        else:
            hi = mid
    return float(min(1.0, lo))


def hoeffding_upper(k: int, n: int, alpha: float) -> float:
    if n == 0:
        return 1.0
    return float(min(1.0, k / n + np.sqrt(np.log(1.0 / alpha) / (2.0 * n))))


def t_upper_mean(x: np.ndarray, alpha: float) -> float:
    """Upper bound on the *mean* recall (the metric people actually monitor)."""
    n = len(x)
    if n < 2:
        return 1.0
    return float(min(1.0, np.mean(x) + 1.645 * np.std(x, ddof=1) / np.sqrt(n)))


# ----------------------------------------------------------------------------- worlds
def load_worlds(min_n: int = 2000):
    worlds = {}
    for f in sorted(glob.glob(os.path.join(S0, "perquery_*.jsonl"))):
        name = os.path.basename(f)[len("perquery_"):-len(".jsonl")]
        if name.startswith(("smoke", "smoke2")):
            continue
        rows = [json.loads(l) for l in open(f)]
        by_ef = {}
        for r in rows:
            by_ef.setdefault(int(r.get("ef", -1)), []).append(r)
        for ef, rs in by_ef.items():
            if len(rs) < min_n:
                continue
            rec = np.array([r["recall"] for r in rs], dtype=np.float64)
            cl = np.array([r.get("cluster", -1) for r in rs], dtype=np.int64)
            rounds = np.array([r["round"] for r in rs], dtype=np.int64)
            fam = np.array([0 if r["family"] == "old" else 1 for r in rs], dtype=np.int64)
            worlds[f"{name}|ef{ef}"] = dict(recall=rec, cluster=cl, round=rounds, fam=fam)
    return worlds


# ----------------------------------------------------------------------------- certify
def certify_world(w: dict, tau: float, phi: float, p: float, alpha: float,
                  rng: np.random.Generator) -> dict:
    rec = w["recall"]
    n = len(rec)
    viol = (rec < tau).astype(np.float64)
    truth = float(viol.mean())

    aud = rng.random(n) < p
    m = int(aud.sum())
    k = int(viol[aud].sum())

    ub_eb = eb_upper(k, m, alpha)
    ub_exact = hypergeom_upper(k, m, n, alpha)
    ub_cp = clopper_pearson_upper(k, m, alpha)
    ub_hoef = hoeffding_upper(k, m, alpha)
    ub_mean = t_upper_mean(rec[aud], alpha)     # upper bound on mean recall
    # mean-based rule: certification of "recall >= tau" via the mean's lower bound
    lb_mean = float(np.mean(rec[aud]) - 1.645 * (np.std(rec[aud], ddof=1) / np.sqrt(max(m, 2))))

    # one-shot audit: spend all budget in the first 10% of the stream, then reuse it
    n1 = max(int(0.1 * n), 30)
    aud1 = aud[:n1]
    m1, k1 = int(aud1.sum()), int(viol[:n1][aud1].sum())
    ub_oneshot = eb_upper(k1, m1, alpha)

    # cluster bootstrap (resample clusters, not queries) on the audited subset
    cl = w["cluster"][aud]
    v = viol[aud]
    uniq = np.unique(cl)
    if len(uniq) >= 3:
        boots = []
        for _ in range(200):
            pick = rng.choice(uniq, size=len(uniq), replace=True)
            vals = np.concatenate([v[cl == c] for c in pick])
            boots.append(vals.mean())
        ub_cluster = float(np.quantile(boots, 1 - alpha))
    else:
        ub_cluster = 1.0

    return dict(
        n=n, m=m, truth=truth,
        ub_ours=ub_eb, ub_exact=ub_exact, ub_cp=ub_cp, ub_hoeffding=ub_hoef, ub_mean_rule=1.0 - lb_mean,
        ub_oneshot=ub_oneshot, ub_cluster=ub_cluster,
        cert_ours=bool(ub_eb <= phi), cert_exact=bool(ub_exact <= phi),
        cert_cp=bool(ub_cp <= phi), cert_hoeffding=bool(ub_hoef <= phi),
        cert_mean=bool(lb_mean >= tau), cert_oneshot=bool(ub_oneshot <= phi),
        cert_cluster=bool(ub_cluster <= phi),
        violates=bool(truth > phi),
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tau", type=float, default=0.95)
    ap.add_argument("--phi", type=float, default=0.05)
    ap.add_argument("--p", type=float, default=0.05, help="audit rate")
    ap.add_argument("--alpha", type=float, default=0.05, help="delta of the certificate")
    ap.add_argument("--seeds", type=int, default=60)
    ap.add_argument("--out", default=os.path.join(S0, "t1_audit.json"))
    a = ap.parse_args()

    worlds = load_worlds()
    if not worlds:
        raise SystemExit("no worlds: run scripts/exp_s0_decay.py first")
    print(f"worlds={len(worlds)}  tau={a.tau} phi={a.phi} p={a.p} alpha={a.alpha} seeds={a.seeds}")
    print(f"{'world':34s} {'n':>6s} {'truth':>6s} {'viol?':>5s} {'exact':>6s} {'cp':>6s} {'oursEB':>6s} "
          f"{'mean':>6s} {'1shot':>6s} {'clust':>6s}")

    out = {"args": vars(a), "worlds": {}}
    agg = {k: {"tp": 0, "fp": 0, "fn": 0, "tn": 0} for k in
           ("ours", "exact", "cp", "hoeffding", "mean", "oneshot", "cluster")}
    for name, w in sorted(worlds.items()):
        rng = np.random.default_rng(abs(hash(name)) % (2 ** 31))
        runs = [certify_world(w, a.tau, a.phi, a.p, a.alpha, rng) for _ in range(a.seeds)]
        truth = runs[0]["truth"]
        violates = runs[0]["violates"]
        rate = {k: float(np.mean([r[f"cert_{k}"] for r in runs])) for k in agg}
        for k in agg:
            if violates:
                agg[k]["fp"] += rate[k]; agg[k]["tn"] += 1 - rate[k]
            else:
                agg[k]["tp"] += rate[k]; agg[k]["fn"] += 1 - rate[k]
        out["worlds"][name] = dict(truth=truth, violates=violates, cert_rate=rate,
                                   m_mean=float(np.mean([r["m"] for r in runs])))
        print(f"{name:34s} {int(runs[0]['n']):6d} {truth:6.3f} {str(violates):>5s} "
              f"{rate['exact']:6.2f} {rate['cp']:6.2f} {rate['ours']:6.2f} {rate['mean']:6.2f} "
              f"{rate['oneshot']:6.2f} {rate['cluster']:6.2f}")

    print("\n=== 决策矩阵（世界级；100 次审计重放取平均比例后按世界累加）===")
    print(f"{'rule':10s} {'TP':>6s} {'FN':>6s} {'FP':>6s} {'TN':>6s} {'FCR(FP/(FP+TN))':>16s} {'TCR(TP/(TP+FN))':>16s}")
    summary = {}
    for k, v in agg.items():
        fcr = v["fp"] / max(v["fp"] + v["tn"], 1e-9)
        tcr = v["tp"] / max(v["tp"] + v["fn"], 1e-9)
        summary[k] = {"TP": v["tp"], "FN": v["fn"], "FP": v["fp"], "TN": v["tn"],
                      "false_cert_rate": fcr, "true_cert_rate": tcr}
        print(f"  {k:10s} {v['tp']:6.1f} {v['fn']:6.1f} {v['fp']:6.1f} {v['tn']:6.1f} {fcr:16.2f} {tcr:16.2f}")
    out["summary"] = summary
    with open(a.out, "w") as f:
        json.dump(out, f, indent=1)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
