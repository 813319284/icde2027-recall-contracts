# Reproduction bundle

`scripts/` holds every experiment and every gate, `src/icde_lab/` the library they import; the
JSON/JSONL artifacts those runs produced live in `../reports/` (per-query logs included, so any table
can be replayed offline). The checkers locate the archive root themselves, so they work from
here without environment variables.

```bash
cd .. && bash repro.sh          # table numbers, prose numbers, template conformance
```

The heavy experiments need the public ann-benchmarks HDF5 files (`sift-128-euclidean`,
`glove-100-angular`, `nytimes-256-angular`, `deep-image-96-angular`), and the PostgreSQL closed
loop needs Docker (`../supplementary/env/pgvector/Dockerfile`):

```bash
python3 scripts/exp_s0_decay.py --data sift-128-euclidean.hdf5 --tag siftA --drift append
python3 scripts/exp_sizing.py
python3 scripts/exp_audit_protocol.py --runs 1000 --regime boundary --p 0.10 --spend uniform \
        --out reports/s0/protocol_boundary_p10_1000.json
python3 scripts/exp_t3_closed_loop.py --policies never,periodic_4,ef_auto,ctrl,ctrl_mean
python3 scripts/exp_u1_pgvector.py --policies never,periodic_4,ctrl_mean,ctrl --seed 1
python3 scripts/exp_u5_margin.py --tag sift --n-base 200000 --nq 3000 --rounds 2 --efs 32 64 128
python3 scripts/exp_u5_strat.py --tag sift --ef 128 --strata 4 --reps 300 --phi 0.10
python3 scripts/make_figs.py           # every panel in paper/figures/, incl. Fig. 1 (loop.pdf)
```

Dependency versions: `requirements.txt`. Hardware and dataset versions are recorded in
`../supplementary/MANIFEST.txt`.
