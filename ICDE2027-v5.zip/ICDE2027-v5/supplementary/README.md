# Supplementary material package

ICDE 2027 Round 2 submission — *Recall Contracts: Anytime-Valid Auditing of Vector Search,
and the Price of Compliance*.

The paper has no appendix (ICDE forbids it), so everything that supports it without being
part of its 12 pages lives here.

## Contents

| path | what it is |
|---|---|
| `supplement.pdf` | 9 pages: full proofs, protocol, the PostgreSQL closed loop (with the cross-engine table and per-epoch log), the targeting study, the reproduction manifest |
| `supplement.tex` | its source (`bash repro/scripts/build_supp.sh` from the archive root) |
| `tables/*.tex` | every table in the supplement, **generated** by `repro/scripts/make_supp_tables.py` from `reports/*.json` — no number is typed by hand |
| `repro.sh` | one command per artifact, in dependency order, with the gates at the end |
| `env/pgvector/Dockerfile` | the database environment for the real-system experiment |
| `MANIFEST.txt` | sha256 of the submitted PDF, the source hash, and the artifact list |

## Reproducing the paper's numbers

```bash
bash supplementary/repro.sh --gates    # rebuild, audit, verify (about 3 minutes on this box)
bash supplementary/repro.sh --database # additionally rebuilds the PostgreSQL experiment (~40 min)
```

The two gates that must exit 0 are:

```bash
python3 repro/scripts/check_numbers.py                 # 236 table cells vs artifacts
python3 repro/scripts/check_prose_numbers.py --strict   # every prose number traces to an artifact
bash repro/scripts/verify_all.sh                        # eleven layers, last line ALL LAYERS OK
```

## What the supplement adds beyond the paper

1. **Full proofs**, including the three design constraints of the certificate (predictable
   audit rate; epoch boundary fixed before the first audit; the α/|E| split that lets the
   controller choose the operating point from the audit it just took).
2. **The protocol at re-runnable detail**, including the measurement discipline: the earlier
   batch of closed-loop latencies was taken with three jobs in flight and was ~25% high;
   those numbers were discarded and re-measured serially.
3. **The closed loop in PostgreSQL 16 + pgvector 0.8.7**: schema, index, server settings,
   the exact SQL of each phase, measured costs, and the per-epoch log of the three policies
   that carry the argument.
4. **A study that is not in the paper**: the tail is predictable from the distances the index
   already returns (AUC 0.70; 14× between the extreme deciles at ef=64, 59× at ef=128), but
   allocating the audit budget by that score costs *more* audits than blind pooling under an
   exact certificate (8.5% more with two strata, 31.2% with four). The score's use is
   prediction, not allocation.

## Files in the repository that this package depends on

```
paper/main.tex            the submission source
paper/refs.bib            23 references
paper/figures/            7 panels, all vector PDF
repro/scripts/            every experiment and every gate (scripts/ in the source tree)
reports/                  every artifact (JSON + per-query logs)
relay/AUDIT.md            number → artifact → recompute command, one row per claim
relay/claims.json         30 headline claims, machine-checked against the PDF
```
