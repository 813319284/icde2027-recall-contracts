#!/usr/bin/env bash
# Reproduce the submission, one step at a time.
#
#   bash supplementary/repro.sh              # build the paper + every number gate (~3 min)
#   bash supplementary/repro.sh --gates      # same, explicit
#   bash supplementary/repro.sh --database   # additionally re-run the PostgreSQL experiment (~40 min)
#   bash supplementary/repro.sh --supp       # additionally rebuild supplement.pdf
#
# Every step prints what it produced; the script stops at the first failure, because a
# silent failure is exactly how a stale PDF once shipped (see relay/DECISIONS.md D006).
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT=$(pwd)
if [ -d "$ROOT/repro/scripts" ]; then SCR="$ROOT/repro/scripts"; else SCR="$ROOT/scripts"; fi
DO_DB=0; DO_SUPP=0
for a in "$@"; do
  case "$a" in
    --database) DO_DB=1 ;;
    --supp) DO_SUPP=1 ;;
    --gates) ;;
    *) echo "unknown flag: $a" >&2; exit 2 ;;
  esac
done

step() { printf '\n== %s\n' "$*"; }

step "1/6 build the paper (deterministic; fails instead of reusing a stale PDF)"
bash "$SCR"/build_paper.sh

step "2/6 every table number traces to an artifact"
python3 "$SCR"/check_numbers.py

step "3/6 every prose number traces to an artifact"
python3 "$SCR"/check_prose_numbers.py --strict

step "4/6 mechanical preflight (author block is the PI's to fill)"
python3 "$SCR"/preflight.py || echo "  (non-zero only while the author block is a placeholder)"

step "5/6 ten-layer gate"
bash "$SCR"/verify_all.sh

if [ "$DO_DB" = "1" ]; then
  step "6/6 the real-system closed loop (PostgreSQL 16 + pgvector)"
  if ! docker image inspect icde/pgvector:pg16 >/dev/null 2>&1; then
    docker build --build-arg DEBIAN_MIRROR=mirrors.tuna.tsinghua.edu.cn \
      -t icde/pgvector:pg16 env/pgvector
  fi
  docker rm -f icde-pg >/dev/null 2>&1 || true
  mkdir -p /opt/volume/icde-pg
  docker run -d --name icde-pg -p 5433:5432 --shm-size=6g \
    -e POSTGRES_PASSWORD=icde -e POSTGRES_DB=icde \
    -v /opt/volume/icde-pg:/var/lib/postgresql/data icde/pgvector:pg16 \
    postgres -c shared_buffers=6GB -c maintenance_work_mem=3GB \
             -c max_parallel_maintenance_workers=12 -c max_parallel_workers=16 \
             -c synchronous_commit=off -c work_mem=256MB
  for i in $(seq 1 30); do docker exec icde-pg pg_isready -U postgres >/dev/null 2>&1 && break; sleep 1; done
  docker exec icde-pg psql -U postgres -d icde -c "CREATE EXTENSION IF NOT EXISTS vector"
  python3 "$SCR"/exp_u1_pgvector.py
  python3 "$SCR"/make_supp_tables.py
else
  step "6/6 the real-system closed loop: skipped (pass --database)"
fi

if [ "$DO_SUPP" = "1" ]; then
  step "supplement"
  bash "$SCR"/build_supp.sh
fi

step "receipt"
bash "$SCR"/submit_manifest.sh
