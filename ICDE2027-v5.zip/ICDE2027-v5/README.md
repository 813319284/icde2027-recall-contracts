# Recall Contracts — ICDE 2027 Round 2 submission, V5

```
paper.pdf                    the submission PDF (13 pages; body ~11.9, references from p. 12)
paper/                       LaTeX source: main.tex, refs.bib, figures/ (7 vector panels), IEEEtran.cls
                             (the class file from the official template 062824, sha c972aca1…)
supplementary/               supplement.pdf (9 pages) + source, generated tables,
                             env/pgvector/Dockerfile, MANIFEST.txt
repro/                       scripts/, src/icde_lab/, requirements.txt
repro.sh                     the gates, runnable from this directory
CHANGELOG-v5.md              what changed relative to the previous delivery
SHA256SUMS                   hashes of every file here
```

## Rebuild the two PDFs

```bash
export SOURCE_DATE_EPOCH=1757484000 FORCE_SOURCE_DATE=1   # the pin used for the delivered bytes
cd paper && pdflatex main && bibtex main && pdflatex main && pdflatex main && cd ..
cd supplementary && pdflatex supplement && pdflatex supplement && cd ..
sha256sum paper/main.pdf supplementary/supplement.pdf     # compare with SHA256SUMS
```

## Check every number

```bash
bash repro.sh        # 236 table cells, 494 prose numbers, 22 template checks — exit 0 required
```

The heavy experiments are listed in `repro/README.md`; they need the public ann-benchmarks
HDF5 files and, for the PostgreSQL closed loop, Docker.
