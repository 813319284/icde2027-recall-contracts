# V5 changelog

V5 is the submission version. It closes the four blocking items and the bundle-hygiene items of
the final external review of V4.

## Theory

1. **Theorem 3** now states admissible Bernoulli parameters,
   `0 < eps < min{phi/2, 1-phi}`, and gives the denominator as `Theta(eps^2/(phi(1-phi)))`, so the
   dependence of the constant on `phi` is explicit instead of hidden in a subscript. The paper and
   the supplement carry the same statement and the same remark.
2. **The data-dependent epoch-boundary extension** of Theorem 1 is restated: an epoch's population
   and its size must be fixed before that epoch's audit coins are drawn, and a boundary that reads
   the current epoch's own audit indicators is outside the argument even when it never inspects a
   label. A later epoch may depend on verdicts already issued. The supplement's design-constraint
   remark says the same thing in the same terms.

## Evidence for the three regimes (Table XIV)

3. The NYTimes-256 and GloVe-1.18M trajectories were **rerun with the current code**, so their logs
   now record `ef_served`, `ef_verified` and `verdict` exactly as the SIFT logs do.
   `exp_t3_recheck.py` covers all three datasets, and `check_numbers.py` now **fails** when a dataset
   has no exact-certification artifact rather than keeping the printed value.
4. The regimes block of `check_numbers.py` reads `certificate_recheck.json` under `runs`; the earlier
   version read the top level and silently matched nothing, so every row fell through to a
   "value kept" branch.
5. Per-run `summary` blocks in `reports/t3/*.json` were recomputed from their round records, so
   `cert_rounds` and `false_cert` equal the exact verdicts. The stored summaries had drifted from the
   rounds after the certification/screening split; the aggregates and the paper were unaffected.

## Bundle hygiene

6. `supplementary/repro.sh` and `supplementary/README.md` use the archive layout (`repro/scripts/...`)
   and no longer reference a build path outside the archive.
7. `paper/SUBMIT.md` carries the current gate counts (38/38, 236 cells) and contains no absolute local
   paths. No file in the archive names a host, a home directory or an internal address.
8. Figure files that the paper does not reference are not shipped.
9. Prose: the abstract and the introduction received a conservative style pass, sentence level only.
   No number, citation, label, claim or emphasis was changed by it.
